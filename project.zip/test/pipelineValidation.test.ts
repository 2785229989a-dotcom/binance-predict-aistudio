import { OpportunityEngine, PAYOUT_RATIOS, COOLDOWN_MS } from '../src/server/opportunityEngine.js';
import { MarketSnapshot, SignalOrder, SymbolType, DurationType } from '../src/types/market.js';
import { ContractManager } from '../src/server/contractManager.js';

// ANSI terminal colors for clean test reporting
const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const CYAN = '\x1b[36m';
const RESET = '\x1b[0m';
const BOLD = '\x1b[1m';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`${RED}  ✗ FAILED: ${message}${RESET}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`${GREEN}  ✓ PASSED: ${message}${RESET}`);
}

function createMockSnapshot(overrides: Partial<MarketSnapshot> = {}): MarketSnapshot {
  const basePrice = overrides.price || (overrides.symbol === 'ETHUSDT' ? 2450 : 68000);
  return {
    symbol: overrides.symbol || 'BTCUSDT',
    price: basePrice,
    markPrice: basePrice,
    indexPrice: basePrice,
    high24h: basePrice * 1.03,
    low24h: basePrice * 0.97,
    volume24h: 15000,
    priceChange24h: basePrice * 0.012,
    priceChangePercent24h: 1.2,
    cvdHistory: [],
    currentCvd: 50,
    nextFundingTime: Date.now() + 14400000,
    longShortRatio: 1.05,
    isRealData: true,
    prediction: {} as any,
    currentRound: {} as any,
    microstructure: { tradesPerSecond: 12, volumePerSecond: 25, takerBuyRatio: 0.55, tickDelta: 5, speedRating: 'NORMAL' },
    orderBook: {
      bids: [
        { price: basePrice - 1, quantity: 5.5, total: 5.5 },
        { price: basePrice - 2, quantity: 12.0, total: 17.5 },
      ],
      asks: [
        { price: basePrice + 1, quantity: 4.2, total: 4.2 },
        { price: basePrice + 2, quantity: 10.0, total: 14.2 },
      ],
      bidTotal: 100,
      askTotal: 80,
      imbalanceRatio: 0.55,
      spread: 0.5,
      spreadPercent: 0.001,
    },
    recentTrades: [],
    indicators: {
      rsi: 54,
      macd: { macd: 12, signal: 8, histogram: 4 },
      ema7: basePrice * 0.998,
      ema20: basePrice * 0.995,
      ema50: basePrice * 0.990,
      bollinger: { upper: basePrice * 1.015, middle: basePrice, lower: basePrice * 0.985, bandwidth: 0.65 },
      atr14: basePrice * 0.0025,
      volatilityPercent: 0.25,
    },
    multiTimeframe: {
      trends: [
        { timeframe: '15m', direction: 'UP', emaDiffPercent: 0.5, rsi: 55 },
        { timeframe: '1h', direction: 'UP', emaDiffPercent: 0.8, rsi: 56 },
        { timeframe: '4h', direction: 'UP', emaDiffPercent: 1.0, rsi: 58 },
      ] as any,
      alignmentScore: 40,
      alignmentText: 'ALIGNED_BULLISH',
      hasConflict: false,
    },
    recentKlines: Array.from({ length: 40 }).map((_, i) => ({
      time: Date.now() - (40 - i) * 60000,
      openTime: Date.now() - (40 - i) * 60000,
      closeTime: Date.now() - (39 - i) * 60000,
      open: basePrice * (1 + (i - 20) * 0.0005),
      high: basePrice * (1 + (i - 20) * 0.0005 + 0.001),
      low: basePrice * (1 + (i - 20) * 0.0005 - 0.001),
      close: basePrice * (1 + (i - 19) * 0.0005),
      volume: 100,
      quoteVolume: 100 * basePrice,
      buyVolume: 55,
      sellVolume: 45,
      cvd: 10,
    })),
    cvdSlope: 6.5,
    cvd5mChange: 20.0,
    rawOfi: 8.2,
    latencyMs: 85,
    lastUpdated: Date.now(),
    fundingRate: 0.0001,
    openInterest: 50000,
    ...overrides,
  };
}

async function runPipelineAcceptanceTests() {
  console.log(`\n${BOLD}${CYAN}================================================================${RESET}`);
  console.log(`${BOLD}${CYAN}   事件合约开单决策逻辑与实时信号生成流水线 — 验收测试套件      ${RESET}`);
  console.log(`${BOLD}${CYAN}================================================================${RESET}\n`);

  const engine = new OpportunityEngine();

  // Test 1: Independent LONG and SHORT Logic (严禁非黑即白的镜像逻辑)
  console.log(`${BOLD}[1. 独立方向逻辑判定 — 严禁镜像逻辑]${RESET}`);
  {
    const bearishSnap = createMockSnapshot({
      symbol: 'BTCUSDT',
      cvdSlope: -7.5,
      cvd5mChange: -25.0,
      rawOfi: -12.0,
      indicators: {
        rsi: 42,
        macd: { macd: -15, signal: -10, histogram: -5 },
        ema7: 67900,
        ema20: 68000,
        ema50: 68200,
        bollinger: { upper: 68500, middle: 68000, lower: 67500, bandwidth: 0.6 },
        atr14: 150,
        volatilityPercent: 0.22,
      },
      orderBook: {
        bids: [{ price: 67990, quantity: 2, total: 2 }],
        asks: [{ price: 68000, quantity: 25, total: 25 }],
        bidTotal: 20,
        askTotal: 120,
        imbalanceRatio: 0.15,
        spread: 1.0,
        spreadPercent: 0.001,
      },
      multiTimeframe: {
        trends: [
          { timeframe: '15m', direction: 'DOWN', emaDiffPercent: -0.6, rsi: 40 },
          { timeframe: '1h', direction: 'DOWN', emaDiffPercent: -0.9, rsi: 40 },
        ] as any,
        alignmentScore: -40,
        alignmentText: 'ALIGNED_BEARISH',
        hasConflict: false,
      },
    });

    const pool = engine.evaluateOpportunityPool(
      { BTCUSDT: bearishSnap, ETHUSDT: createMockSnapshot({ symbol: 'ETHUSDT' }) },
      []
    );

    const btc10m = pool.candidates.find((c) => c.symbol === 'BTCUSDT' && c.duration === '10m');
    assert(btc10m !== undefined, 'BTC 10m 候选对象必须生成');
    if (btc10m) {
      assert(
        btc10m.candidateDirection === 'DOWN',
        `当盘口卖压明显时，应独立判定看跌 DOWN (实际: ${btc10m.candidateDirection})`
      );
    }

    // Neutral snapshot
    const neutralSnap = createMockSnapshot({
      symbol: 'BTCUSDT',
      cvdSlope: 0.1,
      cvd5mChange: 0.5,
      rawOfi: -0.2,
      indicators: {
        rsi: 50.1,
        macd: { macd: 0.5, signal: 0.4, histogram: 0.1 },
        ema7: 68000,
        ema20: 68000,
        ema50: 68000,
        bollinger: { upper: 68200, middle: 68000, lower: 67800, bandwidth: 0.3 },
        atr14: 80,
        volatilityPercent: 0.12,
      },
      orderBook: {
        bids: [{ price: 67999, quantity: 5, total: 5 }],
        asks: [{ price: 68001, quantity: 5, total: 5 }],
        bidTotal: 50,
        askTotal: 50,
        imbalanceRatio: 0.5,
        spread: 0.5,
        spreadPercent: 0.001,
      },
    });

    const neutralPool = engine.evaluateOpportunityPool(
      { BTCUSDT: neutralSnap, ETHUSDT: createMockSnapshot({ symbol: 'ETHUSDT' }) },
      []
    );
    const neutralBtc = neutralPool.candidates.find((c) => c.symbol === 'BTCUSDT' && c.duration === '10m');
    assert(
      neutralBtc?.direction === 'WAIT',
      `中性震荡无明显优势时，状态必须为 WAIT (实际: ${neutralBtc?.direction})`
    );
  }

  // Test 2: Dynamic Thresholds across Regimes (动态门槛体系)
  console.log(`\n${BOLD}[2. 动态门槛体系与高波动保护]${RESET}`);
  {
    const trendThresholds = engine.getDynamicThresholds('TREND_UP');
    assert(trendThresholds.minCalibratedProb === 78.0, '强趋势市场门槛胜率为 78%');
    assert(trendThresholds.requireStrongOrderFlow === true, '强趋势市场必须具备强烈订单流');

    const rangeThresholds = engine.getDynamicThresholds('RANGE');
    assert(rangeThresholds.minCalibratedProb === 85.0, '震荡市场门槛胜率需提高至 85%');
    assert(rangeThresholds.minEdge === 8.0, '震荡市场门槛 Edge 需提高至 +8%');

    const highVolThresholds = engine.getDynamicThresholds('HIGH_VOLATILITY');
    assert(highVolThresholds.minCalibratedProb === 88.0, '极端高波动市场门槛胜率提高至 88%');

    const chaoticThresholds = engine.getDynamicThresholds('CHAOTIC');
    assert(chaoticThresholds.pauseTrading === true, '混乱/数据延迟市场必须暂停开单 (pauseTrading = true)');
  }

  // Test 3: Overextension & Anti-Chasing Filter (防追涨追空检测)
  console.log(`\n${BOLD}[3. 追涨追空风险检测 (Anti-Overextension)]${RESET}`);
  {
    const overboughtCheck = engine.checkOverextension(69500, 68000, 300, 'UP', 78);
    assert(overboughtCheck.isOverextended === true, '严重偏离均线且超买时，必须标记为 Overextended 阻断');
    assert(
      overboughtCheck.reason?.includes('过度延伸') === true || overboughtCheck.reason?.includes('追多') === true,
      '阻断原因必须明确指出偏离均线过度延伸追多风险'
    );

    const healthyCheck = engine.checkOverextension(68100, 68000, 300, 'UP', 58);
    assert(healthyCheck.isOverextended === false, '健康适度偏离不应触发 Overextended 拦截');
  }

  // Test 4: Intra-Symbol Multi-Timeframe Deduplication (严禁多周期机械连开)
  console.log(`\n${BOLD}[4. 同源多周期去重 — 严禁 10m/30m/1h/1d 机械同向连开]${RESET}`);
  {
    const strongBullishSnap = createMockSnapshot({
      symbol: 'BTCUSDT',
      price: 68500,
      cvdSlope: 12.0,
      cvd5mChange: 35.0,
      rawOfi: 18.0,
      indicators: {
        rsi: 62,
        macd: { macd: 25, signal: 15, histogram: 10 },
        ema7: 68400,
        ema20: 68200,
        ema50: 67900,
        bollinger: { upper: 69200, middle: 68400, lower: 67600, bandwidth: 0.8 },
        atr14: 180,
        volatilityPercent: 0.28,
      },
      multiTimeframe: {
        trends: [
          { timeframe: '15m', direction: 'UP', emaDiffPercent: 0.6, rsi: 62 },
          { timeframe: '1h', direction: 'UP', emaDiffPercent: 0.9, rsi: 64 },
          { timeframe: '4h', direction: 'UP', emaDiffPercent: 1.2, rsi: 65 },
        ] as any,
        alignmentScore: 45,
        alignmentText: 'ALIGNED_BULLISH',
        hasConflict: false,
      },
    });

    const pool = engine.evaluateOpportunityPool(
      { BTCUSDT: strongBullishSnap, ETHUSDT: createMockSnapshot({ symbol: 'ETHUSDT' }) },
      []
    );

    const btcQualified = pool.qualifiedSignalsToOpen.filter((c) => c.symbol === 'BTCUSDT');
    assert(
      btcQualified.length <= 1,
      `BTC 同向多周期必须经同源合并去重，严禁同向机械连开 (实际通过数: ${btcQualified.length})`
    );

    if (btcQualified.length > 0) {
      console.log(`  ✓ 优选胜出周期: ${btcQualified[0].duration} (Score: ${btcQualified[0].signalScore})`);
    }
  }

  // Test 5: Cross-Asset De-correlation Filter (严禁双币种无脑联动)
  console.log(`\n${BOLD}[5. 多币种去重与高相关性去相关 (De-correlation)]${RESET}`);
  {
    const btcSnap = createMockSnapshot({ symbol: 'BTCUSDT', cvdSlope: 14.0, rawOfi: 20.0 });
    const ethSnap = createMockSnapshot({ symbol: 'ETHUSDT', cvdSlope: 8.0, rawOfi: 9.0 });

    const pool = engine.evaluateOpportunityPool({ BTCUSDT: btcSnap, ETHUSDT: ethSnap }, []);

    const btcApproved = pool.qualifiedSignalsToOpen.find((c) => c.symbol === 'BTCUSDT');
    const ethApproved = pool.qualifiedSignalsToOpen.find((c) => c.symbol === 'ETHUSDT');

    if (pool.btcEthCorrelation > 0.70 && btcApproved && ethApproved) {
      assert(
        Boolean(
          btcApproved.candidateDirection !== ethApproved.candidateDirection ||
            ethApproved.signalScore >= 94
        ),
        '高相关度下 BTC 与 ETH 不得因宏观联动盲目双开同向单'
      );
    }
    console.log(`  ✓ BTC-ETH 滚动相关度: ${(pool.btcEthCorrelation * 100).toFixed(1)}%`);
  }

  // Test 6: Cooldown Logic (冷却期防抖)
  console.log(`\n${BOLD}[6. 信号冷却期防抖 (Cooldown)]${RESET}`);
  {
    const snap = createMockSnapshot({ symbol: 'BTCUSDT', cvdSlope: 15, rawOfi: 22 });
    const fakeHistoricalOrder: SignalOrder = {
      signalId: 'SIG-TEST-0001',
      id: 'SIG-TEST-0001',
      date: '2026-10-15',
      symbol: 'BTCUSDT',
      duration: '10m',
      direction: 'UP',
      signalTime: Date.now() - 2 * 60 * 1000,
      timestamp: Date.now() - 2 * 60 * 1000,
      signalPrice: 68000,
      referencePrice: 68000,
      modelProb: 82,
      upProb: 82,
      downProb: 18,
      waitProb: 5,
      payoutRatio: 0.8,
      breakEvenProb: 55.56,
      edge: 26.44,
      expectedValue: 45,
      entryTime: Date.now() - 2 * 60 * 1000,
      entryPriceIndex: 68000,
      expiryTime: Date.now() + 8 * 60 * 1000,
      settlementTime: Date.now() + 8 * 60 * 1000,
      expiryPriceIndex: null,
      priceChange: null,
      status: 'ACTIVE',
      result: 'PENDING',
      outcome: 'PENDING',
      resultDetail: '测试中',
      rationale: ['测试'],
      score: 90,
      confirmations: ['测试'],
      createdAt: Date.now() - 2 * 60 * 1000,
    };

    const poolWithCd = engine.evaluateOpportunityPool(
      { BTCUSDT: snap, ETHUSDT: createMockSnapshot({ symbol: 'ETHUSDT' }) },
      [fakeHistoricalOrder],
      [fakeHistoricalOrder]
    );

    const btc10m = poolWithCd.rankedOpportunities.find(
      (c) => c.symbol === 'BTCUSDT' && c.duration === '10m'
    );
    assert(
      Boolean(
        btc10m?.status === 'FILTERED' &&
          (btc10m?.filterReason?.includes('活动订单') || btc10m?.filterReason?.includes('冷却期'))
      ),
      '同一周期在运行中或冷却期内，必须拦截并标记为 FILTERED'
    );
  }

  // Test 7: Signal Locking & Zero Look-Ahead Bias (信号锁定与T+1确立)
  console.log(`\n${BOLD}[7. 信号锁死与真实 T+1 生命周期]${RESET}`);
  {
    const cm = new ContractManager();
    // 隔离测试实例，避免受持久化磁盘上正在运行中的真实活动订单干扰
    (cm as any).signalOrders = [];
    const cand = {
      id: 'BTCUSDT-10m',
      symbol: 'BTCUSDT' as SymbolType,
      duration: '10m' as DurationType,
      direction: 'UP' as const,
      candidateDirection: 'UP' as const,
      status: 'OPEN' as const,
      regime: 'TREND_UP' as const,
      regimeLabel: '多头趋势',
      rawProbability: 84,
      calibratedProbability: 80.5,
      marketProbability: 55.56,
      edge: 24.94,
      expectedValue: 44.9,
      signalScore: 91,
      strengthLevel: 'VERY_STRONG' as const,
      rank: 1,
      timeframeRole: '微观订单流高频撮合',
      historicalSampleCount: 15,
      historicalWinRate: 80.0,
      historicalConfidence: 'MEDIUM' as const,
      isOverextended: false,
      rejectionReasons: [],
      keyFactors: ['CVD放量', 'OFI买方占优'],
      riskNotes: ['到期结算对比'],
      timestamp: Date.now(),
    };

    const entryPrice = 68420.5;
    const order = cm.createOrderFromOpportunity(cand, entryPrice);
    assert(order !== null, '达标候选机会必须成功生成 SignalOrder');
    if (order) {
      assert(order.entryPriceIndex === entryPrice, `开仓价必须立即精确锁定为 ${entryPrice}`);
      assert(order.direction === 'UP', '方向必须锁定为 UP');
      assert(order.expiryTime === order.entryTime + 10 * 60 * 1000, '到期时间必须精确锁定为 10 分钟后');

      const tickPrice = 69000.0;
      cm.updatePriceAndTick('BTCUSDT', tickPrice);
      const active = cm.getActiveSignalOrders().find((o) => o.signalId === order.signalId);
      assert(active?.entryPriceIndex === entryPrice, '盘中价格大幅变动时，历史开仓价严禁被篡改');
    }
  }

  // Test 8: Historical Simulation Runboard (历史模拟跑板统计流水线各阶段过滤率)
  console.log(`\n${BOLD}[8. 历史多情境模拟跑板 (300 轮市场扫描统计流水线漏斗)]${RESET}`);
  {
    let totalCandidates = 0;
    let regimeFiltered = 0;
    let overextensionFiltered = 0;
    let orderflowDirectionFiltered = 0;
    let probEdgeEvFiltered = 0;
    let deduplicationFiltered = 0;
    let correlationFiltered = 0;
    let finalOpenCount = 0;
    let waitCount = 0;

    const iterations = 300;

    for (let i = 0; i < iterations; i++) {
      const rand = Math.random();
      let btcCvd = 0;
      let btcOfi = 0;
      let latency = 80;
      let atr = 120;
      let rsi = 50;

      if (rand < 0.50) {
        btcCvd = (Math.random() - 0.5) * 4;
        btcOfi = (Math.random() - 0.5) * 6;
        rsi = 45 + Math.random() * 10;
      } else if (rand < 0.70) {
        atr = 500;
        btcCvd = (Math.random() - 0.5) * 20;
        btcOfi = (Math.random() - 0.5) * 30;
      } else if (rand < 0.85) {
        btcCvd = Math.random() > 0.5 ? 9.5 : -9.5;
        btcOfi = Math.random() > 0.5 ? 12.0 : -12.0;
        rsi = btcCvd > 0 ? 62 : 38;
      } else if (rand < 0.95) {
        latency = 3500;
      } else {
        btcCvd = 18.0;
        btcOfi = 25.0;
        rsi = 60;
        atr = 150;
      }

      const simBtc = createMockSnapshot({
        symbol: 'BTCUSDT',
        cvdSlope: btcCvd,
        cvd5mChange: btcCvd * 2,
        rawOfi: btcOfi,
        latencyMs: latency,
        indicators: {
          rsi,
          macd: { macd: btcCvd * 2, signal: btcCvd, histogram: btcCvd },
          ema7: 68000 + btcCvd * 20,
          ema20: 68000,
          ema50: 68000 - btcCvd * 20,
          bollinger: { upper: 68500, middle: 68000, lower: 67500, bandwidth: atr > 300 ? 1.5 : 0.6 },
          atr14: atr,
          volatilityPercent: atr > 300 ? 0.7 : 0.2,
        },
      });

      const simEth = createMockSnapshot({
        symbol: 'ETHUSDT',
        cvdSlope: btcCvd * 0.7,
        cvd5mChange: btcCvd * 1.4,
        rawOfi: btcOfi * 0.7,
        latencyMs: latency,
      });

      const poolRes = engine.evaluateOpportunityPool({ BTCUSDT: simBtc, ETHUSDT: simEth }, []);

      totalCandidates += poolRes.candidates.length;

      for (const cand of poolRes.candidates) {
        if (cand.direction === 'WAIT') {
          waitCount++;
          const reasons = cand.rejectionReasons.join(' ');
          if (reasons.includes('CHAOTIC') || reasons.includes('HIGH_VOLATILITY') || reasons.includes('保护态')) {
            regimeFiltered++;
          } else if (reasons.includes('追涨') || reasons.includes('追跌') || cand.isOverextended) {
            overextensionFiltered++;
          } else if (reasons.includes('独立判定') || reasons.includes('冲突')) {
            orderflowDirectionFiltered++;
          } else if (reasons.includes('动态门槛') || reasons.includes('Edge') || reasons.includes('EV')) {
            probEdgeEvFiltered++;
          }
        }
      }

      for (const cand of poolRes.rankedOpportunities) {
        if (cand.status === 'FILTERED') {
          if (cand.filterReason?.includes('同源')) deduplicationFiltered++;
          if (cand.filterReason?.includes('高相关性')) correlationFiltered++;
        }
      }

      finalOpenCount += poolRes.qualifiedSignalsToOpen.length;
    }

    const waitPercentage = ((waitCount / totalCandidates) * 100).toFixed(1);
    const openPercentage = ((finalOpenCount / totalCandidates) * 100).toFixed(1);

    console.log(`  ----------------------------------------------------------------`);
    console.log(`  【流水线漏斗统计表 (300 轮测试 / 8 个标的周期组合)】`);
    console.log(`  1. 初始候选总数 (Candidates):           ${totalCandidates}`);
    console.log(`  2. 市场状态与混沌过滤 (Regime/Chaos):   ${regimeFiltered}`);
    console.log(`  3. 追涨追空偏离过滤 (Overextension):    ${overextensionFiltered}`);
    console.log(`  4. 方向与微观订单流过滤 (Order Flow):   ${orderflowDirectionFiltered}`);
    console.log(`  5. 概率/Edge/EV 门槛过滤 (Math Alpha):  ${probEdgeEvFiltered}`);
    console.log(`  6. 同源多周期合并去重 (Deduplication):  ${deduplicationFiltered}`);
    console.log(`  7. 跨资产高相关性去重 (Correlation):    ${correlationFiltered}`);
    console.log(`  ----------------------------------------------------------------`);
    console.log(`  ${BOLD}最终获准开单 (OPEN Signals):             ${finalOpenCount} (${openPercentage}%)${RESET}`);
    console.log(`  ${BOLD}严格空仓观望 (WAIT Status):             ${waitCount} (${waitPercentage}%)${RESET}`);
    console.log(`  ----------------------------------------------------------------`);

    assert(
      Number(waitPercentage) >= 88.0,
      `在绝大多数无明显确定性优势的时间段必须保持 WAIT (当前 WAIT 率: ${waitPercentage}%)`
    );
    console.log(`${GREEN}  ✓ 漏斗过滤机制完全符合：宁缺毋滥，无真正统计优势时绝不开单！${RESET}`);
  }

  console.log(`\n${BOLD}${GREEN}================================================================${RESET}`);
  console.log(`${BOLD}${GREEN}   ✔ 全部 8 大验收测试指标均已 100% 验证通过！系统重构稳健就绪！   ${RESET}`);
  console.log(`${BOLD}${GREEN}================================================================${RESET}\n`);
}

runPipelineAcceptanceTests()
  .then(() => {
    process.exit(0);
  })
  .catch((err) => {
    console.error('Test run failed:', err);
    process.exit(1);
  });
