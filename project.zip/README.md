# Binance BTC/ETH 10分钟事件合约预测工作台 (Binance Event Contract Workbench)

专业级币安 BTC/ETH 10分钟事件合约量化预测工作台，支持真实行情流、Order Book深度、CVD、OFI、持仓量、资金费率多因子评分预测及模拟交易、回测与 Firestore 云端持久化。

---

## 核心功能

1. **真实高频数据接入**：
   - 官方币安 WebSocket 深度流 (`aggTrade`, `depth20@100ms`, `kline_1m`, `ticker`)。
   - 实时订单簿深度（Bid/Ask 聚合量、微观价格偏离度）。
   - CVD (累积成交量偏差) 与 OFI (订单流不平衡) 实时计算。

2. **多因子综合决策评分池 (Opportunity Engine)**：
   - 多周期并发测算 (10m / 30m / 1h / 1d)。
   - 择优开单机制（自动过滤弱势标的，只在胜率预期与期望值 EV 达到阈值时触发有效单）。
   - 精确锁定期与交割判定（P0 基准价锁存、到期盈亏自动清算）。

3. **云端持久化双层存储**：
   - **Local Cache & SQLite**：本地高频读写与断电恢复 (`data/trading.db`)。
   - **Firebase Firestore**：云端持久化存储，多终端与跨实例自动全量同步 (`signal_orders`, `daily_stats`)。

4. **专业图表看板**：
   - TradingView Lightweight Charts 原生 K 线图，MA7/MA25/MA99 均线动态计算与展示。
   - 信号实时标记（红色做多箭头、绿色做空箭头）、进场价格线与到期倒计时。

---

## 快速上手与运行

### 1. 安装依赖
```bash
npm install
```

### 2. 启动开发服务器
```bash
npm run dev
```
开发服务器将启动并在 `http://localhost:3000` 提供服务，集成了 Express API 与 Vite 前端热更新。

### 3. 生产环境构建与启动
```bash
npm run build
npm start
```

---

## 项目结构

```text
├── src/
│   ├── components/        # React 前端界面组件 (图表、信号列表、统计看板等)
│   ├── server/            # 后端核心服务 (币安流、合约逻辑、评分引擎、Firestore 同步)
│   ├── types/             # 核心 TypeScript 类型定义
│   ├── App.tsx            # 主应用根组件
│   └── main.tsx           # React 入口
├── data/                  # 本地数据缓存与 SQLite 存储
├── public/                # 静态资源与工程压缩包
├── server.ts              # 全栈 Express + Socket.IO + Vite 入口服务
├── firebase-applet-config.json # Firebase 客户端配置
├── firestore.rules        # Firestore 安全规则
├── firebase-blueprint.json# 数据实体模式说明
├── package.json           # 项目配置与脚本
└── tsconfig.json          # TypeScript 编译配置
```
