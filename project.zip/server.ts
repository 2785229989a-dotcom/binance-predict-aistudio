import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { Server as SocketIOServer } from 'socket.io';
import { BinanceManager } from './src/server/binance.js';
import { ContractManager } from './src/server/contractManager.js';
import { predictionDiagnostics } from './src/server/predictionDiagnostics.js';
import { opportunityEngine } from './src/server/opportunityEngine.js';
import { runBacktest, runModelExam } from './src/server/backtest.js';
import { CloudPersistenceManager } from './src/server/cloudPersistence.js';
import { BacktestParams, DurationType, SymbolType } from './src/types/market.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const io = new SocketIOServer(server, {
    cors: { origin: '*' },
    transports: ['websocket', 'polling'],
  });

  const PORT = 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  app.use(express.json());

  // Enable CORS for cross-environment / multi-device access
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // Instantiate Managers
  const binance = new BinanceManager();
  const contracts = new ContractManager();
  const cloudPersistence = new CloudPersistenceManager(contracts, io);
  cloudPersistence.startSyncLoop(8000);

  await binance.start();

  // Standard Health Check Endpoints: /health, /healthz, /api/health
  const healthHandler = (req: express.Request, res: express.Response) => {
    const status = binance.getStatus();
    res.json({
      status: 'ok',
      uptime: Math.round(process.uptime()),
      timestamp: Date.now(),
      service: 'binance-10m-event-contract-workbench',
      binance: {
        wsConnected: status.wsConnected,
        btcPrice: status.btcPrice,
        ethPrice: status.ethPrice,
        latencyMs: status.btcLatencyMs,
        isRealData: status.isRealData,
      },
      activeRounds: {
        BTCUSDT: contracts.getActiveRound('BTCUSDT')?.roundId,
        ETHUSDT: contracts.getActiveRound('ETHUSDT')?.roundId,
      },
    });
  };

  app.get('/health', healthHandler);
  app.get('/healthz', healthHandler);
  app.get('/api/health', healthHandler);

  // Project Zip Package Download Endpoints
  const downloadZipHandler = (req: express.Request, res: express.Response) => {
    const candidates = [
      path.resolve(__dirname, 'project.zip'),
      path.resolve(__dirname, 'public', 'project.zip'),
      path.resolve(__dirname, 'dist', 'project.zip'),
    ];
    const zipPath = candidates.find((p) => fs.existsSync(p));
    if (zipPath) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="project.zip"');
      return res.sendFile(zipPath);
    }
    return res.status(404).json({ error: 'project.zip not found' });
  };

  app.get('/project.zip', downloadZipHandler);
  app.get('/api/download-project', downloadZipHandler);

  // REST API Routes
  app.get('/api/market/:symbol', (req, res) => {
    const symbol = (req.params.symbol?.toUpperCase() || 'BTCUSDT') as SymbolType;
    if (symbol !== 'BTCUSDT' && symbol !== 'ETHUSDT') {
      res.status(400).json({ error: 'Unsupported symbol. Use BTCUSDT or ETHUSDT.' });
      return;
    }
    const currentRound = contracts.getActiveRound(symbol);
    const snapshot = binance.getSnapshot(symbol, currentRound);
    res.json(snapshot);
  });

  // Real-time Ticker Price Proxy (for fallback when browser direct Binance REST is blocked)
  app.get('/api/ticker/price', async (req, res) => {
    const symbol = ((req.query.symbol as string) || 'BTCUSDT').toUpperCase();
    const urls = [
      `https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`,
      `https://data-api.binance.vision/api/v3/ticker/price?symbol=${symbol}`,
      `https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol}`,
    ];
    for (const url of urls) {
      try {
        const resp = await fetch(url, { signal: AbortSignal.timeout(2500) });
        if (resp.ok) {
          const data = await resp.json();
          return res.json(data);
        }
      } catch {}
    }
    const snap = binance.getSnapshot(symbol as SymbolType, contracts.getActiveRound(symbol as SymbolType));
    return res.json({ symbol, price: String(snap.price) });
  });

  // 24hr Ticker Stats Proxy
  app.get('/api/ticker/24hr', async (req, res) => {
    const symbol = ((req.query.symbol as string) || 'BTCUSDT').toUpperCase();
    const urls = [
      `https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol}`,
      `https://data-api.binance.vision/api/v3/ticker/24hr?symbol=${symbol}`,
    ];
    for (const url of urls) {
      try {
        const resp = await fetch(url, { signal: AbortSignal.timeout(2500) });
        if (resp.ok) {
          const data = await resp.json();
          return res.json(data);
        }
      } catch {}
    }
    const snap = binance.getSnapshot(symbol as SymbolType, contracts.getActiveRound(symbol as SymbolType));
    return res.json({
      symbol,
      lastPrice: String(snap.price),
      highPrice: String(snap.high24h),
      lowPrice: String(snap.low24h),
      volume: String(snap.volume24h),
      priceChange: String(snap.priceChange24h),
      priceChangePercent: String(snap.priceChangePercent24h),
    });
  });

  // Full Binance Candlestick History API (币安实盘完整K线历史)
  app.get('/api/klines', async (req, res) => {
    const symbol = ((req.query.symbol as string) || 'BTCUSDT').toUpperCase();
    const interval = (req.query.interval as string) || '5m';
    const limit = Math.min(1000, Math.max(10, parseInt((req.query.limit as string) || '1000', 10)));

    const binanceHosts = [
      `https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
      `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
      `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
    ];

    for (const url of binanceHosts) {
      try {
        const resp = await fetch(url, {
          headers: { 'User-Agent': 'Mozilla/5.0' },
          signal: AbortSignal.timeout(4000),
        });
        if (resp.ok) {
          const raw = await resp.json();
          if (Array.isArray(raw) && raw.length > 0) {
            const klines = raw.map((k: any) => ({
              time: Math.floor(Number(k[0]) / 1000), // in seconds
              open: parseFloat(k[1]),
              high: parseFloat(k[2]),
              low: parseFloat(k[3]),
              close: parseFloat(k[4]),
              volume: parseFloat(k[5]),
              quoteVolume: parseFloat(k[7]),
            }));
            return res.json({ symbol, interval, klines });
          }
        }
      } catch (err) {
        // try next host
      }
    }

    // Local fallback
    const fallbackKlines = binance.getHistoricalKlines(symbol as SymbolType);
    const klines = fallbackKlines.map((k) => ({
      time: Math.floor(k.time / 1000),
      open: k.open,
      high: k.high,
      low: k.low,
      close: k.close,
      volume: k.volume,
      quoteVolume: k.quoteVolume,
    }));
    res.json({ symbol, interval, klines });
  });

  app.get('/api/contracts/current', (req, res) => {
    res.json({
      BTCUSDT: contracts.getActiveRound('BTCUSDT'),
      ETHUSDT: contracts.getActiveRound('ETHUSDT'),
    });
  });

  app.get('/api/contracts/history', (req, res) => {
    res.json(contracts.getRoundHistory());
  });

  // Signal Orders REST API (自动生成的预测信号订单)
  app.get('/api/signal-orders', (req, res) => {
    res.json({
      orders: contracts.getSignalOrders(),
      stats: contracts.getSignalOrderStats(),
      todayStats: contracts.getTodayStats(),
      activeOrders: contracts.getActiveSignalOrders(),
    });
  });

  // 今日真实统计与订单接口 (Asia/Shanghai)
  app.get('/api/signals/today', (req, res) => {
    res.json({
      date: contracts.getCurrentShanghaiDate(),
      todayStats: contracts.getTodayStats(),
      orders: contracts.getTodaySignals(),
      activeOrders: contracts.getActiveSignalOrders(),
    });
  });

  // 历史每日统计归档接口 (Daily Archives)
  app.get('/api/signals/daily-archives', (req, res) => {
    res.json({
      currentDate: contracts.getCurrentShanghaiDate(),
      todayStats: contracts.getTodayStats(),
      archives: contracts.getAllDailyArchives(),
    });
  });

  // 按日期查询历史信号列表
  app.get('/api/signals/by-date', (req, res) => {
    const dateStr = (req.query.date as string) || contracts.getCurrentShanghaiDate();
    res.json({
      date: dateStr,
      orders: contracts.getSignalsByDate(dateStr),
    });
  });

  app.get('/api/signal-orders/active', (req, res) => {
    res.json({
      activeOrders: contracts.getActiveSignalOrders(),
    });
  });

  app.get('/api/signal-orders/stats', (req, res) => {
    res.json(contracts.getSignalOrderStats());
  });

  // Backward-compatible signals route
  app.get('/api/signals', (req, res) => {
    const orders = contracts.getSignalOrders();
    const stats = contracts.getSignalOrderStats();
    res.json({
      signals: orders,
      stats,
      todayStats: contracts.getTodayStats(),
    });
  });

  // 清零重置所有历史交易与信号订单 (响应用户指令)
  app.post('/api/signals/reset', async (req, res) => {
    await contracts.clearAllRecords();
    io.emit('today_stats_updated', contracts.getTodayStats());
    io.emit('daily_archives_updated', contracts.getAllDailyArchives());
    io.emit('signal_stats_updated', contracts.getSignalOrderStats());
    io.emit('signals_cleared');
    res.json({ success: true, message: '历史交易与信号记录已全部清零重置完毕' });
  });

  // 多端/多环境中心化同步写入接口 (Cross-Client & Cross-Environment Sync)
  app.post('/api/signals/sync', (req, res) => {
    const { orders } = req.body;
    if (!Array.isArray(orders)) {
      return res.status(400).json({ error: 'orders 必须为数组格式' });
    }
    const result = contracts.mergeIncomingSignals(orders);
    if (result.added > 0 || result.updated > 0) {
      io.emit('signal_orders_entered', contracts.getActiveSignalOrders());
      io.emit('signal_stats_updated', contracts.getSignalOrderStats());
      io.emit('today_stats_updated', contracts.getTodayStats());
      io.emit('daily_archives_updated', contracts.getAllDailyArchives());
    }
    res.json({
      success: true,
      added: result.added,
      updated: result.updated,
      total: contracts.getSignalOrders().length,
      stats: contracts.getSignalOrderStats(),
      todayStats: contracts.getTodayStats(),
    });
  });

  // 云端同步服务状态查询
  app.get('/api/cloud-sync/status', (req, res) => {
    res.json(cloudPersistence.getStatus());
  });

  // 开单信号诊断模式接口 (Live Candidates & 14-condition Checklist & Opportunity Pool)
  app.get('/api/diagnostics/live', (req, res) => {
    const btcRound = contracts.getActiveRound('BTCUSDT');
    const ethRound = contracts.getActiveRound('ETHUSDT');
    const snapshots = binance.getBothSnapshots(btcRound, ethRound);
    const activeOrders = contracts.getActiveSignalOrders();
    const historicalOrders = contracts.getSignalOrders();
    const durations: DurationType[] = ['10m', '30m', '1h', '1d'];

    const poolResult = opportunityEngine.evaluateOpportunityPool(
      snapshots,
      activeOrders,
      historicalOrders
    );

    const candidates: Record<SymbolType, Record<DurationType, any>> = {
      BTCUSDT: {} as any,
      ETHUSDT: {} as any,
    };
    const dataHealth: Record<SymbolType, any> = {
      BTCUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.BTCUSDT),
      ETHUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.ETHUSDT),
    };

    (['BTCUSDT', 'ETHUSDT'] as SymbolType[]).forEach((sym) => {
      const snap = snapshots[sym];
      durations.forEach((dur) => {
        candidates[sym][dur] = predictionDiagnostics.evaluateCandidateDiagnostic(
          snap,
          dur,
          activeOrders,
          poolResult
        );
      });
    });

    res.json({
      timestamp: Date.now(),
      candidates,
      dataHealth,
      stats100: predictionDiagnostics.getStats100(),
      opportunityPool: poolResult,
    });
  });

  // 全市场机会池接口 (Opportunity Pool & Ranking)
  app.get('/api/opportunity-pool', (req, res) => {
    const btcRound = contracts.getActiveRound('BTCUSDT');
    const ethRound = contracts.getActiveRound('ETHUSDT');
    const snapshots = binance.getBothSnapshots(btcRound, ethRound);
    const activeOrders = contracts.getActiveSignalOrders();
    const historicalOrders = contracts.getSignalOrders();
    const poolResult = opportunityEngine.evaluateOpportunityPool(
      snapshots,
      activeOrders,
      historicalOrders
    );
    res.json(poolResult);
  });

  // 最近 100 次预测过滤统计接口
  app.get('/api/diagnostics/stats', (req, res) => {
    res.json(predictionDiagnostics.getStats100());
  });

  app.get('/api/trades', (req, res) => {
    const trades = contracts.getTrades();
    const balance = contracts.getPaperBalance();
    const settled = trades.filter((t) => t.status !== 'ACTIVE' && t.status !== 'PENDING_OPEN');
    const wins = settled.filter((t) => t.status === 'WON').length;
    const losses = settled.filter((t) => t.status === 'LOST').length;
    const winRate = wins + losses > 0 ? (wins / (wins + losses)) * 100 : 0;
    const totalPnl = Number((balance - 10000).toFixed(2));

    res.json({
      balance,
      initialBalance: 10000,
      totalPnl,
      winRate: Number(winRate.toFixed(1)),
      totalTrades: trades.length,
      trades,
    });
  });

  app.post('/api/trade/place', (req, res) => {
    const { symbol, direction, stake, duration, payoutRatio, modelProb, signalId } = req.body;
    if (!symbol || !direction || !stake) {
      res.status(400).json({ error: '缺少必填下单参数 (symbol, direction, stake)' });
      return;
    }
    const currentRound = contracts.getActiveRound(symbol as SymbolType);
    const result = contracts.placePaperTrade(
      symbol as SymbolType,
      direction as 'UP' | 'DOWN',
      parseFloat(stake),
      duration || '10m',
      payoutRatio ? parseFloat(payoutRatio) : undefined,
      modelProb ? parseFloat(modelProb) : 50,
      currentRound?.currentPrice,
      signalId
    );
    if (!result.success) {
      res.status(400).json(result);
      return;
    }
    io.emit('trade_placed', result);
    res.json(result);
  });

  app.post('/api/trade/reset', (req, res) => {
    const initialBalance = req.body.initialBalance ? parseFloat(req.body.initialBalance) : 10000;
    contracts.resetPaperTrading(initialBalance);
    io.emit('trade_reset', { balance: initialBalance });
    res.json({ success: true, balance: initialBalance });
  });

  app.post('/api/backtest', async (req, res) => {
    const params: BacktestParams = {
      symbol: (req.body.symbol || 'BTCUSDT') as SymbolType,
      days: parseInt(req.body.days || '3', 10),
      threshold: parseInt(req.body.threshold || '30', 10),
      stakePerTrade: parseFloat(req.body.stakePerTrade || '100'),
      payoutRatio: parseFloat(req.body.payoutRatio || '1.90'),
      strikeBuffer: parseFloat(req.body.strikeBuffer || '0'),
      ofiWeight: parseFloat(req.body.ofiWeight ?? 0.22),
      cvdWeight: parseFloat(req.body.cvdWeight ?? 0.22),
      depthWeight: parseFloat(req.body.depthWeight ?? 0.18),
      momentumWeight: parseFloat(req.body.momentumWeight ?? 0.14),
      multiTfWeight: parseFloat(req.body.multiTfWeight ?? 0.14),
      requireTrendAlignment: req.body.requireTrendAlignment ?? true,
    };

    const liveKlines = binance.getHistoricalKlines(params.symbol);
    try {
      const result = await runBacktest(params, liveKlines);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Model Exam API endpoint (模型考试与 Walk-Forward 验证)
  app.post('/api/model-exam', async (req, res) => {
    const symbol = (req.body.symbol || 'BTCUSDT') as SymbolType;
    const liveKlines = binance.getHistoricalKlines(symbol);
    try {
      const examResult = await runModelExam(symbol, liveKlines);
      res.json(examResult);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Background ticker and signal calculation loop (1000ms real-time tick, 15s opportunity engine scan)
  let lastOpportunityScanTime = 0;
  let cachedPoolResult: any = null;
  let cachedDiagnostics: any = null;

  setInterval(() => {
    const btcRound = contracts.getActiveRound('BTCUSDT');
    const ethRound = contracts.getActiveRound('ETHUSDT');

    const snapshots = binance.getBothSnapshots(btcRound, ethRound);

    // Update contract round prices & tick 10m countdown
    contracts.updatePriceAndTick(
      'BTCUSDT',
      snapshots.BTCUSDT.price,
      snapshots.BTCUSDT.currentRound.upOdds,
      snapshots.BTCUSDT.currentRound.downOdds
    );
    contracts.updatePriceAndTick(
      'ETHUSDT',
      snapshots.ETHUSDT.price,
      snapshots.ETHUSDT.currentRound.upOdds,
      snapshots.ETHUSDT.currentRound.downOdds
    );

    // 1. Tick signal orders for T+1s entry locking & expiration settlement
    const { entered, settled, dailyReset, currentShanghaiDate } = contracts.tickSignalOrders({
      BTCUSDT: snapshots.BTCUSDT.price,
      ETHUSDT: snapshots.ETHUSDT.price,
    });

    if (dailyReset) {
      io.emit('daily_reset', {
        date: currentShanghaiDate,
        todayStats: contracts.getTodayStats(),
      });
      io.emit('daily_archives_updated', contracts.getAllDailyArchives());
    }

    if (entered.length > 0) {
      io.emit('signal_orders_entered', entered);
    }
    if (settled.length > 0) {
      io.emit('signal_orders_settled', settled);
      io.emit('signal_stats_updated', contracts.getSignalOrderStats());
      io.emit('today_stats_updated', contracts.getTodayStats());
      io.emit('daily_archives_updated', contracts.getAllDailyArchives());
    }

    // 2. Evaluate all 8 candidates through OpportunityEngine every 15 seconds (Pipeline Stage 1 to 8)
    const now = Date.now();
    const durations: DurationType[] = ['10m', '30m', '1h', '1d'];
    const activeSignalOrders = contracts.getActiveSignalOrders();
    const historicalOrders = contracts.getSignalOrders();

    const shouldRun15sScan = now - lastOpportunityScanTime >= 15000 || !cachedPoolResult;
    if (shouldRun15sScan) {
      lastOpportunityScanTime = now;
      cachedPoolResult = opportunityEngine.evaluateOpportunityPool(
        snapshots,
        activeSignalOrders,
        historicalOrders
      );

      // 3. Phase 3 Execution: Only create orders for candidates approved by the Opportunity Engine
      for (const qualifiedCand of cachedPoolResult.qualifiedSignalsToOpen) {
        const snap = snapshots[qualifiedCand.symbol as SymbolType];
        const pred = snap.predictions?.[qualifiedCand.duration as DurationType] || snap.prediction;
        const newOrder = contracts.createOrderFromOpportunity(qualifiedCand, snap.price, pred);
        if (newOrder && now - newOrder.signalTime < 2500) {
          io.emit('signal_order_created', newOrder);
          io.emit('today_stats_updated', contracts.getTodayStats());
          io.emit('daily_archives_updated', contracts.getAllDailyArchives());
          // 异步向对端环境（如 ais-pre / ais-dev）推送新信号
          cloudPersistence.broadcastOrderToPeers(newOrder).catch(() => {});
        }
      }

      // 4. Update Candidate Signal Diagnostics with Opportunity Pool context
      const candidates: Record<SymbolType, Record<DurationType, any>> = {
        BTCUSDT: {} as any,
        ETHUSDT: {} as any,
      };
      const dataHealth: Record<SymbolType, any> = {
        BTCUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.BTCUSDT),
        ETHUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.ETHUSDT),
      };

      (['BTCUSDT', 'ETHUSDT'] as SymbolType[]).forEach((sym) => {
        const snap = snapshots[sym];
        durations.forEach((dur) => {
          const diag = predictionDiagnostics.evaluateCandidateDiagnostic(
            snap,
            dur,
            activeSignalOrders,
            cachedPoolResult
          );
          candidates[sym][dur] = diag;

          const wasCreatedForThis = cachedPoolResult.qualifiedSignalsToOpen.some(
            (c: any) => c.symbol === sym && c.duration === dur
          );
          predictionDiagnostics.recordEvaluation(diag, wasCreatedForThis);
        });
      });

      const stats100 = predictionDiagnostics.getStats100();
      cachedDiagnostics = {
        timestamp: now,
        candidates,
        dataHealth,
        stats100,
        opportunityPool: cachedPoolResult,
      };
    }

    const diagnostics = cachedDiagnostics || {
      timestamp: now,
      candidates: { BTCUSDT: {}, ETHUSDT: {} },
      dataHealth: {
        BTCUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.BTCUSDT),
        ETHUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.ETHUSDT),
      },
      stats100: predictionDiagnostics.getStats100(),
      opportunityPool: cachedPoolResult,
    };

    // Broadcast live snapshot, active signal orders, stats, and diagnostics to all connected clients
    const signalStats = contracts.getSignalOrderStats();
    const todayStats = contracts.getTodayStats();
    const dailyArchives = contracts.getAllDailyArchives();
    const allSignalOrders = contracts.getSignalOrders();

    io.emit('market_update', {
      BTCUSDT: snapshots.BTCUSDT,
      ETHUSDT: snapshots.ETHUSDT,
      activeSignalOrders,
      signalOrders: allSignalOrders,
      signalStats,
      todayStats,
      dailyArchives,
      currentShanghaiDate,
      diagnostics,
      timestamp: now,
    });
  }, 1000);

  // Socket.io connection handling
  io.on('connection', (socket) => {
    const btcRound = contracts.getActiveRound('BTCUSDT');
    const ethRound = contracts.getActiveRound('ETHUSDT');
    const snapshots = binance.getBothSnapshots(btcRound, ethRound);
    const activeOrders = contracts.getActiveSignalOrders();
    const durations: DurationType[] = ['10m', '30m', '1h', '1d'];

    const initialCandidates: Record<SymbolType, Record<DurationType, any>> = {
      BTCUSDT: {} as any,
      ETHUSDT: {} as any,
    };
    const initialDataHealth: Record<SymbolType, any> = {
      BTCUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.BTCUSDT),
      ETHUSDT: predictionDiagnostics.checkDataFeedHealth(snapshots.ETHUSDT),
    };

    (['BTCUSDT', 'ETHUSDT'] as SymbolType[]).forEach((sym) => {
      const snap = snapshots[sym];
      durations.forEach((dur) => {
        initialCandidates[sym][dur] = predictionDiagnostics.evaluateCandidateDiagnostic(snap, dur, activeOrders);
      });
    });

    socket.emit('market_init', {
      BTCUSDT: snapshots.BTCUSDT,
      ETHUSDT: snapshots.ETHUSDT,
      trades: contracts.getTrades(),
      balance: contracts.getPaperBalance(),
      signals: contracts.getSignalOrders(),
      signalOrders: contracts.getSignalOrders(),
      activeSignalOrders: activeOrders,
      signalStats: contracts.getSignalOrderStats(),
      todayStats: contracts.getTodayStats(),
      dailyArchives: contracts.getAllDailyArchives(),
      currentShanghaiDate: contracts.getCurrentShanghaiDate(),
      diagnostics: {
        timestamp: Date.now(),
        candidates: initialCandidates,
        dataHealth: initialDataHealth,
        stats100: predictionDiagnostics.getStats100(),
      },
    });
  });

  // Mount Vite middleware in development or serve static in production
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    const indexPath = path.resolve(distPath, 'index.html');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(200).send('<!doctype html><html><head><title>Binance Workbench</title></head><body><div id="root">Loading Binance Workbench...</div></body></html>');
      }
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Binance 10m Event Contract Workbench running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Server] Fatal startup error:', err);
  process.exit(1);
});
