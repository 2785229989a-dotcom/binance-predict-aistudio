import React, { useState } from 'react';
import { BacktestParams, BacktestResult, SymbolType } from '../types/market.js';
import {
  Play,
  RotateCcw,
  Download,
  TrendingUp,
  Percent,
  Sliders,
  AlertCircle,
  ShieldCheck,
  PauseCircle,
} from 'lucide-react';

interface BacktestPanelProps {
  currentSymbol: SymbolType;
}

export const BacktestPanel: React.FC<BacktestPanelProps> = ({ currentSymbol }) => {
  const [params, setParams] = useState<BacktestParams>({
    symbol: currentSymbol,
    days: 3,
    threshold: 30,
    stakePerTrade: 100,
    payoutRatio: 1.90,
    strikeBuffer: 0,
    ofiWeight: 0.22,
    cvdWeight: 0.22,
    depthWeight: 0.18,
    momentumWeight: 0.14,
    multiTfWeight: 0.14,
    requireTrendAlignment: true,
  });

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runTest = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/backtest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      if (!res.ok) {
        throw new Error(`回测请求失败: ${res.statusText}`);
      }
      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || '回测运行发生异常');
    } finally {
      setIsLoading(false);
    }
  };

  const exportCSV = () => {
    if (!result || !result.trades || result.trades.length === 0) return;
    const headers = ['时间', '标的', '方向', '评分', '开仓基准价P0', '结算价P10', '结果', '投注额', '净盈亏', '累计资金'];
    const rows = result.trades.map((t) => [
      new Date(t.time).toISOString(),
      t.symbol,
      t.direction,
      t.score,
      t.entryPrice,
      t.exitPrice,
      t.outcome,
      t.stake,
      t.pnl,
      t.cumProfit,
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `backtest_${params.symbol}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const curve = result?.equityCurve || [];
  const minEquity = curve.length > 0 ? Math.min(...curve.map((c) => c.equity)) * 0.98 : 9500;
  const maxEquity = curve.length > 0 ? Math.max(...curve.map((c) => c.equity)) * 1.02 : 11000;
  const equityRange = maxEquity - minEquity || 1;
  const svgWidth = 720;
  const svgHeight = 190;

  return (
    <div className="space-y-6">
      {/* Parameter Settings Card */}
      <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-zinc-800 gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sliders className="h-4 w-4 text-amber-400" />
              10分钟事件合约策略量化回测实验室
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              严格时序顺序回测，零未来数据泄漏（Zero Lookahead Bias），以信号产生瞬间真实 P0 锁定基准价
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={runTest}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs flex items-center gap-1.5 transition shadow-lg shadow-amber-400/20 disabled:opacity-50"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              {isLoading ? '正在进行无未来函数回测...' : '执行策略回测'}
            </button>
          </div>
        </div>

        {/* Inputs Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
          <div>
            <label className="block text-[11px] font-medium text-zinc-400 mb-1">
              测试交易标的
            </label>
            <select
              value={params.symbol}
              onChange={(e) => setParams({ ...params, symbol: e.target.value as any })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
            >
              <option value="BTCUSDT">BTCUSDT</option>
              <option value="ETHUSDT">ETHUSDT</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-zinc-400 mb-1">
              回测历史周期 (天数)
            </label>
            <select
              value={params.days}
              onChange={(e) => setParams({ ...params, days: Number(e.target.value) })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
            >
              <option value="1">最近 1 天 (快速微观验证)</option>
              <option value="3">最近 3 天 (深度检验)</option>
              <option value="7">最近 7 天 (完整周期)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-zinc-400 mb-1">
              信号触发阈值 (|Score| ≥)
            </label>
            <input
              type="number"
              min="20"
              max="70"
              value={params.threshold}
              onChange={(e) => setParams({ ...params, threshold: Number(e.target.value) })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs font-mono text-zinc-200 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="block text-[11px] font-medium text-zinc-400 mb-1">
              行权点差缓冲 (Buffer USD)
            </label>
            <input
              type="number"
              step="0.5"
              value={params.strikeBuffer}
              onChange={(e) => setParams({ ...params, strikeBuffer: Number(e.target.value) })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs font-mono text-zinc-200 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Weights Sliders */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-zinc-800/80 mt-4 text-xs">
          <div>
            <div className="flex justify-between text-zinc-400 mb-1">
              <span>OFI 订单流权重:</span>
              <span className="font-mono text-amber-400">{(params.ofiWeight * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.5"
              step="0.05"
              value={params.ofiWeight}
              onChange={(e) => setParams({ ...params, ofiWeight: parseFloat(e.target.value) })}
              className="w-full accent-amber-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-zinc-400 mb-1">
              <span>CVD 斜率权重:</span>
              <span className="font-mono text-amber-400">{(params.cvdWeight * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.5"
              step="0.05"
              value={params.cvdWeight}
              onChange={(e) => setParams({ ...params, cvdWeight: parseFloat(e.target.value) })}
              className="w-full accent-amber-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-zinc-400 mb-1">
              <span>盘口深度权重:</span>
              <span className="font-mono text-amber-400">{(params.depthWeight * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.5"
              step="0.05"
              value={params.depthWeight}
              onChange={(e) => setParams({ ...params, depthWeight: parseFloat(e.target.value) })}
              className="w-full accent-amber-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-zinc-400 mb-1">
              <span>多周期趋势一致性约束:</span>
              <span className="font-mono text-emerald-400">
                {params.requireTrendAlignment ? '开启' : '关闭'}
              </span>
            </div>
            <label className="flex items-center gap-2 cursor-pointer mt-1 text-zinc-300">
              <input
                type="checkbox"
                checked={params.requireTrendAlignment}
                onChange={(e) => setParams({ ...params, requireTrendAlignment: e.target.checked })}
                className="rounded accent-amber-400 h-4 w-4"
              />
              <span>多周期冲突时强制 WAIT</span>
            </label>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
          <AlertCircle className="h-4 w-4" />
          <span>{error}</span>
        </div>
      )}

      {/* Results View */}
      {result && (
        <div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">总体胜率</span>
              <div className="font-mono text-xl font-black text-emerald-400 mt-1">
                {result.winRate}%
              </div>
              <div className="text-[10px] text-zinc-500">{result.wins} 胜 / {result.losses} 负</div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">净收益</span>
              <div
                className={`font-mono text-xl font-black mt-1 ${
                  result.totalProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {result.totalProfit >= 0 ? `+$${result.totalProfit}` : `-$${Math.abs(result.totalProfit)}`}
              </div>
              <div className="text-[10px] text-zinc-500">ROI: {result.roi}%</div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">有效交易 / 信号</span>
              <div className="font-mono text-xl font-black text-white mt-1">
                {result.totalTrades}
              </div>
              <div className="text-[10px] text-zinc-500">总评估: {result.totalSignals}</div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">WAIT 过滤数</span>
              <div className="font-mono text-xl font-black text-amber-400 mt-1">
                {result.waitCount}
              </div>
              <div className="text-[10px] text-zinc-500">
                占比 {Math.round((result.waitCount / (result.totalSignals || 1)) * 100)}%
              </div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">盈亏比 (PF)</span>
              <div className="font-mono text-xl font-black text-amber-300 mt-1">
                {result.profitFactor}
              </div>
              <div className="text-[10px] text-zinc-500">毛利 / 毛损</div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">最大回撤</span>
              <div className="font-mono text-xl font-black text-rose-400 mt-1">
                -{result.maxDrawdown}%
              </div>
              <div className="text-[10px] text-zinc-500">峰值净值回撤</div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">连续盈利 / 亏损</span>
              <div className="font-mono text-sm font-bold text-white mt-1">
                连胜: <span className="text-emerald-400">{result.maxConsecutiveWins}</span>
              </div>
              <div className="font-mono text-sm font-bold text-white">
                连亏: <span className="text-rose-400">{result.maxConsecutiveLosses}</span>
              </div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">夏普比率</span>
              <div className="font-mono text-xl font-black text-sky-400 mt-1">
                {result.sharpeRatio}
              </div>
              <div className="text-[10px] text-zinc-500">年化风险收益比</div>
            </div>
          </div>

          {/* Equity Curve */}
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-400" />
                策略净值走势曲线 (Equity Curve)
              </h4>
              <button
                onClick={exportCSV}
                className="text-xs px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 flex items-center gap-1.5 transition"
              >
                <Download className="h-3 w-3" /> 导出回测流水 CSV
              </button>
            </div>

            <div className="pt-3">
              <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-[190px] bg-zinc-950 rounded-xl">
                {[0.2, 0.5, 0.8].map((ratio) => {
                  const y = svgHeight * ratio;
                  const eq = maxEquity - equityRange * ratio;
                  return (
                    <g key={ratio}>
                      <line x1="0" y1={y} x2={svgWidth} y2={y} stroke="#27272a" strokeDasharray="3 3" />
                      <text x={svgWidth - 5} y={y - 4} textAnchor="end" fill="#71717a" fontSize="9" fontFamily="monospace">
                        ${eq.toFixed(0)}
                      </text>
                    </g>
                  );
                })}

                {curve.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={curve
                      .map((pt, idx) => {
                        const x = (idx / (curve.length - 1)) * svgWidth;
                        const y = svgHeight - ((pt.equity - minEquity) / equityRange) * svgHeight;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                )}
              </svg>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
