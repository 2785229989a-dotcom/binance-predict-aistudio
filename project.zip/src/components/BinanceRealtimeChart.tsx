import React, { useEffect, useRef, useState, useMemo } from 'react';
import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickSeries,
  HistogramSeries,
  LineSeries,
  CrosshairMode,
  createSeriesMarkers,
  Time,
  ColorType,
  LineStyle,
} from 'lightweight-charts';
import {
  DurationType,
  MarketSnapshot,
  SignalOrder,
  SymbolType,
} from '../types/market.js';
import {
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle2,
  XCircle,
  MinusCircle,
  Activity,
  Maximize2,
  Minimize2,
  BookOpen,
  AlertCircle,
} from 'lucide-react';

interface BinanceRealtimeChartProps {
  symbol: SymbolType;
  snapshot: MarketSnapshot | null;
  activeDuration: DurationType;
  onChangeDuration: (dur: DurationType) => void;
  signalOrders?: SignalOrder[];
}

export const BinanceRealtimeChart: React.FC<BinanceRealtimeChartProps> = ({
  symbol,
  snapshot,
  activeDuration,
  onChangeDuration,
  signalOrders = [],
}) => {
  // Chart container ref
  const chartContainerRef = useRef<HTMLDivElement | null>(null);
  const chartApiRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const ma7SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const ma25SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const ma99SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const seriesMarkersRef = useRef<any>(null);
  const entryPriceLineRef = useRef<any>(null);

  // Timeframe for the Binance K-Line (1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 1d, 1w)
  const [klineInterval, setKlineInterval] = useState<
    '1m' | '3m' | '5m' | '15m' | '30m' | '1h' | '2h' | '4h' | '1d' | '1w'
  >('5m');
  const [showMA, setShowMA] = useState<boolean>(true);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(true);
  const [sideTab, setSideTab] = useState<'signal' | 'depth'>('signal');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Crosshair info display
  const [crosshairData, setCrosshairData] = useState<{
    time: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    changePercent: number;
  } | null>(null);

  // Clock for real-time countdown
  const [now, setNow] = useState<number>(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const currentPrice = snapshot?.price || 0;
  const p0 = snapshot?.currentRound?.lockPrice || currentPrice;

  // Active signal order for this symbol and duration
  const activeSignalOrder = useMemo(() => {
    return signalOrders.find(
      (s) =>
        s.symbol === symbol &&
        s.duration === activeDuration &&
        (s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY')
    );
  }, [signalOrders, symbol, activeDuration]);

  // Recent settled signal
  const recentSettledSignal = useMemo(() => {
    return signalOrders.find(
      (s) => s.symbol === symbol && s.duration === activeDuration && s.status === 'SETTLED'
    );
  }, [signalOrders, symbol, activeDuration]);

  // Active prediction from snapshot
  const pred =
    (snapshot?.predictions && snapshot.predictions[activeDuration]) ||
    snapshot?.prediction ||
    null;

  // Payout, Edge, and Probability metrics
  const payoutRatio =
    activeSignalOrder?.payoutRatio ??
    (pred?.payoutRatio !== undefined
      ? pred.payoutRatio
      : activeDuration === '10m'
      ? 0.8
      : 0.85);

  const breakEvenProb =
    activeSignalOrder?.breakEvenProb ??
    (pred?.breakEvenProb ?? Number(((100 / (100 + payoutRatio * 100)) * 100).toFixed(2)));

  const modelProb =
    activeSignalOrder?.modelProb ??
    (pred?.direction === 'UP'
      ? pred.upProb
      : pred?.direction === 'DOWN'
      ? pred.downProb
      : Math.max(pred?.upProb || 0, pred?.downProb || 0));

  const edge =
    activeSignalOrder?.edge ??
    (pred?.edge ?? Number((modelProb - breakEvenProb).toFixed(2)));

  const expectedValue =
    activeSignalOrder?.expectedValue ??
    (pred?.expectedValue ??
      Number(
        ((modelProb / 100) * (100 * payoutRatio) -
          ((100 - modelProb) / 100) * 100).toFixed(2)
      ));

  const isUp = activeSignalOrder ? activeSignalOrder.direction === 'UP' : pred?.direction === 'UP';
  const isDown = activeSignalOrder ? activeSignalOrder.direction === 'DOWN' : pred?.direction === 'DOWN';
  const isWait = !activeSignalOrder && (!pred || pred.direction === 'WAIT');

  const durationLabel =
    activeDuration === '10m'
      ? '10分钟'
      : activeDuration === '30m'
      ? '30分钟'
      : activeDuration === '1h'
      ? '1小时'
      : '1天';

  // Entry Price & Price Delta Calculation
  const entryPrice = activeSignalOrder?.entryPriceIndex ?? p0;
  const priceDelta = currentPrice - entryPrice;
  const deltaSign = priceDelta >= 0 ? '+' : '';
  const isFavorable =
    activeSignalOrder &&
    ((activeSignalOrder.direction === 'UP' && priceDelta > 0) ||
      (activeSignalOrder.direction === 'DOWN' && priceDelta < 0));

  // Real-time countdown
  const remainingSeconds = activeSignalOrder
    ? activeSignalOrder.status === 'WAITING_ENTRY'
      ? Math.max(0, Math.ceil((activeSignalOrder.entryTime - now) / 1000))
      : Math.max(0, Math.floor((activeSignalOrder.expiryTime - now) / 1000))
    : 0;

  const remMin = Math.floor(remainingSeconds / 60);
  const remSec = remainingSeconds % 60;
  const countdownFormatted = `${String(remMin).padStart(2, '0')}:${String(remSec).padStart(2, '0')}`;

  // Helper to calculate Moving Averages
  const calculateMA = (data: { time: Time; close: number }[], period: number) => {
    const maData: { time: Time; value: number }[] = [];
    for (let i = period - 1; i < data.length; i++) {
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += data[i - j].close;
      }
      maData.push({
        time: data[i].time,
        value: Number((sum / period).toFixed(2)),
      });
    }
    return maData;
  };

  // Helper for responsive chart height
  const getResponsiveHeight = () => {
    if (isFullscreen) return window.innerHeight - 150;
    if (typeof window !== 'undefined') {
      if (window.innerWidth < 640) return 280;
      if (window.innerWidth < 1024) return 360;
      return 450;
    }
    return 360;
  };

  // Initialize and build Lightweight-Charts instance
  useEffect(() => {
    if (!chartContainerRef.current) return;

    if (chartApiRef.current) {
      chartApiRef.current.remove();
      chartApiRef.current = null;
    }

    const container = chartContainerRef.current;
    const chartHeight = getResponsiveHeight();

    const chart = createChart(container, {
      width: container.clientWidth || 800,
      height: chartHeight,
      layout: {
        background: { type: ColorType.Solid, color: '#09090b' },
        textColor: '#a1a1aa',
        fontFamily: 'monospace, sans-serif',
      },
      grid: {
        vertLines: { color: '#18181b', style: LineStyle.Dotted },
        horzLines: { color: '#18181b', style: LineStyle.Dotted },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: '#52525b',
          width: 1,
          style: LineStyle.Dashed,
          labelBackgroundColor: '#27272a',
        },
        horzLine: {
          color: '#52525b',
          width: 1,
          style: LineStyle.Dashed,
          labelBackgroundColor: '#27272a',
        },
      },
      rightPriceScale: {
        borderColor: '#27272a',
        scaleMargins: {
          top: 0.1,
          bottom: 0.22,
        },
      },
      timeScale: {
        borderColor: '#27272a',
        timeVisible: true,
        secondsVisible: false,
      },
    });

    chartApiRef.current = chart;

    // 1. Candlestick Series (Binance Pro colors: #0ecb81 green / #f6465d red)
    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#0ecb81',
      downColor: '#f6465d',
      borderUpColor: '#0ecb81',
      borderDownColor: '#f6465d',
      wickUpColor: '#0ecb81',
      wickDownColor: '#f6465d',
    });
    candleSeriesRef.current = candleSeries;

    // 2. Volume Series (Histogram overlaid at bottom)
    const volumeSeries = chart.addSeries(HistogramSeries, {
      color: '#0ecb81',
      priceFormat: { type: 'volume' },
      priceScaleId: '', // Overlay
    });
    chart.priceScale('').applyOptions({
      scaleMargins: {
        top: 0.8,
        bottom: 0,
      },
    });
    volumeSeriesRef.current = volumeSeries;

    // 3. Moving Average Series (MA7, MA25, MA99)
    const ma7Series = chart.addSeries(LineSeries, {
      color: '#f59e0b',
      lineWidth: 1,
      crosshairMarkerVisible: false,
    });
    ma7SeriesRef.current = ma7Series;

    const ma25Series = chart.addSeries(LineSeries, {
      color: '#ec4899',
      lineWidth: 1,
      crosshairMarkerVisible: false,
    });
    ma25SeriesRef.current = ma25Series;

    const ma99Series = chart.addSeries(LineSeries, {
      color: '#8b5cf6',
      lineWidth: 1,
      crosshairMarkerVisible: false,
    });
    ma99SeriesRef.current = ma99Series;

    // 4. Crosshair Move Handler
    chart.subscribeCrosshairMove((param) => {
      if (
        param.time &&
        param.seriesData &&
        param.seriesData.get(candleSeries)
      ) {
        const bar: any = param.seriesData.get(candleSeries);
        const volBar: any = param.seriesData.get(volumeSeries);
        const open = bar.open || 0;
        const close = bar.close || 0;
        const changePct = open > 0 ? ((close - open) / open) * 100 : 0;
        const timeStr = typeof param.time === 'number'
          ? new Date(param.time * 1000).toLocaleString()
          : String(param.time);

        setCrosshairData({
          time: timeStr,
          open: bar.open,
          high: bar.high,
          low: bar.low,
          close: bar.close,
          volume: volBar?.value || 0,
          changePercent: Number(changePct.toFixed(2)),
        });
      } else {
        setCrosshairData(null);
      }
    });

    let isDisposed = false;
    // Resize Observer with responsive width & height
    const resizeObserver = new ResizeObserver((entries) => {
      if (isDisposed || !chartApiRef.current || !entries[0]) return;
      try {
        const { width } = entries[0].contentRect;
        if (width > 0) {
          const responsiveH = getResponsiveHeight();
          chartApiRef.current.applyOptions({ width, height: responsiveH });
        }
      } catch (e) {
        // Disposed chart guard
      }
    });
    resizeObserver.observe(container);

    return () => {
      isDisposed = true;
      resizeObserver.disconnect();
      if (seriesMarkersRef.current) {
        try {
          seriesMarkersRef.current.detach?.();
        } catch (e) {}
        seriesMarkersRef.current = null;
      }
      if (entryPriceLineRef.current && candleSeriesRef.current) {
        try {
          candleSeriesRef.current.removePriceLine(entryPriceLineRef.current);
        } catch (e) {}
        entryPriceLineRef.current = null;
      }
      candleSeriesRef.current = null;
      volumeSeriesRef.current = null;
      ma7SeriesRef.current = null;
      ma25SeriesRef.current = null;
      ma99SeriesRef.current = null;
      if (chartApiRef.current) {
        const chartToDestroy = chartApiRef.current;
        chartApiRef.current = null;
        try {
          chartToDestroy.remove();
        } catch (e) {
          // ignore
        }
      }
    };
  }, []);

  // Responsive resize on fullscreen toggle without destroying and rebuilding chart instance
  useEffect(() => {
    if (chartApiRef.current && chartContainerRef.current) {
      try {
        chartApiRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth || 800,
          height: getResponsiveHeight(),
        });
      } catch (e) {}
    }
  }, [isFullscreen]);

  // Fetch full Binance candlestick history (1000 bars) when symbol or timeframe changes
  useEffect(() => {
    let isCancelled = false;
    setIsLoadingHistory(true);

    const fetchKlines = async () => {
      try {
        const res = await fetch(
          `/api/klines?symbol=${symbol}&interval=${klineInterval}&limit=1000`
        );
        if (!res.ok) throw new Error('Fetch klines failed');
        const data = await res.json();
        if (isCancelled || !candleSeriesRef.current || !data.klines) return;

        const candles = data.klines.map((k: any) => ({
          time: k.time as Time,
          open: k.open,
          high: k.high,
          low: k.low,
          close: k.close,
        }));

        const volumes = data.klines.map((k: any) => ({
          time: k.time as Time,
          value: k.volume,
          color: k.close >= k.open ? '#0ecb8180' : '#f6465d80',
        }));

        try {
          if (candleSeriesRef.current && chartApiRef.current) {
            candleSeriesRef.current.setData(candles);
            volumeSeriesRef.current?.setData(volumes);

            // Update Moving Averages
            if (showMA) {
              ma7SeriesRef.current?.setData(calculateMA(candles, 7));
              ma25SeriesRef.current?.setData(calculateMA(candles, 25));
              ma99SeriesRef.current?.setData(calculateMA(candles, 99));
            }

            // Fit content
            chartApiRef.current?.timeScale().fitContent();
          }
        } catch (e) {
          // ignore disposed chart
        }
        setIsLoadingHistory(false);
      } catch (err) {
        console.warn('Error loading Binance klines:', err);
        setIsLoadingHistory(false);
      }
    };

    fetchKlines();

    return () => {
      isCancelled = true;
    };
  }, [symbol, klineInterval, showMA]);

  // Real-time tick update: updates the last candle on every incoming price tick
  useEffect(() => {
    if (!candleSeriesRef.current || !chartApiRef.current || currentPrice <= 0) return;

    const intervalMinutes =
      klineInterval === '1m'
        ? 1
        : klineInterval === '3m'
        ? 3
        : klineInterval === '5m'
        ? 5
        : klineInterval === '15m'
        ? 15
        : klineInterval === '30m'
        ? 30
        : klineInterval === '1h'
        ? 60
        : klineInterval === '2h'
        ? 120
        : klineInterval === '4h'
        ? 240
        : klineInterval === '1d'
        ? 1440
        : 10080;

    const intervalSeconds = intervalMinutes * 60;
    const currentBarTime = (Math.floor(Date.now() / 1000 / intervalSeconds) * intervalSeconds) as Time;

    try {
      candleSeriesRef.current.update({
        time: currentBarTime,
        open: snapshot?.recentKlines?.[snapshot.recentKlines.length - 1]?.open || currentPrice,
        high: Math.max(currentPrice, snapshot?.high24h || currentPrice),
        low: Math.min(currentPrice, snapshot?.low24h || currentPrice),
        close: currentPrice,
      });
    } catch (e) {
      // ignore
    }
  }, [currentPrice, snapshot, klineInterval]);

  // Update Series Markers (Signal Orders markers on the candlestick chart)
  useEffect(() => {
    if (!candleSeriesRef.current || !chartApiRef.current) return;

    const relevantSignals = signalOrders
      .filter((s) => s.symbol === symbol && s.duration === activeDuration)
      .slice(0, 40);

    const markers = relevantSignals.map((sig) => {
      const isUpSig = sig.direction === 'UP';
      const timeInSec = Math.floor((sig.signalTime || sig.createdAt) / 1000) as Time;

      // K线开单信号直接换成箭头：开多单红色箭头 (arrowUp)，空单绿色箭头 (arrowDown)
      return {
        time: timeInSec,
        position: isUpSig ? ('belowBar' as const) : ('aboveBar' as const),
        color: isUpSig ? '#ef4444' : '#10b981',
        shape: isUpSig ? ('arrowUp' as const) : ('arrowDown' as const),
        text: '',
        size: 2,
      };
    });

    try {
      if (seriesMarkersRef.current) {
        seriesMarkersRef.current.setMarkers(markers);
      } else {
        seriesMarkersRef.current = createSeriesMarkers(candleSeriesRef.current, markers);
      }
    } catch (e) {
      seriesMarkersRef.current = null;
    }
  }, [signalOrders, symbol, activeDuration]);

  // Update Entry Price Horizontal Line on Chart
  useEffect(() => {
    if (!candleSeriesRef.current || !chartApiRef.current) return;

    try {
      if (entryPriceLineRef.current) {
        candleSeriesRef.current.removePriceLine(entryPriceLineRef.current);
        entryPriceLineRef.current = null;
      }

      if (activeSignalOrder?.entryPriceIndex) {
        const isUpDir = activeSignalOrder.direction === 'UP';
        const pLine = candleSeriesRef.current.createPriceLine({
          price: activeSignalOrder.entryPriceIndex,
          color: isUpDir ? '#ef4444' : '#10b981',
          lineWidth: 1,
          lineStyle: LineStyle.Dashed,
          axisLabelVisible: true,
          title: `Entry: $${activeSignalOrder.entryPriceIndex.toFixed(1)} (剩 ${countdownFormatted})`,
        });
        entryPriceLineRef.current = pLine;
      }
    } catch (e) {
      entryPriceLineRef.current = null;
    }

    return () => {
      try {
        if (entryPriceLineRef.current && candleSeriesRef.current) {
          candleSeriesRef.current.removePriceLine(entryPriceLineRef.current);
          entryPriceLineRef.current = null;
        }
      } catch (e) {}
    };
  }, [activeSignalOrder, countdownFormatted]);

  // Recent Trades and Order Book entries
  const bids = snapshot?.orderBook?.bids?.slice(0, 8) || [];
  const asks = snapshot?.orderBook?.asks?.slice(0, 8) || [];
  const maxDepthQty = Math.max(
    ...bids.map((b) => b.total || b.quantity),
    ...asks.map((a) => a.total || a.quantity),
    1
  );

  return (
    <div
      className={`bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3 sm:p-5 shadow-2xl relative transition-all max-w-full overflow-x-hidden ${
        isFullscreen ? 'fixed inset-2 sm:inset-4 z-50 overflow-y-auto bg-zinc-950 p-4 sm:p-6' : ''
      }`}
    >
      {/* Top Bar: Binance Market Header with Live Stats & Timeframe Switcher */}
      <div className="flex flex-col gap-3 pb-3 border-b border-zinc-800/80">
        {/* Row 1: Symbol, Live Price, 24h Change, Fullscreen */}
        <div className="flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span
                className={`h-2.5 w-2.5 sm:h-3 sm:w-3 rounded-full ${
                  symbol === 'BTCUSDT' ? 'bg-amber-400' : 'bg-sky-400'
                } animate-pulse`}
              />
              <h2 className="text-lg sm:text-2xl font-black text-white tracking-tight font-mono">
                {symbol}
              </h2>
              <span className="text-[9px] sm:text-[10px] uppercase font-bold tracking-widest px-1.5 sm:px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 font-mono border border-zinc-700">
                币安实盘
              </span>
            </div>

            <div className="flex items-baseline gap-1.5 font-mono">
              <span className="text-lg sm:text-2xl font-black text-white">
                ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
              <span
                className={`text-[11px] sm:text-xs font-bold ${
                  (snapshot?.priceChangePercent24h || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {(snapshot?.priceChangePercent24h || 0) >= 0 ? '+' : ''}
                {snapshot?.priceChangePercent24h?.toFixed(2)}%
              </span>
            </div>
          </div>

          {/* Quick Actions (Fullscreen & Indicator Toggle) */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowMA(!showMA)}
              className={`min-h-[36px] px-2.5 py-1 rounded-xl text-xs font-mono font-bold transition border cursor-pointer ${
                showMA
                  ? 'bg-zinc-800 text-amber-300 border-zinc-700'
                  : 'bg-zinc-950 text-zinc-500 border-zinc-800 hover:text-zinc-300'
              }`}
              title="显示或隐藏 MA7, MA25, MA99 均线"
            >
              MA {showMA ? '开' : '关'}
            </button>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="min-h-[36px] min-w-[36px] p-2 rounded-xl border border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-white transition cursor-pointer flex items-center justify-center"
              title={isFullscreen ? '退出全屏' : '全屏看板模式'}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {/* Row 2: 24h High/Low/Volume Strip (Responsive grid on mobile, horizontal on desktop) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] sm:text-[11px] font-mono text-zinc-400 bg-zinc-950/70 p-2 sm:p-2.5 rounded-xl border border-zinc-800/80">
          <div>
            <span className="text-zinc-500 block text-[9px]">24h 最高</span>
            <strong className="text-zinc-200">
              ${snapshot?.high24h?.toLocaleString(undefined, { minimumFractionDigits: 2 }) || '---'}
            </strong>
          </div>
          <div>
            <span className="text-zinc-500 block text-[9px]">24h 最低</span>
            <strong className="text-zinc-200">
              ${snapshot?.low24h?.toLocaleString(undefined, { minimumFractionDigits: 2 }) || '---'}
            </strong>
          </div>
          <div>
            <span className="text-zinc-500 block text-[9px]">24h 成交额</span>
            <strong className="text-zinc-200">
              ${snapshot?.volume24h ? (snapshot.volume24h * currentPrice / 1000000).toFixed(1) + 'M' : '---'}
            </strong>
          </div>
          <div>
            <span className="text-zinc-500 block text-[9px]">资金费率</span>
            <span className="text-amber-300 font-bold">
              {snapshot?.fundingRate ? `${(snapshot.fundingRate * 100).toFixed(4)}%` : '0.0100%'}
            </span>
          </div>
        </div>

        {/* Row 3: Timeframe Bar & Contract Duration (Swipeable with 40px touch height) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
          {/* Timeframe Buttons: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 1d, 1w */}
          <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-xs font-mono overflow-x-auto no-scrollbar whitespace-nowrap">
            {(['1m', '3m', '5m', '15m', '30m', '1h', '2h', '4h', '1d', '1w'] as const).map((interval) => (
              <button
                key={interval}
                onClick={() => setKlineInterval(interval)}
                className={`min-h-[36px] px-2.5 py-1 rounded-lg font-bold transition cursor-pointer text-xs shrink-0 ${
                  klineInterval === interval
                    ? 'bg-amber-400 text-zinc-950 shadow-md font-black'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {interval}
              </button>
            ))}
          </div>

          {/* Event Contract Duration Selector */}
          <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-xl border border-amber-500/30 text-xs overflow-x-auto no-scrollbar whitespace-nowrap shrink-0">
            <span className="text-[10px] text-amber-400 font-bold font-sans pl-1 flex items-center gap-1">
              <Clock className="h-3 w-3" /> 合约:
            </span>
            {(
              [
                { id: '10m', label: '10m' },
                { id: '30m', label: '30m' },
                { id: '1h', label: '1h' },
                { id: '1d', label: '1d' },
              ] as const
            ).map((dur) => (
              <button
                key={dur.id}
                onClick={() => onChangeDuration(dur.id)}
                className={`min-h-[36px] px-2.5 py-1 rounded-lg font-bold text-[11px] font-mono transition cursor-pointer shrink-0 ${
                  activeDuration === dur.id
                    ? 'bg-amber-500 text-zinc-950 shadow-md font-black'
                    : 'text-zinc-400 hover:text-white'
                }`}
                title={`切换针对 ${dur.label} 的事件合约模型`}
              >
                {dur.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid: Candlestick Viewport (Left 8-9 cols) + Side Panel (Right 3-4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4 mt-3">
        {/* Candlestick Chart Viewport */}
        <div className="lg:col-span-8 xl:col-span-9 bg-zinc-950 rounded-xl p-2 sm:p-2.5 border border-zinc-800/80 relative flex flex-col justify-between overflow-hidden">
          {/* Top HUD: Crosshair or Latest Bar Data */}
          <div className="flex flex-wrap items-center justify-between text-[9px] sm:text-[10px] font-mono text-zinc-400 px-2 py-1.5 bg-zinc-900/70 rounded-lg mb-1 gap-1.5 sm:gap-2">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-3">
              {crosshairData ? (
                <>
                  <span className="text-zinc-300 font-bold">{crosshairData.time}</span>
                  <span>O: <strong className="text-zinc-200">{crosshairData.open}</strong></span>
                  <span>H: <strong className="text-emerald-400">{crosshairData.high}</strong></span>
                  <span>L: <strong className="text-rose-400">{crosshairData.low}</strong></span>
                  <span>C: <strong className="text-white font-bold">{crosshairData.close}</strong></span>
                  <span>Vol: <strong className="text-amber-300">{crosshairData.volume.toFixed(1)}</strong></span>
                  <span className={crosshairData.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                    {crosshairData.changePercent >= 0 ? '+' : ''}{crosshairData.changePercent}%
                  </span>
                </>
              ) : (
                <>
                  <span className="flex items-center gap-1 text-zinc-300">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                    币安实时流
                  </span>
                  {showMA && (
                    <span className="hidden sm:flex items-center gap-1.5">
                      <span className="text-amber-400 font-bold">MA7</span>
                      <span className="text-pink-400 font-bold">MA25</span>
                      <span className="text-purple-400 font-bold">MA99</span>
                    </span>
                  )}
                  <span>周期: <strong className="text-white">{klineInterval}</strong></span>
                  <span>深度: <strong className="text-emerald-400">1000根</strong></span>
                </>
              )}
            </div>

            {activeSignalOrder && (
              <span className="flex items-center gap-1 text-amber-300 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20 text-[9px] sm:text-[10px]">
                <Activity className="h-2.5 w-2.5 animate-pulse" />
                Entry: ${activeSignalOrder.entryPriceIndex?.toFixed(1) || 'T+1s'} · 倒计时: {countdownFormatted}
              </span>
            )}
          </div>

          {/* Interactive TradingView Chart Container with Adaptive Responsive Height */}
          <div
            className="w-full relative transition-all"
            style={{
              height: isFullscreen
                ? 'calc(100vh - 220px)'
                : 'clamp(280px, 45vh, 450px)',
              minHeight: '280px',
            }}
          >
            {isLoadingHistory && (
              <div className="absolute inset-0 bg-zinc-950/80 backdrop-blur-xs flex items-center justify-center z-10 text-xs font-mono text-amber-300">
                <Clock className="h-4 w-4 animate-spin mr-2" />
                正在载入 {symbol} 币安完整K线数据 (1000 Bars)...
              </div>
            )}
            <div ref={chartContainerRef} className="w-full h-full" />
          </div>

          {/* Chart Bottom Helper */}
          <div className="text-[9px] sm:text-[10px] text-zinc-500 font-mono px-1 sm:px-2 pt-1 flex items-center justify-between border-t border-zinc-900">
            <span>双指缩放、拖拽看盘 · K线开单信号箭头：<strong className="text-red-400">▲ 开多 (红箭头)</strong> · <strong className="text-emerald-400">▼ 开空 (绿箭头)</strong></span>
            <span className="text-zinc-600">Binance 1000 Bars</span>
          </div>
        </div>

        {/* Right Side Panel: Tab Switch between Signal Order & Live Depth/Trades */}
        <div className="lg:col-span-4 xl:col-span-3 flex flex-col justify-between bg-zinc-950 rounded-xl p-3 sm:p-3.5 border border-zinc-800 space-y-3">
          <div>
            {/* Tab Switcher: Signal Order vs Order Book (Touch Friendly) */}
            <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-xl border border-zinc-800 mb-3 text-xs">
              <button
                onClick={() => setSideTab('signal')}
                className={`flex-1 min-h-[38px] py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 transition cursor-pointer text-xs ${
                  sideTab === 'signal'
                    ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Activity className="h-3.5 w-3.5" />
                模型信号与合约
              </button>
              <button
                onClick={() => setSideTab('depth')}
                className={`flex-1 min-h-[38px] py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 transition cursor-pointer text-xs ${
                  sideTab === 'depth'
                    ? 'bg-zinc-800 text-sky-300 border border-zinc-700 shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <BookOpen className="h-3.5 w-3.5" />
                盘口深度与成交
              </button>
            </div>

            {/* TAB 1: Signal Order Lifecycle & Quantitative Verdict Card */}
            {sideTab === 'signal' && (
              <div className="space-y-2.5 sm:space-y-3">
                {/* Header: Symbol, Duration, Status */}
                <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                  <span className="font-bold text-white text-xs sm:text-sm">
                    {symbol} · {durationLabel} 预测
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                      activeSignalOrder
                        ? activeSignalOrder.status === 'WAITING_ENTRY'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : !isWait
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {activeSignalOrder
                      ? activeSignalOrder.status === 'WAITING_ENTRY'
                        ? '⏳ T+1s 确立中'
                        : activeSignalOrder.direction === 'UP'
                        ? '🟢 OPEN LONG (进行中)'
                        : '🔴 OPEN SHORT (进行中)'
                      : !isWait
                      ? isUp
                        ? '🟢 OPEN LONG'
                        : '🔴 OPEN SHORT'
                      : '⚪ WAIT'}
                  </span>
                </div>

                {/* Signal Verdict Banner */}
                <div>
                  {isUp ? (
                    <div className="bg-emerald-950/60 border border-emerald-500/50 rounded-xl p-2.5 sm:p-3 text-center shadow-lg shadow-emerald-500/10">
                      <div className="text-lg sm:text-2xl font-black text-emerald-400 flex items-center justify-center gap-1.5">
                        <TrendingUp className="h-5 sm:h-6 w-5 sm:w-6 stroke-[3]" />
                        🟢 OPEN LONG (买涨)
                      </div>
                      <div className="text-[10px] sm:text-[11px] text-emerald-300/90 font-medium mt-0.5">
                        预测 Expiry Price Index 高于 Entry Price Index
                      </div>
                    </div>
                  ) : isDown ? (
                    <div className="bg-rose-950/60 border border-rose-500/50 rounded-xl p-2.5 sm:p-3 text-center shadow-lg shadow-rose-500/10">
                      <div className="text-lg sm:text-2xl font-black text-rose-400 flex items-center justify-center gap-1.5">
                        <TrendingDown className="h-5 sm:h-6 w-5 sm:w-6 stroke-[3]" />
                        🔴 OPEN SHORT (买跌)
                      </div>
                      <div className="text-[10px] sm:text-[11px] text-rose-300/90 font-medium mt-0.5">
                        预测 Expiry Price Index 低于 Entry Price Index
                      </div>
                    </div>
                  ) : (
                    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 sm:p-3 text-left space-y-1">
                      <div className="text-sm sm:text-base font-black text-amber-400 flex items-center gap-1.5">
                        <AlertCircle className="h-4 w-4 shrink-0" />
                        ⚪ WAIT / 空仓观望
                      </div>
                      <div className="text-[10px] sm:text-[11px] text-amber-200/90 font-medium leading-relaxed">
                        阻断原因: {pred?.waitReasons?.[0]?.replace(/^[❌\s]+/, '') || '微观订单流不满足统计优势与动态门槛，策略空仓保护'}
                      </div>
                    </div>
                  )}
                </div>

                {/* Active Signal Box with Live Countdown & Delta */}
                {activeSignalOrder ? (
                  <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 p-2.5 sm:p-3 rounded-xl border border-amber-500/30 space-y-1.5 sm:space-y-2 text-xs font-mono shadow-inner">
                    <div className="flex justify-between items-center pb-1 border-b border-zinc-800">
                      <span className="text-zinc-400 text-[11px]">开仓价 (Entry):</span>
                      <strong className="text-white text-xs">
                        ${activeSignalOrder.entryPriceIndex?.toFixed(2) || 'T+1s确立中...'}
                      </strong>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-zinc-400 text-[11px]">当前现价:</span>
                      <span className="text-zinc-200 text-xs">${currentPrice.toFixed(2)}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-zinc-400 text-[11px]">距离开仓价:</span>
                      <span className={`font-bold text-xs ${isFavorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {deltaSign}{priceDelta.toFixed(2)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center pt-1 border-t border-zinc-800/80">
                      <span className="text-amber-400 font-bold flex items-center gap-1 text-[11px]">
                        <Clock className="h-3.5 w-3.5 animate-spin" />
                        到期倒计时:
                      </span>
                      <span className="text-amber-300 font-black text-sm tracking-wider">
                        {countdownFormatted}
                      </span>
                    </div>
                  </div>
                ) : null}

                {/* Numerical Probability & Quantitative Edge Checklist */}
                <div className="space-y-1 sm:space-y-1.5 text-[11px] sm:text-xs font-mono bg-zinc-900/60 p-2 sm:p-2.5 rounded-xl border border-zinc-800/80">
                  <div className="flex justify-between">
                    <span className="text-zinc-400">模型胜率:</span>
                    <strong className={!isWait ? (isUp ? 'text-emerald-400' : 'text-rose-400') : 'text-zinc-200'}>
                      {modelProb.toFixed(1)}%
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">支付比率:</span>
                    <span className="text-amber-300 font-bold">
                      {(payoutRatio * 100).toFixed(0)}% (1:{(payoutRatio).toFixed(2)})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">盈亏平衡:</span>
                    <span className="text-zinc-300">{breakEvenProb.toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">统计优势 (Edge):</span>
                    <span className={`font-bold ${edge > 0 ? 'text-emerald-400' : 'text-zinc-400'}`}>
                      {edge > 0 ? '+' : ''}{edge.toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">单笔理论 EV:</span>
                    <span className={`font-bold ${expectedValue > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {expectedValue > 0 ? '+' : ''}{expectedValue.toFixed(2)} USDT
                    </span>
                  </div>
                </div>

                {/* Recent Settled Signal Info Strip */}
                {recentSettledSignal && !activeSignalOrder && (() => {
                  const isUpSig = recentSettledSignal.direction === 'UP';
                  const entry = recentSettledSignal.entryPriceIndex ?? recentSettledSignal.signalPrice ?? 0;
                  const expiry = recentSettledSignal.expiryPriceIndex ?? entry;
                  const isWin = recentSettledSignal.result === 'WIN' || (isUpSig ? expiry >= entry : expiry <= entry);

                  return (
                    <div className="p-2 bg-zinc-900/70 border border-zinc-800 rounded-lg text-[10px] sm:text-[11px] font-mono">
                      <div className="flex items-center justify-between text-zinc-400 mb-1">
                        <span>最近结算信号:</span>
                        <span
                          className={`font-bold flex items-center gap-0.5 ${
                            isWin ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isWin ? (
                            <CheckCircle2 className="h-3 w-3" />
                          ) : (
                            <XCircle className="h-3 w-3" />
                          )}
                          {isWin ? 'WIN 获胜' : 'LOSS 未中'}
                        </span>
                      </div>
                      <div className="flex justify-between text-zinc-300 text-[10px]">
                        <span>Entry: ${recentSettledSignal.entryPriceIndex?.toFixed(1)}</span>
                        <span>Expiry: ${recentSettledSignal.expiryPriceIndex?.toFixed(1)}</span>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* TAB 2: Live Binance L2 Order Book Depth & Recent Trades */}
            {sideTab === 'depth' && (
              <div className="space-y-2.5 sm:space-y-3 font-mono text-xs">
                {/* L2 Order Book Depth Table */}
                <div className="bg-zinc-900/60 p-2 sm:p-2.5 rounded-xl border border-zinc-800 space-y-1.5 sm:space-y-2">
                  <div className="flex items-center justify-between pb-1 border-b border-zinc-800 text-[10px] sm:text-[11px]">
                    <span className="text-zinc-400 font-bold">买卖深度盘口</span>
                    <span className="text-zinc-500">点差: ${snapshot?.orderBook?.spread?.toFixed(2) || '0.10'}</span>
                  </div>

                  {/* Asks (Sells) - Red */}
                  <div className="space-y-0.5">
                    {asks.slice(0, 5).reverse().map((ask, i) => {
                      const depthPct = Math.min(100, ((ask.total || ask.quantity) / maxDepthQty) * 100);
                      return (
                        <div key={`ask-${i}`} className="relative flex justify-between text-[10px] py-0.5 px-1 rounded overflow-hidden">
                          <div
                            className="absolute right-0 top-0 bottom-0 bg-rose-500/15 pointer-events-none"
                            style={{ width: `${depthPct}%` }}
                          />
                          <span className="text-rose-400 font-bold z-10">${ask.price.toFixed(2)}</span>
                          <span className="text-zinc-400 z-10">{ask.quantity.toFixed(3)}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Current Spread Divider */}
                  <div className="py-1 px-2 rounded bg-zinc-950 border border-zinc-800/80 flex items-center justify-between text-[10px] sm:text-[11px]">
                    <span className="font-bold text-white">${currentPrice.toFixed(2)}</span>
                    <span className="text-zinc-500 text-[9px]">
                      买卖比: {((snapshot?.orderBook?.imbalanceRatio || 0.5) * 100).toFixed(0)}% : {((1 - (snapshot?.orderBook?.imbalanceRatio || 0.5)) * 100).toFixed(0)}%
                    </span>
                  </div>

                  {/* Bids (Buys) - Green */}
                  <div className="space-y-0.5">
                    {bids.slice(0, 5).map((bid, i) => {
                      const depthPct = Math.min(100, ((bid.total || bid.quantity) / maxDepthQty) * 100);
                      return (
                        <div key={`bid-${i}`} className="relative flex justify-between text-[10px] py-0.5 px-1 rounded overflow-hidden">
                          <div
                            className="absolute right-0 top-0 bottom-0 bg-emerald-500/15 pointer-events-none"
                            style={{ width: `${depthPct}%` }}
                          />
                          <span className="text-emerald-400 font-bold z-10">${bid.price.toFixed(2)}</span>
                          <span className="text-zinc-400 z-10">{bid.quantity.toFixed(3)}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Real-time Trades Ticker */}
                <div className="bg-zinc-900/60 p-2 sm:p-2.5 rounded-xl border border-zinc-800">
                  <div className="flex items-center justify-between pb-1 border-b border-zinc-800 text-[10px] sm:text-[11px] mb-1">
                    <span className="text-zinc-400 font-bold">逐笔成交</span>
                    <span className="text-zinc-500 text-[9px]">币安推流</span>
                  </div>
                  <div className="space-y-0.5">
                    {(snapshot?.recentTrades || []).slice(-5).reverse().map((t, idx) => {
                      const isSell = t.isBuyerMaker;
                      const timeStr = new Date(t.time).toTimeString().slice(0, 8);
                      return (
                        <div key={idx} className="flex justify-between items-center text-[10px]">
                          <span className={isSell ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                            ${t.price.toFixed(2)}
                          </span>
                          <span className="text-zinc-300">{t.qty.toFixed(3)}</span>
                          <span className="text-zinc-600">{timeStr}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Model Status Footer */}
          <div className="pt-2 border-t border-zinc-800 text-[9px] sm:text-[10px] text-zinc-500 text-center font-mono">
            有效信号自动确立 Entry 并结算 · 杜绝人为模拟操作干扰模型胜率
          </div>
        </div>
      </div>
    </div>
  );
};
