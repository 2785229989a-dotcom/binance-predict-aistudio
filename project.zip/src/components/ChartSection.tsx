import React, { useState, useMemo } from 'react';
import { KlineData, MarketSnapshot } from '../types/market.js';
import { BarChart3, TrendingUp, Zap, Activity } from 'lucide-react';

interface ChartSectionProps {
  snapshot: MarketSnapshot | null;
}

export const ChartSection: React.FC<ChartSectionProps> = ({ snapshot }) => {
  const [timeframe, setTimeframe] = useState<
    '1m' | '3m' | '5m' | '10m' | '15m' | '30m' | '1h' | '1d'
  >('1m');
  const [subChart, setSubChart] = useState<'cvd' | 'ofi'>('cvd');
  const [showBands, setShowBands] = useState<boolean>(true);

  const klines = snapshot?.recentKlines || [];
  const currentPrice = snapshot?.price || 0;
  const p0 = snapshot?.currentRound?.lockPrice || currentPrice;
  const micro = snapshot?.microstructure;
  const ind = snapshot?.indicators;

  // Aggregate 1m klines dynamically into target timeframes (1m, 3m, 5m, 10m, 15m, 30m, 1h, 1d)
  const displayKlines = useMemo(() => {
    if (!klines || klines.length === 0) return [];
    if (timeframe === '1m') return klines;

    const minMap: Record<string, number> = {
      '3m': 3,
      '5m': 5,
      '10m': 10,
      '15m': 15,
      '30m': 30,
      '1h': 60,
      '1d': 1440,
    };
    const groupSize = minMap[timeframe] || 1;
    const aggregated: KlineData[] = [];

    for (let i = 0; i < klines.length; i += groupSize) {
      const slice = klines.slice(i, i + groupSize);
      if (slice.length === 0) continue;
      const open = slice[0].open;
      const close = slice[slice.length - 1].close;
      const high = Math.max(...slice.map((s) => s.high));
      const low = Math.min(...slice.map((s) => s.low));
      const volume = slice.reduce((acc, s) => acc + s.volume, 0);
      const quoteVolume = slice.reduce((acc, s) => acc + s.quoteVolume, 0);
      const buyVolume = slice.reduce((acc, s) => acc + s.buyVolume, 0);
      const sellVolume = slice.reduce((acc, s) => acc + s.sellVolume, 0);
      const cvd = slice[slice.length - 1].cvd;

      aggregated.push({
        time: slice[0].time,
        open,
        high,
        low,
        close,
        volume,
        quoteVolume,
        buyVolume,
        sellVolume,
        cvd,
      });
    }
    return aggregated;
  }, [klines, timeframe]);

  const chartHeight = 240;
  const subChartHeight = 70;
  const chartWidth = 720;

  const minPrice = useMemo(() => {
    if (displayKlines.length === 0) return 0;
    const lows = displayKlines.map((k) => k.low);
    lows.push(p0, currentPrice);
    if (ind?.bollinger.lower) lows.push(ind.bollinger.lower);
    return Math.min(...lows) * 0.999;
  }, [displayKlines, p0, currentPrice, ind]);

  const maxPrice = useMemo(() => {
    if (displayKlines.length === 0) return 1;
    const highs = displayKlines.map((k) => k.high);
    highs.push(p0, currentPrice);
    if (ind?.bollinger.upper) highs.push(ind.bollinger.upper);
    return Math.max(...highs) * 1.001;
  }, [displayKlines, p0, currentPrice, ind]);

  const priceRange = maxPrice - minPrice || 1;

  const getY = (price: number) => {
    return chartHeight - ((price - minPrice) / priceRange) * chartHeight;
  };

  const candleWidth = Math.max(3, Math.min(12, chartWidth / (displayKlines.length || 1) - 3));

  // Sub-chart min/max
  const cvdValues = displayKlines.map((k) => k.cvd);
  const minCvd = Math.min(0, ...cvdValues);
  const maxCvd = Math.max(0, ...cvdValues);
  const cvdRange = maxCvd - minCvd || 1;
  const getSubY = (val: number) => {
    return subChartHeight - ((val - minCvd) / cvdRange) * subChartHeight;
  };

  return (
    <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-4 shadow-lg flex flex-col justify-between">
      {/* Top Bar with Timeframes & Indicator Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-white flex items-center gap-1.5">
            <BarChart3 className="h-4 w-4 text-amber-400" />
            多周期 K线与量价微观结构
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 font-mono">
            {snapshot?.symbol}
          </span>
        </div>

        {/* Timeframe selector: 1m, 3m, 5m, 10m, 15m, 30m, 1h, 1d */}
        <div className="flex items-center gap-2">
          <div className="flex bg-zinc-950 p-0.5 rounded-lg border border-zinc-800 text-xs overflow-x-auto">
            {(
              [
                { id: '1m', label: '1m' },
                { id: '3m', label: '3m' },
                { id: '5m', label: '5m' },
                { id: '10m', label: '10m' },
                { id: '15m', label: '15m' },
                { id: '30m', label: '30m' },
                { id: '1h', label: '1h' },
                { id: '1d', label: '1d' },
              ] as const
            ).map((tf) => (
              <button
                key={tf.id}
                onClick={() => setTimeframe(tf.id)}
                className={`px-2 py-0.5 rounded font-mono text-[11px] font-medium transition whitespace-nowrap ${
                  timeframe === tf.id
                    ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {tf.label}
              </button>
            ))}
          </div>

          {/* Subchart toggle */}
          <div className="flex bg-zinc-950 p-0.5 rounded-lg border border-zinc-800 text-xs">
            <button
              onClick={() => setSubChart('cvd')}
              className={`px-2 py-0.5 rounded font-mono text-[10px] ${
                subChart === 'cvd' ? 'bg-zinc-800 text-white font-bold' : 'text-zinc-500'
              }`}
            >
              CVD
            </button>
            <button
              onClick={() => setSubChart('ofi')}
              className={`px-2 py-0.5 rounded font-mono text-[10px] ${
                subChart === 'ofi' ? 'bg-zinc-800 text-white font-bold' : 'text-zinc-500'
              }`}
            >
              OFI
            </button>
          </div>
        </div>
      </div>

      {/* Microstructure Speed Badge Banner */}
      {micro && (
        <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-zinc-400 py-1.5 px-2 bg-zinc-950/60 rounded-lg mt-2 border border-zinc-800/60">
          <div className="flex items-center gap-3">
            <span>
              成交速率: <strong className="text-zinc-200">{micro.tradesPerSecond} 笔/秒</strong>
            </span>
            <span>
              主买占比: <strong className={micro.takerBuyRatio >= 0.5 ? 'text-emerald-400' : 'text-rose-400'}>
                {(micro.takerBuyRatio * 100).toFixed(1)}%
              </strong>
            </span>
            <span>
              Tick Delta: <strong className={micro.tickDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {micro.tickDelta > 0 ? `+${micro.tickDelta}` : micro.tickDelta}
              </strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span>RSI: <strong className="text-zinc-200">{ind?.rsi || 50}</strong></span>
            <span>ATR(14): <strong className="text-zinc-200">${ind?.atr14 || 0}</strong></span>
          </div>
        </div>
      )}

      {/* SVG Canvas Candlestick Chart */}
      <div className="pt-2 w-full overflow-x-auto">
        <div className="min-w-[580px]">
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            className="w-full h-[240px] bg-zinc-950/80 rounded-t-xl border border-zinc-800/80"
          >
            {/* Grid lines */}
            {[0.2, 0.4, 0.6, 0.8].map((ratio, idx) => {
              const y = chartHeight * ratio;
              const p = maxPrice - priceRange * ratio;
              return (
                <g key={idx}>
                  <line x1="0" y1={y} x2={chartWidth} y2={y} stroke="#27272a" strokeDasharray="3 3" />
                  <text x={chartWidth - 5} y={y - 4} textAnchor="end" fill="#71717a" fontSize="9" fontFamily="monospace">
                    ${p.toFixed(2)}
                  </text>
                </g>
              );
            })}

            {/* Bollinger Bands Upper / Lower lines */}
            {ind && showBands && (
              <>
                <line
                  x1="0"
                  y1={getY(ind.bollinger.upper)}
                  x2={chartWidth}
                  y2={getY(ind.bollinger.upper)}
                  stroke="#6366f1"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                  opacity="0.6"
                />
                <line
                  x1="0"
                  y1={getY(ind.bollinger.lower)}
                  x2={chartWidth}
                  y2={getY(ind.bollinger.lower)}
                  stroke="#6366f1"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                  opacity="0.6"
                />
              </>
            )}

            {/* Anchored Reference Price P0 line (Gold Dashed) */}
            {p0 > 0 && (
              <g>
                <line
                  x1="0"
                  y1={getY(p0)}
                  x2={chartWidth}
                  y2={getY(p0)}
                  stroke="#f59e0b"
                  strokeWidth="1.8"
                  strokeDasharray="4 4"
                />
                <rect x={chartWidth - 130} y={getY(p0) - 16} width="125" height="16" fill="#78350f" rx="3" />
                <text
                  x={chartWidth - 8}
                  y={getY(p0) - 4}
                  textAnchor="end"
                  fill="#fbbf24"
                  fontSize="9"
                  fontWeight="bold"
                  fontFamily="monospace"
                >
                  参考基准价 P0 ${p0.toFixed(2)}
                </text>
              </g>
            )}

            {/* Live Price Line (Cyan) */}
            {currentPrice > 0 && (
              <g>
                <line x1="0" y1={getY(currentPrice)} x2={chartWidth} y2={getY(currentPrice)} stroke="#38bdf8" strokeWidth="1.2" />
                <rect x={0} y={getY(currentPrice) - 16} width="105" height="16" fill="#0369a1" rx="3" />
                <text x={6} y={getY(currentPrice) - 4} fill="#e0f2fe" fontSize="9" fontWeight="bold" fontFamily="monospace">
                  实时现价 ${currentPrice.toFixed(2)}
                </text>
              </g>
            )}

            {/* Candlesticks */}
            {displayKlines.map((k, i) => {
              const x = (i + 0.5) * (chartWidth / (displayKlines.length || 1));
              const isGreen = k.close >= k.open;
              const highY = getY(k.high);
              const lowY = getY(k.low);
              const openY = getY(k.open);
              const closeY = getY(k.close);
              const bodyTop = Math.min(openY, closeY);
              const bodyHeight = Math.max(2, Math.abs(closeY - openY));

              return (
                <g key={k.time}>
                  <line x1={x} y1={highY} x2={x} y2={lowY} stroke={isGreen ? '#10b981' : '#f43f5e'} strokeWidth="1.2" />
                  <rect
                    x={x - candleWidth / 2}
                    y={bodyTop}
                    width={candleWidth}
                    height={bodyHeight}
                    fill={isGreen ? '#10b981' : '#f43f5e'}
                    rx="1"
                  />
                </g>
              );
            })}
          </svg>

          {/* Subchart: CVD or OFI */}
          <div className="relative border-x border-b border-zinc-800/80 bg-zinc-950 rounded-b-xl">
            <div className="absolute top-1 left-2 text-[10px] text-zinc-400 font-mono z-10 flex items-center gap-2">
              <span className="font-bold text-zinc-300">
                {subChart === 'cvd' ? 'CVD 累计成交量增量' : 'OFI 订单流失衡柱状图'}
              </span>
              <span>•</span>
              <span className={snapshot?.currentCvd && snapshot.currentCvd >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {snapshot?.currentCvd?.toFixed(2)}
              </span>
            </div>

            <svg viewBox={`0 0 ${chartWidth} ${subChartHeight}`} className="w-full h-[70px]">
              <line x1="0" y1={getSubY(0)} x2={chartWidth} y2={getSubY(0)} stroke="#3f3f46" strokeWidth="1" />
              {subChart === 'cvd' && (
                <polyline
                  fill="none"
                  stroke="#eab308"
                  strokeWidth="2"
                  points={displayKlines
                    .map((k, i) => {
                      const x = (i + 0.5) * (chartWidth / (displayKlines.length || 1));
                      const y = getSubY(k.cvd);
                      return `${x},${y}`;
                    })
                    .join(' ')}
                />
              )}

              {subChart === 'ofi' &&
                displayKlines.map((k, i) => {
                  const x = (i + 0.5) * (chartWidth / (displayKlines.length || 1));
                  const delta = k.buyVolume - k.sellVolume;
                  const isPositive = delta >= 0;
                  const zeroY = getSubY(0);
                  const barY = getSubY(delta * 2);
                  const top = Math.min(zeroY, barY);
                  const height = Math.max(2, Math.abs(zeroY - barY));
                  return (
                    <rect
                      key={k.time}
                      x={x - candleWidth / 2}
                      y={top}
                      width={candleWidth}
                      height={height}
                      fill={isPositive ? '#10b981' : '#f43f5e'}
                      opacity="0.85"
                      rx="1"
                    />
                  );
                })}
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
};
