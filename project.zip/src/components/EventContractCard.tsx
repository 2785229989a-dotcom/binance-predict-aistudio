import React, { useState, useEffect } from 'react';
import { EventContractRound, MarketSnapshot, PredictionResult } from '../types/market.js';
import { Clock, TrendingUp, TrendingDown, Target, Zap, AlertCircle, CheckCircle2 } from 'lucide-react';

interface EventContractCardProps {
  snapshot: MarketSnapshot | null;
  onQuickTrade: (direction: 'UP' | 'DOWN', stake: number) => void;
}

export const EventContractCard: React.FC<EventContractCardProps> = ({
  snapshot,
  onQuickTrade,
}) => {
  const [stakeInput, setStakeInput] = useState<number>(100);
  const [timeLeft, setTimeLeft] = useState<{ minutes: number; seconds: number; totalSec: number }>({
    minutes: 0,
    seconds: 0,
    totalSec: 0,
  });

  const round = snapshot?.currentRound;
  const pred = snapshot?.prediction;

  useEffect(() => {
    if (!round) return;

    const updateTimer = () => {
      const now = Date.now();
      const diffMs = Math.max(0, round.expiryTime - now);
      const totalSec = Math.floor(diffMs / 1000);
      const minutes = Math.floor(totalSec / 60);
      const seconds = totalSec % 60;
      setTimeLeft({ minutes, seconds, totalSec });
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [round?.expiryTime]);

  if (!snapshot || !round) {
    return (
      <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 animate-pulse text-center text-zinc-500">
        正在同步 10分钟事件合约状态...
      </div>
    );
  }

  const currentPrice = snapshot.price;
  const lockPrice = round.lockPrice;
  const priceDiff = currentPrice - lockPrice;
  const priceDiffPct = lockPrice > 0 ? (priceDiff / lockPrice) * 100 : 0;
  const isCurrentlyUp = priceDiff >= 0;

  // Calculate progress percent (0 to 100%)
  const totalDuration = round.durationSeconds || 600;
  const elapsedSec = totalDuration - timeLeft.totalSec;
  const progressPercent = Math.min(100, Math.max(0, (elapsedSec / totalDuration) * 100));

  const directionColor =
    pred?.direction === 'UP'
      ? 'from-emerald-600/30 to-emerald-950/40 border-emerald-500/40 text-emerald-400'
      : pred?.direction === 'DOWN'
      ? 'from-rose-600/30 to-rose-950/40 border-rose-500/40 text-rose-400'
      : 'from-amber-600/20 to-zinc-900 border-amber-500/30 text-amber-400';

  return (
    <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-800 rounded-xl p-5 shadow-xl relative overflow-hidden">
      {/* Background ambient glow */}
      <div
        className={`absolute top-0 right-0 w-96 h-96 rounded-full blur-3xl opacity-15 pointer-events-none ${
          pred?.direction === 'UP'
            ? 'bg-emerald-500'
            : pred?.direction === 'DOWN'
            ? 'bg-rose-500'
            : 'bg-amber-500'
        }`}
      />

      {/* Top Banner Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-zinc-800/80 border border-zinc-700/60 flex items-center justify-center text-amber-400">
            <Clock className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white text-base">
                {snapshot.symbol} 10分钟事件合约
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 font-mono">
                {round.roundId}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-medium">
                进行中 (LIVE)
              </span>
            </div>
            <div className="text-xs text-zinc-400 mt-0.5">
              规则：在10分钟结算点，若结算价格 ≥ 锁定行权价，则【UP 看涨】胜出；反之【DOWN 看跌】胜出。
            </div>
          </div>
        </div>

        {/* Countdown Timer Display */}
        <div className="flex items-center gap-3 bg-zinc-900/90 border border-zinc-800 px-4 py-2 rounded-xl">
          <div className="text-right">
            <div className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">
              结算倒计时
            </div>
            <div className="font-mono text-2xl font-black text-amber-400 tracking-wider">
              {String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}
            </div>
          </div>
          <div className="w-12 h-12 relative flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-zinc-800"
                strokeWidth="3"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-amber-500 transition-all duration-1000 ease-linear"
                strokeDasharray={`${progressPercent}, 100`}
                strokeWidth="3"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <span className="absolute text-[10px] font-bold text-zinc-300 font-mono">
              {Math.round(progressPercent)}%
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Price Strike, Current State, Prediction Signal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 pt-4">
        {/* Box 1: Lock Price vs Live Price */}
        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-zinc-400 flex items-center gap-1.5 font-medium">
              <Target className="h-3.5 w-3.5 text-amber-400" />
              锁定行权基准价
            </span>
            <span className="text-[11px] text-zinc-500 font-mono">本期开盘价</span>
          </div>
          <div className="font-mono text-xl font-bold text-zinc-200">
            ${lockPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>

          <div className="mt-3 pt-3 border-t border-zinc-800/60 flex items-center justify-between">
            <div>
              <div className="text-[11px] text-zinc-400">实时当前价</div>
              <div className="font-mono text-base font-bold text-white">
                ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] text-zinc-400">行权偏差 (Delta)</div>
              <div
                className={`font-mono text-sm font-bold flex items-center justify-end gap-1 ${
                  isCurrentlyUp ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {isCurrentlyUp ? '+' : ''}
                {priceDiff.toFixed(2)} ({isCurrentlyUp ? '+' : ''}
                {priceDiffPct.toFixed(3)}%)
              </div>
            </div>
          </div>

          <div
            className={`mt-2.5 text-xs py-1 px-2 rounded font-medium flex items-center justify-between ${
              isCurrentlyUp
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
            }`}
          >
            <span>当前瞬时状态:</span>
            <span className="font-bold">{isCurrentlyUp ? '【UP 看涨】领先盈利中' : '【DOWN 看跌】领先盈利中'}</span>
          </div>
        </div>

        {/* Box 2: Prediction Quantitative Model Decision */}
        <div className={`bg-gradient-to-br ${directionColor} border rounded-xl p-4 flex flex-col justify-between`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="h-3.5 w-3.5" />
              量化多因子实时预测
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-900/60 font-mono text-zinc-300">
              置信度: {pred?.confidence ?? 50}%
            </span>
          </div>

          <div className="my-2 flex items-center gap-4">
            <div className="flex-1">
              <div className="text-[11px] text-zinc-300 font-medium">模型建议信号</div>
              <div className="text-2xl font-black tracking-tight flex items-center gap-2">
                {pred?.direction === 'UP' && (
                  <>
                    <TrendingUp className="h-6 w-6 text-emerald-400" />
                    <span className="text-emerald-400">UP (看涨)</span>
                  </>
                )}
                {pred?.direction === 'DOWN' && (
                  <>
                    <TrendingDown className="h-6 w-6 text-rose-400" />
                    <span className="text-rose-400">DOWN (看跌)</span>
                  </>
                )}
                {pred?.direction === 'WAIT' && (
                  <>
                    <AlertCircle className="h-6 w-6 text-amber-400" />
                    <span className="text-amber-400">WAIT (观望)</span>
                  </>
                )}
              </div>
            </div>

            <div className="text-right">
              <div className="text-[11px] text-zinc-300">胜率预估</div>
              <div className="font-mono text-xl font-bold text-white">
                {pred?.winProbability ?? 50}%
              </div>
              <div className="text-[10px] text-zinc-400 font-mono">
                综合评分: {pred?.compositeScore ?? 0}
              </div>
            </div>
          </div>

          <div className="text-xs text-zinc-300/90 line-clamp-2 bg-zinc-950/40 p-2 rounded border border-zinc-800/40">
            {pred?.rationale[0] || '实时订单流平衡，等待更清晰的方向失衡'}
          </div>
        </div>

        {/* Box 3: Quick Action & Dynamic Odds */}
        <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-zinc-400 mb-2">
              <span className="font-medium">模拟快捷投注额</span>
              <div className="flex gap-1">
                {[50, 100, 200].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setStakeInput(amt)}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono border ${
                      stakeInput === amt
                        ? 'border-amber-400 bg-amber-400/20 text-amber-300'
                        : 'border-zinc-700 bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
            </div>

            <div className="relative mb-3">
              <span className="absolute left-3 top-2 text-zinc-500 font-mono text-sm">$</span>
              <input
                type="number"
                value={stakeInput}
                onChange={(e) => setStakeInput(Math.max(1, Number(e.target.value)))}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg pl-7 pr-3 py-1.5 text-sm font-mono font-bold text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onQuickTrade('UP', stakeInput)}
              className="flex flex-col items-center justify-center p-2 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 transition group active:scale-95"
            >
              <div className="flex items-center gap-1 font-bold text-xs">
                <TrendingUp className="h-3.5 w-3.5 group-hover:-translate-y-0.5 transition" />
                看涨 (UP)
              </div>
              <div className="text-[10px] text-emerald-400/80 font-mono mt-0.5">
                赔率 {round?.upOdds ?? 1.90}x (返${(stakeInput * (round?.upOdds ?? 1.9)).toFixed(1)})
              </div>
            </button>

            <button
              onClick={() => onQuickTrade('DOWN', stakeInput)}
              className="flex flex-col items-center justify-center p-2 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-400 transition group active:scale-95"
            >
              <div className="flex items-center gap-1 font-bold text-xs">
                <TrendingDown className="h-3.5 w-3.5 group-hover:translate-y-0.5 transition" />
                看跌 (DOWN)
              </div>
              <div className="text-[10px] text-rose-400/80 font-mono mt-0.5">
                赔率 {round?.downOdds ?? 1.90}x (返${(stakeInput * (round?.downOdds ?? 1.9)).toFixed(1)})
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
