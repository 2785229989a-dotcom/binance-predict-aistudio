import React, { useState } from 'react';
import { ModelExamResult, SymbolType } from '../types/market.js';
import {
  Award,
  Play,
  CheckCircle,
  XCircle,
  AlertTriangle,
  TrendingUp,
  Percent,
  Layers,
  ShieldCheck,
  Activity,
  Calendar,
} from 'lucide-react';

interface ModelExamPanelProps {
  currentSymbol: SymbolType;
}

export const ModelExamPanel: React.FC<ModelExamPanelProps> = ({ currentSymbol }) => {
  const [selectedSymbol, setSelectedSymbol] = useState<SymbolType>(currentSymbol);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [examResult, setExamResult] = useState<ModelExamResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startExam = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/model-exam', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol: selectedSymbol }),
      });
      if (!res.ok) {
        throw new Error(`考试请求失败: ${res.statusText}`);
      }
      const data = await res.json();
      setExamResult(data);
    } catch (err: any) {
      setError(err.message || '模型考试运行发生异常');
    } finally {
      setIsLoading(false);
    }
  };

  const curve = examResult?.equityCurve || [];
  const minEq = curve.length > 0 ? Math.min(...curve.map((c) => c.equity)) * 0.98 : 9500;
  const maxEq = curve.length > 0 ? Math.max(...curve.map((c) => c.equity)) * 1.02 : 11000;
  const eqRange = maxEq - minEq || 1;
  const svgWidth = 720;
  const svgHeight = 180;

  return (
    <div className="space-y-6">
      {/* Exam Header Card */}
      <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <Award className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                10分钟模型自动考试系统 (Model Exam & Walk-Forward Audit)
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                基于币安真实历史行情切片，执行严格时间序列截断与三阶段 Walk-Forward (训练/验证/盲盒测试)，严防未来数据泄漏
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2">
            <div className="flex bg-zinc-950 p-1 rounded-lg border border-zinc-800 text-xs">
              <button
                onClick={() => setSelectedSymbol('BTCUSDT')}
                className={`px-3 py-1 font-bold rounded ${
                  selectedSymbol === 'BTCUSDT'
                    ? 'bg-amber-400 text-zinc-950'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                BTCUSDT
              </button>
              <button
                onClick={() => setSelectedSymbol('ETHUSDT')}
                className={`px-3 py-1 font-bold rounded ${
                  selectedSymbol === 'ETHUSDT'
                    ? 'bg-amber-400 text-zinc-950'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                ETHUSDT
              </button>
            </div>

            <button
              onClick={startExam}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs flex items-center gap-1.5 transition shadow-lg shadow-amber-400/20 disabled:opacity-50"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              {isLoading ? '考试中 (Walk-Forward评估)...' : '开始全真模型考试'}
            </button>
          </div>
        </div>

        {/* Feature Highlights of the Exam */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 text-xs text-zinc-400">
          <div className="bg-zinc-950/70 p-3 rounded-xl border border-zinc-800/80">
            <span className="font-bold text-zinc-200 block mb-1">1. 严禁未来数据 (Zero Leakage)</span>
            每个时序切片仅采用 Lag(i) 前序特征计算，禁止利用未出现的结算价与后续K线。
          </div>
          <div className="bg-zinc-950/70 p-3 rounded-xl border border-zinc-800/80">
            <span className="font-bold text-zinc-200 block mb-1">2. 严格 WAIT 过滤器检验</span>
            考核模型能否在无明显概率优势、趋势冲突及订单流背离时果断保持观望(WAIT)。
          </div>
          <div className="bg-zinc-950/70 p-3 rounded-xl border border-zinc-800/80">
            <span className="font-bold text-zinc-200 block mb-1">3. 盲盒样本 Out-of-Sample 验证</span>
            切分时间序列为独立三段，评估模型在完全未接触的未来时间段中的泛化稳定性。
          </div>
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
          <AlertTriangle className="h-4 w-4" />
          <span>{error}</span>
        </div>
      )}

      {/* Exam Result Details */}
      {examResult && (
        <div className="space-y-6">
          {/* Key Metric Scorecard */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">总体胜率 (Win Rate)</span>
              <div className="font-mono text-2xl font-black text-emerald-400 mt-1">
                {examResult.overallWinRate}%
              </div>
              <div className="text-[10px] text-zinc-500 font-mono">
                {examResult.wins} 胜 / {examResult.losses} 负
              </div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">看涨 / 看跌 胜率</span>
              <div className="font-mono text-sm font-bold text-white mt-1">
                UP: <span className="text-emerald-400">{examResult.upWinRate}%</span>
              </div>
              <div className="font-mono text-sm font-bold text-white">
                DOWN: <span className="text-rose-400">{examResult.downWinRate}%</span>
              </div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">WAIT 观望率 (风控)</span>
              <div className="font-mono text-2xl font-black text-amber-400 mt-1">
                {examResult.waitPercentage}%
              </div>
              <div className="text-[10px] text-zinc-500 font-mono">
                过滤低质信号 {examResult.waitCount} 次
              </div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">平均优势 (Edge)</span>
              <div className="font-mono text-2xl font-black text-sky-400 mt-1">
                +{examResult.avgEdge}%
              </div>
              <div className="text-[10px] text-zinc-500">超额统计概率</div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">最大回撤 (Max DD)</span>
              <div className="font-mono text-2xl font-black text-rose-400 mt-1">
                -{examResult.maxDrawdown}%
              </div>
              <div className="text-[10px] text-zinc-500 font-mono">
                最大连错: {examResult.maxConsecutiveLosses} 次
              </div>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-3">
              <span className="text-[10px] text-zinc-400">夏普比率 (Sharpe)</span>
              <div className="font-mono text-2xl font-black text-amber-300 mt-1">
                {examResult.sharpeRatio}
              </div>
              <div className="text-[10px] text-zinc-500 font-mono">
                盈亏比: {examResult.profitFactor}
              </div>
            </div>
          </div>

          {/* Walk-Forward 3-Stage Split Table */}
          <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-5 shadow-lg">
            <h4 className="text-sm font-bold text-white mb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-amber-400" />
                Walk-Forward 时序滚动分段检验报告
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                严格防止过拟合
              </span>
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="text-zinc-500 border-b border-zinc-800 font-mono text-[11px]">
                    <th className="py-2">分段名称</th>
                    <th>时间跨度</th>
                    <th>预测总数</th>
                    <th>有效交易 (UP/DOWN)</th>
                    <th>WAIT过滤</th>
                    <th>该段胜率</th>
                    <th>Precision / 查准</th>
                    <th>盈亏比 (PF)</th>
                    <th>净收益</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60 font-mono">
                  {examResult.splits.map((s, idx) => (
                    <tr key={idx} className="hover:bg-zinc-800/30">
                      <td className="py-2.5 font-sans font-bold text-zinc-200">
                        {s.splitName}
                      </td>
                      <td className="text-zinc-400 text-[11px]">{s.timeRange}</td>
                      <td className="text-zinc-300">{s.tradesCount + s.waitCount}</td>
                      <td className="text-zinc-200">
                        {s.tradesCount} ({s.upCount}多 / {s.downCount}空)
                      </td>
                      <td className="text-amber-400">{s.waitCount}</td>
                      <td>
                        <span className="font-bold text-emerald-400">{s.winRate}%</span>
                      </td>
                      <td className="text-zinc-300">{s.precision}%</td>
                      <td className="text-zinc-300">{s.profitFactor}</td>
                      <td className={s.netPnl >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                        {s.netPnl >= 0 ? `+$${s.netPnl}` : `-$${Math.abs(s.netPnl)}`}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Equity Curve SVG */}
          <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-5 shadow-lg">
            <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              模型考试全周期净值走势曲线 (按10分钟结算严格复现)
            </h4>
            <div className="pt-2">
              <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-[180px] bg-zinc-950 rounded-lg">
                {[0.2, 0.5, 0.8].map((ratio) => {
                  const y = svgHeight * ratio;
                  const eq = maxEq - eqRange * ratio;
                  return (
                    <g key={ratio}>
                      <line x1="0" y1={y} x2={svgWidth} y2={y} stroke="#27272a" strokeDasharray="3 3" />
                      <text x={svgWidth - 5} y={y - 4} textAnchor="end" fill="#71717a" fontSize="9" fontFamily="monospace">
                        ${eq.toFixed(0)}
                      </text>
                    </g>
                  );
                })}

                {curve.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={curve
                      .map((pt, idx) => {
                        const x = (idx / (curve.length - 1)) * svgWidth;
                        const y = svgHeight - ((pt.equity - minEq) / eqRange) * svgHeight;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                )}
              </svg>
            </div>
          </div>

          {/* Audit Conclusion Box */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-center gap-2 text-sm font-bold text-white mb-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              模型考试审计结论与实盘合格性
            </div>
            <ul className="space-y-1 text-xs text-zinc-300 font-sans">
              {examResult.auditNotes.map((note, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-emerald-400">•</span>
                  <span>{note}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
