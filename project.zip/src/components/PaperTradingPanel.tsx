import React, { useState } from 'react';
import { MarketSnapshot, PaperTrade, SymbolType } from '../types/market.js';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle,
  XCircle,
  RefreshCw,
  Award,
  DollarSign,
  AlertCircle,
  ShieldAlert,
} from 'lucide-react';

interface PaperTradingPanelProps {
  currentSymbol: SymbolType;
  snapshot: MarketSnapshot | null;
  balance: number;
  trades: PaperTrade[];
  onPlaceTrade: (symbol: SymbolType, direction: 'UP' | 'DOWN', stake: number, modelProb?: number) => Promise<void>;
  onResetBalance: (initialBalance?: number) => void;
}

export const PaperTradingPanel: React.FC<PaperTradingPanelProps> = ({
  currentSymbol,
  snapshot,
  balance,
  trades,
  onPlaceTrade,
  onResetBalance,
}) => {
  const [direction, setDirection] = useState<'UP' | 'DOWN'>('UP');
  const [stake, setStake] = useState<number>(100);
  const [customBalance, setCustomBalance] = useState<number>(10000);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const round = snapshot?.currentRound;
  const pred = snapshot?.prediction;
  const upOdds = round?.upOdds || 1.88;
  const downOdds = round?.downOdds || 1.95;
  const currentOdds = direction === 'UP' ? upOdds : downOdds;
  const potentialPayout = (stake * currentOdds).toFixed(2);
  const potentialProfit = (stake * (currentOdds - 1)).toFixed(2);

  const activeTrades = trades.filter((t) => t.status === 'ACTIVE');
  const settledTrades = trades.filter((t) => t.status !== 'ACTIVE');

  // Stats
  const totalSettled = settledTrades.length;
  const winCount = settledTrades.filter((t) => t.status === 'WON').length;
  const winRate = totalSettled > 0 ? ((winCount / totalSettled) * 100).toFixed(1) : '0.0';
  const totalPnl = (balance - 10000).toFixed(2);
  const isPnlPositive = balance >= 10000;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (stake <= 0) {
      setFeedback({ type: 'error', message: '下单金额必须大于0' });
      return;
    }
    if (stake > balance) {
      setFeedback({ type: 'error', message: '模拟账户余额不足' });
      return;
    }

    setIsSubmitting(true);
    setFeedback(null);
    try {
      const modelProb = direction === 'UP' ? pred?.upProb || 50 : pred?.downProb || 50;
      await onPlaceTrade(currentSymbol, direction, stake, modelProb);
      setFeedback({
        type: 'success',
        message: `模拟订单已提交: ${currentSymbol} 10分钟看${direction === 'UP' ? '涨' : '跌'} $${stake} (锁定行权基准价 $${round?.lockPrice.toFixed(2)})`,
      });
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || '下单失败' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Explicit Safety Notice Banner */}
      <div className="bg-amber-950/30 border border-amber-500/40 rounded-2xl p-4 flex items-center justify-between text-xs text-amber-300">
        <div className="flex items-center gap-2.5">
          <ShieldAlert className="h-5 w-5 text-amber-400 shrink-0" />
          <div>
            <strong className="text-amber-200">【模拟交易系统 • 仅供量化模型验证 • 绝不连接真实资金】</strong>
            <div className="text-[11px] text-amber-400/80 mt-0.5">
              严格模拟二元事件期权结算规则，依据入场瞬间参考价 P0 与到期收盘价 P10 进行虚拟 PnL 结算。
            </div>
          </div>
        </div>

        {/* Configurable Initial Balance */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-zinc-400 hidden sm:inline">重置资金:</span>
          <select
            value={customBalance}
            onChange={(e) => {
              const val = Number(e.target.value);
              setCustomBalance(val);
              onResetBalance(val);
            }}
            className="bg-zinc-900 border border-zinc-700 text-zinc-200 rounded px-2 py-1 text-xs"
          >
            <option value="5000">$5,000</option>
            <option value="10000">$10,000</option>
            <option value="20000">$20,000</option>
            <option value="50000">$50,000</option>
          </select>
        </div>
      </div>

      {/* Top Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">模拟账户净值</span>
            <Wallet className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-white">
            ${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-zinc-500 mt-1">虚拟本金: ${customBalance.toLocaleString()}</div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">累计盈亏 (PnL)</span>
            <DollarSign className={`h-4 w-4 ${isPnlPositive ? 'text-emerald-400' : 'text-rose-400'}`} />
          </div>
          <div
            className={`mt-2 font-mono text-2xl font-bold ${
              isPnlPositive ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {isPnlPositive ? `+$${totalPnl}` : `-$${Math.abs(Number(totalPnl)).toFixed(2)}`}
          </div>
          <div className="text-[10px] text-zinc-500 mt-1">
            总收益率: {(((balance - customBalance) / customBalance) * 100).toFixed(2)}%
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">模拟交易胜率</span>
            <Award className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-amber-400">
            {winRate}%
          </div>
          <div className="text-[10px] text-zinc-500 mt-1">
            已结算: {winCount} 胜 / {totalSettled - winCount} 负
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">持仓中合约</span>
            <Clock className="h-4 w-4 text-sky-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-sky-400">
            {activeTrades.length} <span className="text-xs font-normal text-zinc-500">笔</span>
          </div>
          <div className="text-[10px] text-zinc-500 mt-1">
            保证金: ${activeTrades.reduce((acc, t) => acc + t.stake, 0)}
          </div>
        </div>
      </div>

      {/* Main Execution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trade Form */}
        <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-5 shadow-xl lg:col-span-1">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              10分钟模拟开仓台
            </h3>
            <span className="text-xs text-zinc-400 font-mono">
              P0: ${round?.lockPrice.toFixed(1) || 0}
            </span>
          </div>

          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            {/* Direction Selection */}
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-2">
                选择预测方向 (以基准价 P0 为准)
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDirection('UP')}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-center transition-all ${
                    direction === 'UP'
                      ? 'bg-emerald-600/30 border-emerald-500 text-emerald-400 shadow-md shadow-emerald-500/10'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <TrendingUp className="h-5 w-5 mb-1" />
                  <span className="font-bold text-sm">看涨 (UP)</span>
                  <span className="text-[10px] font-mono mt-0.5">模型概率 {pred?.upProb || 50}%</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDirection('DOWN')}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-center transition-all ${
                    direction === 'DOWN'
                      ? 'bg-rose-600/30 border-rose-500 text-rose-400 shadow-md shadow-rose-500/10'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  <TrendingDown className="h-5 w-5 mb-1" />
                  <span className="font-bold text-sm">看跌 (DOWN)</span>
                  <span className="text-[10px] font-mono mt-0.5">模型概率 {pred?.downProb || 50}%</span>
                </button>
              </div>
            </div>

            {/* Stake Input */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label className="font-medium text-zinc-400">虚拟投注金额 (USDT)</label>
                <span className="text-zinc-500 font-mono">余额: ${balance.toFixed(1)}</span>
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-zinc-500 font-mono">$</span>
                <input
                  type="number"
                  min="1"
                  max={balance}
                  value={stake}
                  onChange={(e) => setStake(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg pl-8 pr-4 py-2 text-base font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Quick Amount Buttons */}
              <div className="grid grid-cols-4 gap-1.5 mt-2">
                {[50, 100, 250, 500].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setStake(amt)}
                    className="py-1 rounded bg-zinc-950 border border-zinc-800 text-xs font-mono text-zinc-300 hover:bg-zinc-800"
                  >
                    ${amt}
                  </button>
                ))}
              </div>
            </div>

            {/* Contract Summary Box */}
            <div className="bg-zinc-950 rounded-xl p-3 border border-zinc-800/80 text-xs space-y-1.5 font-mono">
              <div className="flex justify-between text-zinc-400">
                <span>行权锁定基准价 P0:</span>
                <span className="text-amber-400 font-bold">${round?.lockPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>10分钟结算胜出判定:</span>
                <span className="text-zinc-200">
                  {direction === 'UP' ? `结算价 > $${round?.lockPrice.toFixed(2)}` : `结算价 < $${round?.lockPrice.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>赔率 Multiplier:</span>
                <span className="text-amber-400 font-bold">{currentOdds}x</span>
              </div>
              <div className="flex justify-between text-zinc-400 pt-1.5 border-t border-zinc-800">
                <span>获胜预计返还:</span>
                <span className="text-emerald-400 font-bold">${potentialPayout}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>预期净盈亏 (Net PnL):</span>
                <span className="text-emerald-400 font-bold">+${potentialProfit}</span>
              </div>
            </div>

            {feedback && (
              <div
                className={`p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                  feedback.type === 'success'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                }`}
              >
                {feedback.type === 'success' ? (
                  <CheckCircle className="h-4 w-4 shrink-0" />
                ) : (
                  <AlertCircle className="h-4 w-4 shrink-0" />
                )}
                <span>{feedback.message}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting || stake > balance}
              className={`w-full py-2.5 rounded-xl font-bold text-sm text-zinc-950 transition-all ${
                direction === 'UP'
                  ? 'bg-emerald-400 hover:bg-emerald-300 shadow-lg shadow-emerald-500/20'
                  : 'bg-rose-400 hover:bg-rose-300 shadow-lg shadow-rose-500/20'
              } disabled:opacity-50`}
            >
              {isSubmitting ? '模拟撮合中...' : `确认模拟看${direction === 'UP' ? '涨' : '跌'} ($${stake})`}
            </button>
          </form>
        </div>

        {/* Active & Settled Tables */}
        <div className="space-y-6 lg:col-span-2">
          {/* Active Positions */}
          <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-sky-400" />
                当前持仓中的合约 ({activeTrades.length})
              </span>
              <span className="text-[11px] text-zinc-500">到期以真实价格 P10 自动结算</span>
            </h3>

            {activeTrades.length === 0 ? (
              <div className="py-8 text-center text-zinc-500 text-xs border border-dashed border-zinc-800 rounded-xl">
                暂无持仓合约。在左侧或上方预测卡片中点击【看涨/看跌】即可模拟开仓！
              </div>
            ) : (
              <div className="space-y-2">
                {activeTrades.map((trade) => {
                  const currentPrice = snapshot?.price || trade.strikePrice;
                  const isWinning =
                    trade.direction === 'UP'
                      ? currentPrice > trade.strikePrice
                      : currentPrice < trade.strikePrice;

                  return (
                    <div
                      key={trade.id}
                      className="bg-zinc-950 border border-zinc-800 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`text-xs px-2 py-0.5 rounded font-bold ${
                            trade.direction === 'UP'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                          }`}
                        >
                          {trade.direction}
                        </span>
                        <div>
                          <div className="font-bold text-xs text-white">
                            {trade.symbol} 10-Min Event
                          </div>
                          <div className="text-[11px] text-zinc-400 font-mono">
                            锁定基准价 P0: ${trade.strikePrice.toFixed(2)} | 投注: ${trade.stake}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-right">
                        <div>
                          <div className="text-[10px] text-zinc-400">现价瞬时状态</div>
                          <div
                            className={`text-xs font-bold font-mono ${
                              isWinning ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            ${currentPrice.toFixed(1)} ({isWinning ? '领先 +盈' : '落后 -亏'})
                          </div>
                        </div>

                        <div>
                          <div className="text-[10px] text-zinc-400">胜出到账</div>
                          <div className="text-xs font-mono font-bold text-amber-400">
                            ${(trade.stake * trade.odds).toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Settled History */}
          <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-3">
              历史结算模拟记录 ({settledTrades.length})
            </h3>

            {settledTrades.length === 0 ? (
              <div className="py-6 text-center text-zinc-500 text-xs border border-dashed border-zinc-800 rounded-xl">
                暂无结算记录。10分钟周期到期后将根据真实市场收盘价生成胜负结果。
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="text-zinc-500 border-b border-zinc-800 font-mono text-[11px]">
                      <th className="py-2">标的与周期</th>
                      <th>方向</th>
                      <th>基准价 P0</th>
                      <th>结算价 P10</th>
                      <th>投注额</th>
                      <th>净盈亏 (PnL)</th>
                      <th>结果</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/60 font-mono">
                    {settledTrades.slice(0, 10).map((trade) => {
                      const isWin = trade.status === 'WON';
                      return (
                        <tr key={trade.id} className="hover:bg-zinc-800/30">
                          <td className="py-2.5 font-sans font-medium text-zinc-300">
                            {trade.symbol}
                            <span className="block text-[10px] text-zinc-500">{trade.roundId}</span>
                          </td>
                          <td>
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                trade.direction === 'UP'
                                  ? 'bg-emerald-500/10 text-emerald-400'
                                  : 'bg-rose-500/10 text-rose-400'
                              }`}
                            >
                              {trade.direction}
                            </span>
                          </td>
                          <td className="text-zinc-300">${trade.strikePrice.toFixed(2)}</td>
                          <td className="text-zinc-300">${trade.settlementPrice?.toFixed(2) || '-'}</td>
                          <td className="text-zinc-300">${trade.stake}</td>
                          <td className={`font-bold ${isWin ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isWin ? `+$${trade.pnl.toFixed(2)}` : `-$${trade.stake.toFixed(2)}`}
                          </td>
                          <td>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold inline-flex items-center gap-1 ${
                                isWin
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {isWin ? <CheckCircle className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                              {isWin ? 'WIN 胜出' : 'LOSS 未中'}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
