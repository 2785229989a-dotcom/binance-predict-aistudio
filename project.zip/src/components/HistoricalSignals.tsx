import React, { useState } from 'react';
import { SignalRecord } from '../types/market.js';
import {
  Activity,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  PauseCircle,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Target,
} from 'lucide-react';

interface HistoricalSignalsProps {
  signals: SignalRecord[];
}

export const HistoricalSignals: React.FC<HistoricalSignalsProps> = ({ signals }) => {
  const [filterSymbol, setFilterSymbol] = useState<'ALL' | 'BTCUSDT' | 'ETHUSDT'>('ALL');
  const [filterDirection, setFilterDirection] = useState<'ALL' | 'UP' | 'DOWN' | 'WAIT'>('ALL');
  const [filterOutcome, setFilterOutcome] = useState<'ALL' | 'WIN' | 'LOSS' | 'PENDING'>('ALL');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filteredSignals = signals.filter((s) => {
    if (filterSymbol !== 'ALL' && s.symbol !== filterSymbol) return false;
    if (filterDirection !== 'ALL' && s.direction !== filterDirection) return false;
    if (filterOutcome !== 'ALL' && s.outcome !== filterOutcome) return false;
    return true;
  });

  const verified = signals.filter((s) => s.outcome === 'WIN' || s.outcome === 'LOSS');
  const wins = verified.filter((s) => s.outcome === 'WIN').length;
  const overallWinRate = verified.length > 0 ? ((wins / verified.length) * 100).toFixed(1) : '0.0';

  const upSignals = verified.filter((s) => s.direction === 'UP');
  const upWins = upSignals.filter((s) => s.outcome === 'WIN').length;
  const upWinRate = upSignals.length > 0 ? ((upWins / upSignals.length) * 100).toFixed(1) : '0.0';

  const downSignals = verified.filter((s) => s.direction === 'DOWN');
  const downWins = downSignals.filter((s) => s.outcome === 'WIN').length;
  const downWinRate = downSignals.length > 0 ? ((downWins / downSignals.length) * 100).toFixed(1) : '0.0';

  const waitCount = signals.filter((s) => s.direction === 'WAIT').length;

  return (
    <div className="space-y-6">
      {/* Accuracy Header Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">实盘已检验胜率</span>
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-1.5 font-mono text-2xl font-black text-emerald-400">
            {overallWinRate}%
          </div>
          <div className="text-[10px] text-zinc-500 mt-0.5">
            {wins} 胜 / {verified.length - wins} 负 (样本: {verified.length})
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">UP 看涨胜率</span>
            <TrendingUp className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-1.5 font-mono text-2xl font-black text-white">
            {upWinRate}%
          </div>
          <div className="text-[10px] text-zinc-500 mt-0.5">
            {upWins} 胜 / {upSignals.length} 笔
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">DOWN 看跌胜率</span>
            <TrendingDown className="h-4 w-4 text-rose-400" />
          </div>
          <div className="mt-1.5 font-mono text-2xl font-black text-white">
            {downWinRate}%
          </div>
          <div className="text-[10px] text-zinc-500 mt-0.5">
            {downWins} 胜 / {downSignals.length} 笔
          </div>
        </div>

        <div className="bg-zinc-900/70 border border-zinc-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">WAIT 观望过滤</span>
            <PauseCircle className="h-4 w-4 text-amber-400" />
          </div>
          <div className="mt-1.5 font-mono text-2xl font-black text-amber-400">
            {waitCount}
          </div>
          <div className="text-[10px] text-zinc-500 mt-0.5">过滤低胜率震荡区间</div>
        </div>
      </div>

      {/* Main Signal Table */}
      <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-4 sm:p-5 shadow-xl">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="h-4 w-4 text-amber-400" />
              10分钟信号完整生命周期与真实校验记录
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              记录触发瞬间的参考基准价 P0、预测概率、市场状态，并在 T+10m 依据真实收盘结算价 P10 验证
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Symbol Filter */}
            <select
              value={filterSymbol}
              onChange={(e) => setFilterSymbol(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-800 text-zinc-300 rounded-lg px-2.5 py-1.5"
            >
              <option value="ALL">全部币种</option>
              <option value="BTCUSDT">BTCUSDT</option>
              <option value="ETHUSDT">ETHUSDT</option>
            </select>

            {/* Direction Filter */}
            <select
              value={filterDirection}
              onChange={(e) => setFilterDirection(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-800 text-zinc-300 rounded-lg px-2.5 py-1.5"
            >
              <option value="ALL">全部方向</option>
              <option value="UP">🟢 仅看涨 UP</option>
              <option value="DOWN">🔴 仅看跌 DOWN</option>
              <option value="WAIT">⚪ 仅观望 WAIT</option>
            </select>

            {/* Outcome Filter */}
            <select
              value={filterOutcome}
              onChange={(e) => setFilterOutcome(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-800 text-zinc-300 rounded-lg px-2.5 py-1.5"
            >
              <option value="ALL">全部检验结果</option>
              <option value="WIN">仅获胜 WIN</option>
              <option value="LOSS">仅未中 LOSS</option>
              <option value="PENDING">进行中 10m</option>
            </select>
          </div>
        </div>

        {/* Signals List */}
        {filteredSignals.length === 0 ? (
          <div className="py-12 text-center text-zinc-500 text-xs">
            暂无符合条件的信号记录。系统每分钟持续监控盘口与订单流，达到入场阈值即自动入库！
          </div>
        ) : (
          <div className="overflow-x-auto pt-2">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="text-zinc-500 border-b border-zinc-800 font-mono text-[11px]">
                  <th className="py-2.5">产生时间</th>
                  <th>币种</th>
                  <th>信号方向</th>
                  <th>概率矩阵 (UP/WAIT/DOWN)</th>
                  <th>参考基准价 P0</th>
                  <th>10m结算价 P10</th>
                  <th>结算价差 (Delta)</th>
                  <th>检验结果</th>
                  <th className="text-right">详情</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60 font-mono">
                {filteredSignals.map((sig) => {
                  const dateStr = new Date(sig.timestamp).toLocaleTimeString();
                  const isWin = sig.outcome === 'WIN';
                  const isLoss = sig.outcome === 'LOSS';
                  const isPending = sig.outcome === 'PENDING';
                  const isExpanded = expandedId === sig.id;

                  return (
                    <React.Fragment key={sig.id}>
                      <tr
                        onClick={() => setExpandedId(isExpanded ? null : sig.id)}
                        className="hover:bg-zinc-800/40 cursor-pointer transition"
                      >
                        <td className="py-3 text-zinc-400">{dateStr}</td>
                        <td className="font-sans font-bold text-white">{sig.symbol}</td>
                        <td>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              sig.direction === 'UP'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : sig.direction === 'DOWN'
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            {sig.direction === 'UP'
                              ? '🟢 UP'
                              : sig.direction === 'DOWN'
                              ? '🔴 DOWN'
                              : '⚪ WAIT'}
                          </span>
                        </td>
                        <td className="text-zinc-300">
                          {sig.upProb}% / {sig.waitProb}% / {sig.downProb}%
                        </td>
                        <td className="text-amber-400 font-bold">
                          ${sig.referencePrice.toFixed(2)}
                        </td>
                        <td className="text-zinc-200">
                          {sig.settlementPrice ? `$${sig.settlementPrice.toFixed(2)}` : '等待10m结算...'}
                        </td>
                        <td>
                          {sig.priceChange !== null ? (
                            <span
                              className={`font-bold ${
                                sig.priceChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                              }`}
                            >
                              {sig.priceChange >= 0 ? '+' : ''}
                              {sig.priceChange}
                            </span>
                          ) : (
                            <span className="text-zinc-600">-</span>
                          )}
                        </td>
                        <td>
                          {isWin && (
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold inline-flex items-center gap-1 text-[10px]">
                              <CheckCircle className="h-3 w-3" /> 胜利 WIN
                            </span>
                          )}
                          {isLoss && (
                            <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold inline-flex items-center gap-1 text-[10px]">
                              <XCircle className="h-3 w-3" /> 未中 LOSS
                            </span>
                          )}
                          {isPending && (
                            <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-400 border border-sky-500/30 font-medium inline-flex items-center gap-1 text-[10px]">
                              <Clock className="h-3 w-3 animate-spin" /> 进行中...
                            </span>
                          )}
                          {sig.outcome === 'WAIT_SKIPPED' && (
                            <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-medium text-[10px]">
                              风控空仓
                            </span>
                          )}
                        </td>
                        <td className="text-right text-zinc-400">
                          {isExpanded ? <ChevronUp className="h-4 w-4 inline" /> : <ChevronDown className="h-4 w-4 inline" />}
                        </td>
                      </tr>

                      {/* Expandable row: Market Snapshot at signal time */}
                      {isExpanded && (
                        <tr className="bg-zinc-950/90 font-sans">
                          <td colSpan={9} className="p-4 border-b border-zinc-800/80">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                              <div>
                                <span className="font-bold text-zinc-200 block mb-1">
                                  产生信号时的市场状态与微观结构：
                                </span>
                                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-zinc-900 p-2.5 rounded-lg border border-zinc-800">
                                  <div>OFI 原始失衡: {sig.marketSnapshotAtSignal?.ofi ?? '---'}</div>
                                  <div>CVD 5m Delta: {sig.marketSnapshotAtSignal?.cvd ?? '---'}</div>
                                  <div>盘口买盘占比: {sig.marketSnapshotAtSignal ? (sig.marketSnapshotAtSignal.depthImbalance * 100).toFixed(1) + '%' : '---'}</div>
                                  <div>RSI(14): {sig.marketSnapshotAtSignal?.rsi ?? '---'}</div>
                                  <div>ATR(14) 波动值: ${sig.marketSnapshotAtSignal?.atr ?? '---'}</div>
                                  <div>盘口点差: ${sig.marketSnapshotAtSignal?.spread ?? '---'}</div>
                                </div>
                              </div>

                              <div>
                                <span className="font-bold text-zinc-200 block mb-1">
                                  触发归因推演：
                                </span>
                                <div className="bg-zinc-900 p-2.5 rounded-lg border border-zinc-800 text-zinc-300 text-xs leading-relaxed">
                                  {sig.factorsSummary}
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
