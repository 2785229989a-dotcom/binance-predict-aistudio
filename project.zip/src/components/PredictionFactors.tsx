import React from 'react';
import { MarketSnapshot, PredictionResult } from '../types/market.js';
import {
  Layers,
  Scale,
  Activity,
  Flame,
  LineChart,
  ShieldAlert,
  AlertTriangle,
  Info,
  CheckCircle,
  Clock,
  Compass,
} from 'lucide-react';

interface PredictionFactorsProps {
  prediction: PredictionResult | null;
  snapshot: MarketSnapshot | null;
}

export const PredictionFactors: React.FC<PredictionFactorsProps> = ({ prediction, snapshot }) => {
  if (!prediction || !snapshot) {
    return (
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 text-center text-zinc-500">
        正在计算多因子量化微观结构评分...
      </div>
    );
  }

  const {
    compositeScore,
    confidence,
    factors,
    rationale,
    direction,
    signalLevel,
    upProb,
    downProb,
    waitProb,
    regime,
    regimeLabel,
    isWait,
    waitReasons,
    multiTimeframe,
  } = prediction;

  const factorItems = [
    {
      id: 'ofi',
      name: 'OFI 订单流失衡度',
      subtitle: 'Cont & Stoikov (2014) L2 边沿挂单微观失衡',
      icon: Scale,
      score: factors.ofi.score,
      weight: factors.ofi.weight,
      raw: `原始净失衡: ${factors.ofi.value}`,
      label: factors.ofi.label,
      desc: '买一与卖一档位的挂单数量变化。正值代表买盘高频补单或卖盘撤销，看涨驱动。',
    },
    {
      id: 'cvd',
      name: 'CVD 主动买卖增量',
      subtitle: 'Cumulative Volume Delta 5m斜率与市价吃单差',
      icon: Activity,
      score: factors.cvd.score,
      weight: factors.cvd.weight,
      raw: `5m Delta: ${factors.cvd.value} | 斜率: ${factors.cvd.slope}`,
      label: factors.cvd.label,
      desc: 'Taker 主动市价吃单成交量差。正斜率代表大单在市价主动扫盘突破。',
    },
    {
      id: 'multiTf',
      name: '多周期趋势一致性',
      subtitle: '1m / 3m / 5m / 15m / 30m / 1h 协同分析',
      icon: Compass,
      score: factors.multiTf.score,
      weight: factors.multiTf.weight,
      raw: `协同分: ${factors.multiTf.alignmentScore}`,
      label: factors.multiTf.label,
      desc: '大周期定方向，短周期找拐点。若大周期看跌而短线假突破，强制触发 WAIT。',
    },
    {
      id: 'depth',
      name: 'L2 挂单深度倾斜',
      subtitle: '前20档挂单总厚度与不对称比率',
      icon: Layers,
      score: factors.depth.score,
      weight: factors.depth.weight,
      raw: `买卖比: ${factors.depth.skewRatio}:1 | 失衡率: ${factors.depth.imbalanceRatio}`,
      label: factors.depth.label,
      desc: '挂单簿托盘厚度 vs 压盘厚度。买盘厚度远大于卖盘时，下方支撑扎实。',
    },
    {
      id: 'momentum',
      name: '短周期动量与 RSI',
      subtitle: 'EMA(7)/EMA(20) 发散与 RSI(14) 动能偏离',
      icon: LineChart,
      score: factors.momentum.score,
      weight: factors.momentum.weight,
      raw: `RSI(14): ${factors.momentum.rsi} | EMA差: ${factors.momentum.emaDiff}`,
      label: factors.momentum.label,
      desc: '快速均线与慢速均线发散程度结合相对强弱指数，研判超买超卖与趋势动能。',
    },
    {
      id: 'oi',
      name: '持仓量与量价协同',
      subtitle: 'Open Interest 变动与价格走势共振',
      icon: Flame,
      score: factors.oi.score,
      weight: factors.oi.weight,
      raw: `持仓量: ${factors.oi.openInterest} | 24h变动: ${factors.oi.oiChange24h}%`,
      label: factors.oi.label,
      desc: '价格与持仓量同向增加为真突破；反向为轧空或多头踩踏平仓。',
    },
    {
      id: 'funding',
      name: '资金费率溢价偏向',
      subtitle: '8小时资金费率基差套利压力',
      icon: Info,
      score: factors.funding.score,
      weight: factors.funding.weight,
      raw: `当前费率: ${factors.funding.rate}%`,
      label: factors.funding.label,
      desc: '过高的正资金费率会加剧多头持仓成本，形成潜在获利回吐压力；负费率利于轧空。',
    },
  ];

  return (
    <div className="bg-zinc-900/70 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Top Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-amber-400" />
            10分钟多因子预测评分引擎 (透明量化归因)
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            绝非黑箱随机猜测：融合微观订单流(OFI)、主动吃单量差(CVD)、多周期共振及深度倾斜进行概率校准
          </p>
        </div>

        {/* Market Regime Badge */}
        <div className="flex items-center gap-2">
          <div className="bg-zinc-950 px-3 py-1.5 rounded-xl border border-zinc-800 text-right">
            <div className="text-[10px] text-zinc-400 font-sans">市场微观状态</div>
            <div className="font-bold text-xs text-amber-300 font-mono flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
              {regimeLabel}
            </div>
          </div>

          <div className="bg-zinc-950 px-3 py-1.5 rounded-xl border border-zinc-800 text-right font-mono">
            <div className="text-[10px] text-zinc-400 font-sans">综合评分</div>
            <div
              className={`font-black text-sm ${
                compositeScore >= 30
                  ? 'text-emerald-400'
                  : compositeScore <= -30
                  ? 'text-rose-400'
                  : 'text-zinc-400'
              }`}
            >
              {compositeScore > 0 ? `+${compositeScore}` : compositeScore} / 100
            </div>
          </div>
        </div>
      </div>

      {/* Multi-Timeframe Consistency Matrix */}
      <div className="bg-zinc-950/80 p-3 rounded-xl border border-zinc-800/80">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="font-bold text-zinc-200 flex items-center gap-1.5">
            <Compass className="h-3.5 w-3.5 text-amber-400" />
            多周期趋势协同阵列 (Multi-Timeframe Trend Matrix)
          </span>
          <span className="text-[11px] font-mono text-zinc-400">
            一致性得分: <strong className={multiTimeframe.alignmentScore > 0 ? 'text-emerald-400' : multiTimeframe.alignmentScore < 0 ? 'text-rose-400' : 'text-zinc-400'}>
              {multiTimeframe.alignmentScore > 0 ? `+${multiTimeframe.alignmentScore}` : multiTimeframe.alignmentScore}
            </strong>
          </span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-xs font-mono">
          {multiTimeframe.trends.map((t) => (
            <div
              key={t.timeframe}
              className={`p-2 rounded-lg border ${
                t.direction === 'UP'
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-400'
                  : t.direction === 'DOWN'
                  ? 'bg-rose-950/30 border-rose-500/40 text-rose-400'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400'
              }`}
            >
              <div className="text-[10px] text-zinc-500">{t.timeframe} 趋势</div>
              <div className="font-bold text-xs mt-0.5">
                {t.direction === 'UP' ? '看涨 UP' : t.direction === 'DOWN' ? '看跌 DOWN' : '震荡 NEUTRAL'}
              </div>
              <div className="text-[9px] text-zinc-500 mt-0.5">
                RSI {t.rsi}
              </div>
            </div>
          ))}
        </div>

        {multiTimeframe.hasConflict && (
          <div className="mt-2 text-[11px] text-amber-400 bg-amber-950/20 p-2 rounded border border-amber-500/30 flex items-center gap-1.5">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span>{multiTimeframe.conflictDescription} (系统自动启动风控降级)</span>
          </div>
        )}
      </div>

      {/* Strict WAIT Notice if triggered */}
      {isWait && waitReasons.length > 0 && (
        <div className="bg-amber-950/30 border border-amber-500/40 p-3.5 rounded-xl text-xs text-amber-300">
          <div className="font-bold flex items-center gap-2 mb-1 text-amber-200">
            <ShieldAlert className="h-4 w-4 text-amber-400" />
            严格 WAIT 风控机制生效中 (WAIT 是核心功能，宁愿观望也不产生低质量交易)
          </div>
          <ul className="space-y-1 text-[11px] font-sans text-amber-300/90 pl-4 list-disc">
            {waitReasons.map((reason, idx) => (
              <li key={idx}>{reason}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Factor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {factorItems.map((item) => {
          const Icon = item.icon;
          const isPos = item.score > 0;
          const isNeg = item.score < 0;
          const abs = Math.abs(item.score);

          return (
            <div
              key={item.id}
              className="bg-zinc-950/70 border border-zinc-800/80 rounded-xl p-3 hover:border-zinc-700 transition"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-amber-400">
                    <Icon className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-zinc-200">{item.name}</div>
                    <div className="text-[10px] text-zinc-500">权重: {Math.round(item.weight * 100)}%</div>
                  </div>
                </div>

                <div className="text-right">
                  <div
                    className={`font-mono text-sm font-bold ${
                      isPos ? 'text-emerald-400' : isNeg ? 'text-rose-400' : 'text-zinc-400'
                    }`}
                  >
                    {isPos ? `+${item.score}` : item.score}
                  </div>
                  <div className="text-[10px] text-zinc-400">{item.label}</div>
                </div>
              </div>

              {/* Score Bar */}
              <div className="mt-2.5 relative h-1.5 bg-zinc-800 rounded-full overflow-hidden flex">
                <div className="w-1/2 flex justify-end">
                  {isNeg && (
                    <div
                      className="h-full bg-rose-500 rounded-l"
                      style={{ width: `${Math.min(100, abs)}%` }}
                    />
                  )}
                </div>
                <div className="w-px bg-zinc-600 h-full" />
                <div className="w-1/2">
                  {isPos && (
                    <div
                      className="h-full bg-emerald-500 rounded-r"
                      style={{ width: `${Math.min(100, abs)}%` }}
                    />
                  )}
                </div>
              </div>

              <div className="mt-2 text-[10px] text-zinc-400 font-mono truncate">
                {item.raw}
              </div>

              <div className="mt-1 text-[10px] text-zinc-500 leading-relaxed border-t border-zinc-900 pt-1.5">
                {item.desc}
              </div>
            </div>
          );
        })}
      </div>

      {/* Rationale Deduction Summary */}
      <div className="bg-zinc-950/80 border border-zinc-800 rounded-xl p-3.5">
        <div className="text-xs font-semibold text-zinc-200 mb-1.5 flex items-center gap-1.5">
          <Info className="h-3.5 w-3.5 text-amber-400" />
          多因子综合推演逻辑 (实时归因分析)
        </div>
        <ul className="space-y-1 text-xs text-zinc-400">
          {rationale.map((r, i) => (
            <li key={i} className="flex items-start gap-1.5">
              <span className="text-amber-500 mt-0.5">•</span>
              <span>{r}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
