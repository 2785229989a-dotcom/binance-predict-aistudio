import React from 'react';
import { OrderBookData } from '../types/market.js';
import { Layers, ArrowDown, ArrowUp } from 'lucide-react';

interface OrderBookDepthProps {
  orderBook: OrderBookData | null;
  currentPrice: number;
}

export const OrderBookDepth: React.FC<OrderBookDepthProps> = ({ orderBook, currentPrice }) => {
  if (!orderBook) {
    return (
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-4 text-center text-zinc-500">
        正在同步 L2 盘口深度...
      </div>
    );
  }

  const { bids, asks, spread, spreadPercent, bidTotal, askTotal, imbalanceRatio } = orderBook;
  const maxTotal = Math.max(bidTotal, askTotal) || 1;

  // Render top 9 asks in descending order (highest ask at top, lowest ask near spread)
  const displayAsks = [...asks].slice(0, 9).reverse();
  // Render top 9 bids in descending order (highest bid near spread, lowest bid at bottom)
  const displayBids = bids.slice(0, 9);

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-4 shadow-lg flex flex-col justify-between">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
        <div className="flex items-center gap-1.5">
          <Layers className="h-4 w-4 text-amber-400" />
          <span className="text-xs font-bold text-white">L2 深度盘口 (Order Book)</span>
        </div>
        <span className="text-[10px] text-zinc-400 font-mono">
          买卖比: {(imbalanceRatio * 100).toFixed(1)}% / {(100 - imbalanceRatio * 100).toFixed(1)}%
        </span>
      </div>

      {/* Visual Imbalance Bar */}
      <div className="py-2">
        <div className="flex justify-between text-[10px] font-mono mb-1">
          <span className="text-emerald-400 font-bold flex items-center gap-0.5">
            <ArrowUp className="h-3 w-3" /> 买盘 {bidTotal.toFixed(1)}
          </span>
          <span className="text-rose-400 font-bold flex items-center gap-0.5">
            卖盘 {askTotal.toFixed(1)} <ArrowDown className="h-3 w-3" />
          </span>
        </div>
        <div className="h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden flex">
          <div
            className="h-full bg-emerald-500 transition-all duration-300"
            style={{ width: `${Math.min(95, Math.max(5, imbalanceRatio * 100))}%` }}
          />
          <div
            className="h-full bg-rose-500 transition-all duration-300"
            style={{ width: `${Math.min(95, Math.max(5, (1 - imbalanceRatio) * 100))}%` }}
          />
        </div>
      </div>

      {/* Book Table Headers */}
      <div className="grid grid-cols-3 text-[10px] font-medium text-zinc-500 py-1 border-y border-zinc-800/80 font-mono">
        <div>价格 (USDT)</div>
        <div className="text-right">挂单数量</div>
        <div className="text-right">累计深度</div>
      </div>

      {/* Asks (Sells) */}
      <div className="space-y-0.5 py-1">
        {displayAsks.map((ask, idx) => {
          const depthPercent = ((ask.total || ask.quantity) / maxTotal) * 100;
          return (
            <div
              key={`ask-${idx}`}
              className="grid grid-cols-3 text-xs font-mono py-0.5 relative group hover:bg-zinc-800/50 rounded"
            >
              {/* Depth background fill */}
              <div
                className="absolute right-0 top-0 bottom-0 bg-rose-950/40 rounded pointer-events-none"
                style={{ width: `${Math.min(100, depthPercent)}%` }}
              />
              <div className="text-rose-400 font-medium z-10">{ask.price.toFixed(2)}</div>
              <div className="text-right text-zinc-300 z-10">{ask.quantity.toFixed(3)}</div>
              <div className="text-right text-zinc-500 z-10 font-mono">
                {(ask.total || ask.quantity).toFixed(2)}
              </div>
            </div>
          );
        })}
      </div>

      {/* Center Spread & Current Price Bar */}
      <div className="my-1 py-1.5 px-3 bg-zinc-950 rounded border border-zinc-800/80 flex items-center justify-between font-mono">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-white">${currentPrice.toFixed(2)}</span>
          <span className="text-[10px] text-zinc-500">最新</span>
        </div>
        <div className="text-[11px] text-zinc-400">
          盘口价差: <span className="text-zinc-200">${spread.toFixed(2)}</span> ({spreadPercent.toFixed(3)}%)
        </div>
      </div>

      {/* Bids (Buys) */}
      <div className="space-y-0.5 py-1">
        {displayBids.map((bid, idx) => {
          const depthPercent = ((bid.total || bid.quantity) / maxTotal) * 100;
          return (
            <div
              key={`bid-${idx}`}
              className="grid grid-cols-3 text-xs font-mono py-0.5 relative group hover:bg-zinc-800/50 rounded"
            >
              {/* Depth background fill */}
              <div
                className="absolute right-0 top-0 bottom-0 bg-emerald-950/40 rounded pointer-events-none"
                style={{ width: `${Math.min(100, depthPercent)}%` }}
              />
              <div className="text-emerald-400 font-medium z-10">{bid.price.toFixed(2)}</div>
              <div className="text-right text-zinc-300 z-10">{bid.quantity.toFixed(3)}</div>
              <div className="text-right text-zinc-500 z-10 font-mono">
                {(bid.total || bid.quantity).toFixed(2)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
