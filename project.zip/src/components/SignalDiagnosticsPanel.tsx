import React, { useState } from 'react';
import {
  CandidateSignalDiagnostic,
  DataFeedHealthStatus,
  DiagnosticStats100,
  DurationType,
  OpportunityCandidate,
  OpportunityPoolResult,
  SymbolType,
} from '../types/market.js';
import {
  Activity,
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Clock,
  Database,
  Filter,
  Flame,
  HelpCircle,
  Layers,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  XCircle,
  Zap,
} from 'lucide-react';

interface SignalDiagnosticsPanelProps {
  candidates?: Record<SymbolType, Record<DurationType, CandidateSignalDiagnostic>> | null;
  dataHealth?: Record<SymbolType, DataFeedHealthStatus> | null;
  stats100?: DiagnosticStats100 | null;
  opportunityPool?: OpportunityPoolResult | null;
  defaultSymbol?: SymbolType;
  defaultDuration?: DurationType;
  onRefresh?: () => void;
}

export const SignalDiagnosticsPanel: React.FC<SignalDiagnosticsPanelProps> = ({
  candidates,
  dataHealth,
  stats100,
  opportunityPool,
  defaultSymbol = 'BTCUSDT',
  defaultDuration = '10m',
  onRefresh,
}) => {
  const [selectedSymbol, setSelectedSymbol] = useState<SymbolType>(defaultSymbol);
  const [selectedDuration, setSelectedDuration] = useState<DurationType | 'ALL'>(defaultDuration);
  const [viewTab, setViewTab] = useState<'pool' | 'matrix' | 'stats100' | 'datafeed' | 'audit'>('pool');

  const currentHealth = dataHealth?.[selectedSymbol];
  const symbolCandidates = candidates?.[selectedSymbol];

  const durations: DurationType[] = ['10m', '30m', '1h', '1d'];
  const activeDiag =
    selectedDuration !== 'ALL' && symbolCandidates
      ? symbolCandidates[selectedDuration]
      : symbolCandidates?.['10m'];

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Top Banner: Diagnosis Header & Quick Controls */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-950 p-4 sm:p-5 rounded-2xl border border-amber-500/30 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
                <ShieldCheck className="h-5 w-5" />
              </span>
              <div>
                <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                  <span>开单信号深度诊断模式</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono border border-amber-500/30">
                    DIAGNOSTIC MODE
                  </span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5 font-mono">
                  严格硬性门槛全景排查 · 宁缺毋滥 · 实时透视“为什么没有开单”与14项开单门槛通过率
                </p>
              </div>
            </div>
          </div>

          {/* Controls: Symbol Selector, Duration Selector & Refresh */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Symbol Buttons */}
            <div className="flex items-center bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-xs">
              <button
                onClick={() => setSelectedSymbol('BTCUSDT')}
                className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                  selectedSymbol === 'BTCUSDT'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                BTC / USDT
              </button>
              <button
                onClick={() => setSelectedSymbol('ETHUSDT')}
                className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                  selectedSymbol === 'ETHUSDT'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                ETH / USDT
              </button>
            </div>

            {/* Duration Buttons */}
            <div className="flex items-center bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-xs font-mono">
              {durations.map((d) => (
                <button
                  key={d}
                  onClick={() => setSelectedDuration(d)}
                  className={`px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                    selectedDuration === d
                      ? 'bg-zinc-800 text-white border border-zinc-700 shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {d}
                </button>
              ))}
              <button
                onClick={() => setSelectedDuration('ALL')}
                className={`px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                  selectedDuration === 'ALL'
                    ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                全周期
              </button>
            </div>

            {/* Refresh */}
            {onRefresh && (
              <button
                onClick={onRefresh}
                className="p-2 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white transition cursor-pointer"
                title="刷新诊断数据"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {/* View Switch Tabs */}
        <div className="flex items-center gap-2 mt-4 pt-4 border-t border-zinc-800/80 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setViewTab('pool')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
              viewTab === 'pool'
                ? 'bg-amber-500 text-black shadow-md'
                : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>市场机会池 & 排序去重</span>
            {opportunityPool && (
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/30 font-mono">
                {opportunityPool.rankedOpportunities?.length || 8}候选
              </span>
            )}
          </button>
          <button
            onClick={() => setViewTab('matrix')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
              viewTab === 'matrix'
                ? 'bg-amber-500 text-black shadow-md'
                : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <ShieldCheck className="h-3.5 w-3.5" />
            <span>14项开单门槛核验</span>
          </button>
          <button
            onClick={() => setViewTab('stats100')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
              viewTab === 'stats100'
                ? 'bg-amber-500 text-black shadow-md'
                : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <Filter className="h-3.5 w-3.5" />
            <span>最近100次过滤统计</span>
            {stats100 && (
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/30 font-mono">
                {stats100.totalEvaluations}次
              </span>
            )}
          </button>
          <button
            onClick={() => setViewTab('datafeed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
              viewTab === 'datafeed'
                ? 'bg-amber-500 text-black shadow-md'
                : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <Database className="h-3.5 w-3.5" />
            <span>底层数据源健康</span>
            <span
              className={`h-2 w-2 rounded-full ${
                currentHealth?.allOk ? 'bg-emerald-500' : 'bg-rose-500 animate-pulse'
              }`}
            />
          </button>
          <button
            onClick={() => setViewTab('audit')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
              viewTab === 'audit'
                ? 'bg-amber-500 text-black shadow-md'
                : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <Activity className="h-3.5 w-3.5" />
            <span>实时计算审计流水</span>
          </button>
        </div>
      </div>

      {/* Tab: 市场机会池与统一排序去重 (Opportunity Pool & Ranking) */}
      {viewTab === 'pool' && (
        <div className="space-y-4 sm:space-y-6">
          {/* Top Pool Health & Correlation Banner */}
          <div className="bg-zinc-950 rounded-2xl border border-zinc-800 p-4 sm:p-5 shadow-xl">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
              <div className="flex items-center gap-3">
                <span className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  <Layers className="h-6 w-6" />
                </span>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                    <span>全市场机会池统一排序与去重引擎</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono border border-emerald-500/30">
                      RANKING & DEDUP PIPELINE
                    </span>
                  </h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    拒绝“每个周期独立机械出一单” · 8大候选统一评分 · 跨周期同向去重 · 严选最高胜率期望值唯一机会
                  </p>
                </div>
              </div>

              {/* Correlation & Status Badges */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs flex items-center gap-2">
                  <span className="text-zinc-400">BTC-ETH 相关度:</span>
                  <span className="font-mono font-bold text-amber-300">
                    {opportunityPool
                      ? `${(opportunityPool.btcEthCorrelation * 100).toFixed(0)}%`
                      : '85%'}
                  </span>
                  <span className="text-[10px] text-zinc-500">(强同向联动)</span>
                </div>
                <div className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs flex items-center gap-2">
                  <span className="text-zinc-400">获准开单数:</span>
                  <span
                    className={`font-mono font-bold ${
                      (opportunityPool?.qualifiedSignalsToOpen?.length ?? 0) > 0
                        ? 'text-emerald-400 animate-pulse'
                        : 'text-zinc-400'
                    }`}
                  >
                    {opportunityPool?.qualifiedSignalsToOpen?.length ?? 0} 笔 (不设机械上限 · 达标即开)
                  </span>
                </div>
              </div>
            </div>

            {/* Market Decision Summary */}
            <div className="mt-4 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <ShieldAlert className="h-4 w-4 text-amber-400 shrink-0" />
                <span className="text-zinc-400">全市场决策状态：</span>
                <span className="font-bold text-white">
                  {opportunityPool?.marketStatusSummary ||
                    '当前市场无高EV确定性统计优势，全市场处于严谨空仓观望态 (WAIT)'}
                </span>
              </div>
              <span className="text-[10px] text-zinc-500 font-mono hidden md:inline">
                开单门槛: 评分≥84 · 动态校准胜率≥78~85% · Edge≥+5~8% · EV&gt;0 · 仅对外输出 [OPEN LONG]/[OPEN SHORT]/[WAIT]
              </span>
            </div>
          </div>

          {/* Opportunity Pool Candidates List (Ranked #1 to #8) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <span>8大候选交易机会实时排序表</span>
                <span className="text-zinc-600 font-mono">
                  (按综合优势分降序排列)
                </span>
              </h4>
              <span className="text-[11px] text-zinc-500 font-mono">
                刷新时间: {new Date(opportunityPool?.timestamp || Date.now()).toLocaleTimeString()}
              </span>
            </div>

            {opportunityPool?.rankedOpportunities && opportunityPool.rankedOpportunities.length > 0 ? (
              <div className="grid grid-cols-1 gap-3">
                {opportunityPool.rankedOpportunities.map((cand) => {
                  const isTop = cand.rank === 1;
                  const isOpen = cand.status === 'OPEN';
                  const isFiltered = cand.status === 'FILTERED';

                  return (
                    <div
                      key={cand.id}
                      className={`rounded-2xl p-4 sm:p-5 border transition ${
                        isOpen
                          ? 'bg-gradient-to-r from-emerald-950/40 via-zinc-950 to-zinc-950 border-emerald-500/50 shadow-lg shadow-emerald-950/30'
                          : isTop
                          ? 'bg-zinc-950 border-amber-500/40'
                          : 'bg-zinc-950/80 border-zinc-800/80 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        {/* Left: Rank, Symbol, Duration & Role */}
                        <div className="flex items-start sm:items-center gap-3">
                          <div
                            className={`h-9 w-9 rounded-xl flex items-center justify-center font-black font-mono text-sm shrink-0 border ${
                              isOpen
                                ? 'bg-emerald-500 text-black border-emerald-400'
                                : isTop
                                ? 'bg-amber-500 text-black border-amber-400'
                                : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                            }`}
                          >
                            #{cand.rank}
                          </div>

                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-sm sm:text-base font-black text-white">
                                {cand.symbol.replace('USDT', '')} / USDT
                              </span>
                              <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-amber-300 font-mono font-bold border border-zinc-700">
                                {cand.duration}
                              </span>
                              <span
                                className={`text-xs px-2.5 py-0.5 rounded font-bold border ${
                                  cand.candidateDirection === 'UP'
                                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                                    : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                                }`}
                              >
                                {cand.candidateDirection === 'UP' ? '买涨 (UP)' : '买跌 (DOWN)'}
                              </span>

                              {/* Strength Level Pill */}
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded font-black border ${
                                  cand.strengthLevel === 'VERY_STRONG'
                                    ? 'bg-emerald-500/30 text-emerald-300 border-emerald-500/60 shadow-sm'
                                    : cand.strengthLevel === 'STRONG'
                                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                                    : cand.strengthLevel === 'VALID'
                                    ? 'bg-sky-500/20 text-sky-400 border-sky-500/30'
                                    : cand.strengthLevel === 'WEAK'
                                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                                    : cand.strengthLevel === 'WATCH'
                                    ? 'bg-zinc-800 text-zinc-300 border-zinc-700'
                                    : 'bg-zinc-900 text-zinc-500 border-zinc-800'
                                }`}
                              >
                                等级: {cand.strengthLevel}
                              </span>

                              {/* Status Badge: Strictly OPEN LONG / OPEN SHORT / WAIT */}
                              <span
                                className={`text-[10px] px-2.5 py-0.5 rounded font-black border ${
                                  isOpen
                                    ? cand.candidateDirection === 'UP'
                                      ? 'bg-emerald-500 text-black border-emerald-400 animate-pulse'
                                      : 'bg-rose-500 text-black border-rose-400 animate-pulse'
                                    : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                                }`}
                              >
                                {isOpen
                                  ? cand.candidateDirection === 'UP'
                                    ? '🟢 OPEN LONG'
                                    : '🔴 OPEN SHORT'
                                  : '⚪ WAIT'}
                              </span>
                            </div>

                            <p className="text-[11px] text-zinc-400 mt-1 font-mono">
                              {cand.timeframeRole}
                            </p>
                          </div>
                        </div>

                        {/* Middle & Right: Key Metrics Strip & Actions */}
                        <div className="flex flex-wrap items-center gap-3 sm:gap-6">
                          {/* Signal Score */}
                          <div className="text-right">
                            <span className="text-[10px] text-zinc-500 block">综合评分</span>
                            <span
                              className={`text-base font-black font-mono ${
                                cand.signalScore >= 85
                                  ? 'text-emerald-400'
                                  : cand.signalScore >= 70
                                  ? 'text-amber-400'
                                  : 'text-zinc-400'
                              }`}
                            >
                              {cand.signalScore}
                              <span className="text-[10px] text-zinc-600 font-normal">/100</span>
                            </span>
                          </div>

                          {/* Calibrated Win Prob vs Break-even */}
                          <div className="text-right">
                            <span className="text-[10px] text-zinc-500 block">校准胜率 / 平衡点</span>
                            <span className="text-xs font-mono font-bold text-white">
                              <span
                                className={
                                  cand.calibratedProbability >= 75
                                    ? 'text-emerald-400 font-black'
                                    : 'text-zinc-300'
                                }
                              >
                                {cand.calibratedProbability}%
                              </span>
                              <span className="text-zinc-600"> / {cand.marketProbability}%</span>
                            </span>
                          </div>

                          {/* Edge */}
                          <div className="text-right">
                            <span className="text-[10px] text-zinc-500 block">统计优势 Edge</span>
                            <span
                              className={`text-xs font-mono font-bold ${
                                cand.edge >= 8.0
                                  ? 'text-emerald-400 font-black'
                                  : cand.edge > 0
                                  ? 'text-amber-300'
                                  : 'text-rose-400'
                              }`}
                            >
                              {cand.edge > 0 ? `+${cand.edge}%` : `${cand.edge}%`}
                            </span>
                          </div>

                          {/* Expected Value */}
                          <div className="text-right">
                            <span className="text-[10px] text-zinc-500 block">期望值 EV</span>
                            <span
                              className={`text-xs font-mono font-bold ${
                                cand.expectedValue >= 8.0
                                  ? 'text-emerald-400 font-black'
                                  : cand.expectedValue > 0
                                  ? 'text-amber-300'
                                  : 'text-rose-400'
                              }`}
                            >
                              {cand.expectedValue > 0
                                ? `+$${cand.expectedValue}U`
                                : `$${cand.expectedValue}U`}
                            </span>
                          </div>

                          {/* Inspect in 14-matrix button */}
                          <button
                            onClick={() => {
                              setSelectedSymbol(cand.symbol);
                              setSelectedDuration(cand.duration);
                              setViewTab('matrix');
                            }}
                            className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-300 hover:text-white transition cursor-pointer shrink-0"
                          >
                            查看14项核验 →
                          </button>
                        </div>
                      </div>

                      {/* Detail Reason Box */}
                      <div className="mt-3 pt-3 border-t border-zinc-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="text-zinc-500 shrink-0">状态决策与原因:</span>
                          <span
                            className={
                              isOpen
                                ? 'text-emerald-400 font-bold'
                                : 'text-amber-300'
                            }
                          >
                            {isOpen
                              ? `✓ ${cand.candidateDirection === 'UP' ? 'OPEN LONG' : 'OPEN SHORT'}: 通过完整决策链全部门槛，具备高统计优势 (EV: +$${cand.expectedValue}U, Edge: +${cand.edge}%)`
                              : `WAIT: ${cand.filterReason || cand.rejectionReasons[0] || '综合条件未达及格线'}`}
                          </span>
                        </div>

                        {cand.keyFactors && cand.keyFactors.length > 0 && (
                          <div className="text-[11px] text-zinc-500 font-mono truncate max-w-md">
                            {cand.keyFactors[0]}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center text-zinc-500 bg-zinc-950 rounded-2xl border border-zinc-850 font-mono text-xs">
                暂无机会池候选数据，数据正在接入计算中...
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 1: 14项开单门槛与候选信号诊断 */}
      {viewTab === 'matrix' && (
        <div className="space-y-4 sm:space-y-6">
          {/* Active Candidate Status & Why No Order Box */}
          {selectedDuration !== 'ALL' && activeDiag ? (
            <div className="bg-zinc-950 rounded-2xl border border-zinc-800/80 p-4 sm:p-5 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800/80">
                <div className="flex items-center gap-3">
                  <div
                    className={`h-3 w-3 rounded-full ${
                      activeDiag.isQualified
                        ? 'bg-emerald-500 animate-ping'
                        : 'bg-zinc-400'
                    }`}
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-base text-white">
                        {activeDiag.symbol} · {activeDiag.duration} 候选信号诊断
                      </span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded font-black ${
                          activeDiag.direction === 'UP'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : activeDiag.direction === 'DOWN'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                        }`}
                      >
                        当前判定: {activeDiag.direction === 'UP' ? '🟢 买涨 / UP' : activeDiag.direction === 'DOWN' ? '🔴 买跌 / DOWN' : '⚪ WAIT 观望'}
                      </span>
                    </div>
                    <div className="text-xs text-zinc-400 mt-0.5 flex items-center gap-2">
                      <span>最高概率倾向:</span>
                      <strong className={activeDiag.candidateDirection === 'UP' ? 'text-emerald-400' : 'text-rose-400'}>
                        {activeDiag.candidateDirection === 'UP' ? '买涨 (UP)' : '买跌 (DOWN)'}
                      </strong>
                      <span>• 综合评分:</span>
                      <strong className={activeDiag.compositeScore >= 85 ? 'text-emerald-400' : 'text-amber-400'}>
                        {activeDiag.compositeScore} / 100
                      </strong>
                      <span className="text-zinc-600">(开单门槛: 85分)</span>
                    </div>
                  </div>
                </div>

                {/* Probability Pills */}
                <div className="flex items-center gap-2 font-mono text-xs">
                  <div className="bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-800">
                    <span className="text-zinc-500 block text-[10px]">UP 概率</span>
                    <strong className="text-emerald-400 text-sm">{activeDiag.upProb.toFixed(1)}%</strong>
                  </div>
                  <div className="bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-800">
                    <span className="text-zinc-500 block text-[10px]">DOWN 概率</span>
                    <strong className="text-rose-400 text-sm">{activeDiag.downProb.toFixed(1)}%</strong>
                  </div>
                  <div className="bg-zinc-900 px-3 py-1.5 rounded-xl border border-zinc-800">
                    <span className="text-zinc-500 block text-[10px]">WAIT 概率</span>
                    <strong className="text-zinc-400 text-sm">{activeDiag.waitProb.toFixed(1)}%</strong>
                  </div>
                </div>
              </div>

              {/* Core Feature: 为什么没有开单 (Why No Order Placed) */}
              <div
                className={`p-4 rounded-xl border ${
                  activeDiag.isQualified
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/15 border-rose-500/30 text-rose-200'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  {activeDiag.isQualified ? (
                    <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-1.5 flex-1">
                    <div className="font-bold text-sm flex items-center justify-between">
                      <span>
                        {activeDiag.isQualified
                          ? '✅ 满足全部 14 项开单硬性门槛，已触发正式开单信号！'
                          : '【未达到正式开单条件 · 策略执行空仓保护】'}
                      </span>
                      <span className="text-xs font-mono font-normal text-zinc-400">
                        通过项: {activeDiag.conditions.filter((c) => c.passed).length} / {activeDiag.conditions.length}
                      </span>
                    </div>

                    {!activeDiag.isQualified && (
                      <div className="mt-2 space-y-1.5 text-xs font-mono">
                        <span className="text-zinc-400 font-sans block text-[11px]">
                          未开单拦截原因明细 (任一不满足均空仓保护):
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1">
                          {activeDiag.rejectionReasons.map((reason, idx) => (
                            <div
                              key={idx}
                              className="bg-black/40 px-2.5 py-1.5 rounded-lg border border-rose-500/20 text-rose-300 text-[11px] flex items-center gap-1.5"
                            >
                              <span className="text-rose-400 shrink-0">•</span>
                              <span>{reason}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {activeDiag.isQualified && activeDiag.confirmations.length > 0 && (
                      <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                        {activeDiag.confirmations.map((conf, idx) => (
                          <div
                            key={idx}
                            className="bg-black/40 px-2.5 py-1.5 rounded-lg border border-emerald-500/30 text-emerald-300 text-[11px]"
                          >
                            {conf}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* 14 项全景门槛表格/卡片矩阵 */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold text-zinc-300 flex items-center gap-2">
                    <Layers className="h-4 w-4 text-amber-400" />
                    <span>14 大硬性开单门槛逐项核验结果 (14-Point Checklist)</span>
                  </h3>
                  <span className="text-[11px] font-mono text-zinc-500">
                    宁缺毋滥 · 必须 100% 通过方可开单
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {activeDiag.conditions.map((cond) => (
                    <div
                      key={cond.id}
                      className={`p-3 rounded-xl border text-xs font-mono flex flex-col justify-between space-y-1.5 transition ${
                        cond.passed
                          ? 'bg-zinc-900/60 border-emerald-500/30 text-zinc-300'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white flex items-center gap-1.5">
                          {cond.passed ? (
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                          ) : (
                            <XCircle className="h-3.5 w-3.5 text-rose-500" />
                          )}
                          <span>{cond.name}</span>
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                            cond.passed
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {cond.passed ? '✅ 通过' : '❌ 未通过'}
                        </span>
                      </div>

                      <div className="text-[11px] text-zinc-300 bg-black/40 px-2 py-1 rounded border border-zinc-900 flex items-center justify-between">
                        <span className="text-zinc-500">当前实测:</span>
                        <strong className={cond.passed ? 'text-emerald-300' : 'text-rose-300'}>
                          {cond.value}
                        </strong>
                      </div>

                      <div className="text-[10px] text-zinc-500 flex items-center justify-between pt-0.5">
                        <span>门槛标准:</span>
                        <span className="text-zinc-400 truncate max-w-[150px]">{cond.threshold}</span>
                      </div>

                      <div className="text-[10px] text-zinc-600 line-clamp-1" title={cond.detail}>
                        {cond.detail}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* 全周期对比视图 (All Durations Overview) */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {durations.map((dur) => {
                const diag = symbolCandidates?.[dur];
                if (!diag) return null;
                const passedCount = diag.conditions.filter((c) => c.passed).length;

                return (
                  <div
                    key={dur}
                    className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 font-mono text-xs space-y-3"
                  >
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                      <div className="flex items-center gap-2">
                        <strong className="text-white text-sm">
                          {selectedSymbol} · {dur}
                        </strong>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                            diag.direction === 'UP'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : diag.direction === 'DOWN'
                              ? 'bg-rose-500/20 text-rose-400'
                              : 'bg-zinc-800 text-zinc-400'
                          }`}
                        >
                          {diag.direction === 'UP' ? 'UP 买涨' : diag.direction === 'DOWN' ? 'DOWN 买跌' : 'WAIT 观望'}
                        </span>
                      </div>
                      <span className="text-amber-400 font-bold">
                        评分: {diag.compositeScore} / 100
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-1 text-[11px] text-center bg-zinc-900/60 p-2 rounded-lg">
                      <div>
                        <span className="text-zinc-500 block text-[9px]">UP</span>
                        <strong className="text-emerald-400">{diag.upProb.toFixed(1)}%</strong>
                      </div>
                      <div>
                        <span className="text-zinc-500 block text-[9px]">DOWN</span>
                        <strong className="text-rose-400">{diag.downProb.toFixed(1)}%</strong>
                      </div>
                      <div>
                        <span className="text-zinc-500 block text-[9px]">门槛通过</span>
                        <strong className={passedCount === 14 ? 'text-emerald-400' : 'text-zinc-400'}>
                          {passedCount} / 14
                        </strong>
                      </div>
                    </div>

                    <div className="text-[11px] space-y-1">
                      <span className="text-zinc-500 text-[10px] block">未开单拦截原因:</span>
                      {diag.rejectionReasons.slice(0, 3).map((r, i) => (
                        <div key={i} className="text-rose-300 text-[10px] truncate">
                          {r}
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={() => setSelectedDuration(dur)}
                      className="w-full py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-amber-400 text-center font-bold text-xs transition cursor-pointer"
                    >
                      查看 14 项完整核验清单 →
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: 最近 100 次预测过滤漏斗与统计 (Filter Statistics) */}
      {viewTab === 'stats100' && stats100 && (
        <div className="bg-zinc-950 rounded-2xl border border-zinc-800/80 p-4 sm:p-5 shadow-xl space-y-5 font-mono">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-3">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <Filter className="h-4 w-4 text-amber-400" />
                <span>最近 100 次预测过滤漏斗分析 (Rolling 100 Evaluations)</span>
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                实时统计每一个核心条件过滤了多少信号，排查是否存在“AND条件过严”或单项门槛卡死
              </p>
            </div>
            <div className="text-xs text-zinc-400 bg-zinc-900 px-3 py-1 rounded-lg border border-zinc-800">
              当前累计样本: <strong className="text-amber-400">{stats100.totalEvaluations}</strong> 次
            </div>
          </div>

          {/* Metric Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {[
              {
                name: '模型概率通过',
                count: stats100.modelProbPassed,
                color: 'text-amber-400',
                desc: '概率 >= 75.0%',
              },
              {
                name: '多周期共振通过',
                count: stats100.multiTfPassed,
                color: 'text-sky-400',
                desc: '无趋势逆风冲突',
              },
              {
                name: 'CVD 主动突破',
                count: stats100.cvdPassed,
                color: 'text-emerald-400',
                desc: '主动吃单得分>=10',
              },
              {
                name: 'OFI 订单流通过',
                count: stats100.ofiPassed,
                color: 'text-indigo-400',
                desc: '盘口挂单失衡>=10',
              },
              {
                name: 'Order Book 深度',
                count: stats100.orderBookPassed,
                color: 'text-teal-400',
                desc: '买卖占比无压单',
              },
              {
                name: 'OI 持仓量结构',
                count: stats100.oiPassed,
                color: 'text-purple-400',
                desc: '非插针爆仓异常',
              },
              {
                name: '波动率安全边际',
                count: stats100.volatilityPassed,
                color: 'text-blue-400',
                desc: '非极端洗盘ATR',
              },
              {
                name: 'EV 正期望优势',
                count: stats100.evPassed,
                color: 'text-yellow-400',
                desc: 'EV>10U, Edge>10%',
              },
              {
                name: '最终正式开单',
                count: stats100.formalOrdersCreated,
                color: 'text-emerald-400',
                desc: '通过全部门槛产生单',
                highlight: true,
              },
            ].map((stat, idx) => {
              const total = stats100.totalEvaluations || 1;
              const pct = ((stat.count / total) * 100).toFixed(1);

              return (
                <div
                  key={idx}
                  className={`p-3 rounded-xl border text-xs flex flex-col justify-between space-y-1.5 ${
                    stat.highlight
                      ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                      : 'bg-zinc-900/60 border-zinc-800 text-zinc-300'
                  }`}
                >
                  <span className="text-[11px] text-zinc-400">{stat.name}</span>
                  <div className="flex items-baseline justify-between">
                    <strong className={`text-base sm:text-lg font-black ${stat.color}`}>
                      {stat.count}
                    </strong>
                    <span className="text-zinc-500 text-[10px]">({pct}%)</span>
                  </div>

                  {/* Visual Bar */}
                  <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        stat.highlight ? 'bg-emerald-400' : 'bg-amber-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  <span className="text-[9px] text-zinc-600 block">{stat.desc}</span>
                </div>
              );
            })}
          </div>

          <div className="bg-zinc-900/40 p-3 rounded-xl border border-zinc-800/80 text-xs text-zinc-400 flex items-center gap-2">
            <HelpCircle className="h-4 w-4 text-amber-400 shrink-0" />
            <span>
              数据解读：如果“最终正式开单”为0，请对比上方各指标通过率。哪个指标通过率最低，即代表当前市场该维度最不满足严格条件（例如“OFI”或“模型概率”）。
            </span>
          </div>
        </div>
      )}

      {/* Tab 3: 底层数据源实时健康监测 (Data Feed Health) */}
      {viewTab === 'datafeed' && currentHealth && (
        <div className="bg-zinc-950 rounded-2xl border border-zinc-800/80 p-4 sm:p-5 shadow-xl space-y-4 font-mono">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <Database className="h-4 w-4 text-emerald-400" />
                <span>{selectedSymbol} 底层高频数据源真实性与健康度校验</span>
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                若任何数据获取失败，系统将明确报错并停止预测，绝不使用假数据或随机模拟
              </p>
            </div>
            <span
              className={`text-xs px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 ${
                currentHealth.allOk
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              }`}
            >
              {currentHealth.allOk ? '✅ 全部数据源正常' : '❌ 存在异常数据源'}
            </span>
          </div>

          {/* Feed Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {currentHealth.items.map((item, idx) => (
              <div
                key={idx}
                className={`p-3.5 rounded-xl border text-xs flex flex-col justify-between space-y-2 ${
                  item.status === 'OK'
                    ? 'bg-zinc-900/50 border-emerald-500/20 text-zinc-300'
                    : 'bg-rose-950/20 border-rose-500/40 text-rose-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <strong className="text-white flex items-center gap-1.5">
                    {item.status === 'OK' ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    ) : (
                      <XCircle className="h-4 w-4 text-rose-400" />
                    )}
                    <span>{item.name}</span>
                  </strong>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                      item.status === 'OK'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-rose-500/20 text-rose-300'
                    }`}
                  >
                    {item.status === 'OK' ? '✅ 正常' : '❌ 失败'}
                  </span>
                </div>

                <div className="bg-black/40 px-2.5 py-1.5 rounded-lg border border-zinc-900 flex items-center justify-between">
                  <span className="text-zinc-500">实测取值:</span>
                  <strong className="text-amber-300">{item.value ?? '---'}</strong>
                </div>

                <div className="text-[11px] text-zinc-400">
                  {item.message}
                </div>

                <div className="text-[9px] text-zinc-600 flex items-center justify-between pt-1 border-t border-zinc-900">
                  <span>更新时间:</span>
                  <span>{new Date(item.lastUpdated).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: 实时计算审计流水 (Real-time Calculation Audit Log) */}
      {viewTab === 'audit' && stats100 && (
        <div className="bg-zinc-950 rounded-2xl border border-zinc-800/80 p-4 sm:p-5 shadow-xl space-y-4 font-mono">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <Activity className="h-4 w-4 text-amber-400" />
                <span>实时量化模型判定审计流水 (Live Audit Stream)</span>
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                记录每一次高频评定：币种、周期、概率、综合评分、通过条件数与拦截原因
              </p>
            </div>
            <span className="text-xs text-zinc-500">保留最新 30 条</span>
          </div>

          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full text-left text-xs text-zinc-300">
              <thead className="bg-zinc-900 text-zinc-400 text-[11px] border-b border-zinc-800">
                <tr>
                  <th className="py-2 px-3">时间</th>
                  <th className="py-2 px-3">标的</th>
                  <th className="py-2 px-3">周期</th>
                  <th className="py-2 px-3">候选倾向</th>
                  <th className="py-2 px-3">概率 (UP/DOWN/WAIT)</th>
                  <th className="py-2 px-3">综合评分</th>
                  <th className="py-2 px-3">门槛通过</th>
                  <th className="py-2 px-3">最终结果</th>
                  <th className="py-2 px-3">主要拦截原因</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-900 text-[11px]">
                {stats100.recentLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-zinc-900/40 transition">
                    <td className="py-2 px-3 text-zinc-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </td>
                    <td className="py-2 px-3 font-bold text-white whitespace-nowrap">
                      {log.symbol.replace('USDT', '')}
                    </td>
                    <td className="py-2 px-3 text-amber-400 font-bold whitespace-nowrap">
                      {log.duration}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span
                        className={
                          log.candidateDirection === 'UP' ? 'text-emerald-400' : 'text-rose-400'
                        }
                      >
                        {log.candidateDirection === 'UP' ? '买涨 (UP)' : '买跌 (DOWN)'}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-zinc-400 whitespace-nowrap">
                      {log.upProb.toFixed(0)}% / {log.downProb.toFixed(0)}% / {log.waitProb.toFixed(0)}%
                    </td>
                    <td className="py-2 px-3 font-bold whitespace-nowrap">
                      <span className={log.compositeScore >= 85 ? 'text-emerald-400' : 'text-zinc-300'}>
                        {log.compositeScore}
                      </span>
                      <span className="text-zinc-600">/100</span>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span className={log.passedConditions === 14 ? 'text-emerald-400 font-bold' : 'text-zinc-400'}>
                        {log.passedConditions} / {log.totalConditions}
                      </span>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          log.isFormalSignal
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {log.isFormalSignal ? '🟢 正式开单' : '⚪ WAIT'}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-rose-300 truncate max-w-[280px]" title={log.mainRejectReason}>
                      {log.mainRejectReason || '---'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
