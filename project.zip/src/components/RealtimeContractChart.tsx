import React, { useState, useMemo, useEffect } from 'react';
import {
  DurationType,
  KlineData,
  MarketSnapshot,
  PaperTrade,
  PredictionResult,
  SignalOrder,
  SignalRecord,
  SymbolType,
} from '../types/market.js';
import {
  TrendingUp,
  TrendingDown,
  Clock,
  Target,
  AlertTriangle,
  Zap,
  Percent,
  CheckCircle2,
  XCircle,
  MinusCircle,
  ArrowRight,
  ShieldCheck,
  Activity,
} from 'lucide-react';

interface RealtimeContractChartProps {
  symbol: SymbolType;
  snapshot: MarketSnapshot | null;
  activeDuration: DurationType;
  onChangeDuration: (dur: DurationType) => void;
  trades: PaperTrade[];
  signals?: SignalRecord[];
  signalOrders?: SignalOrder[];
  onPlaceTrade: (
    symbol: SymbolType,
    direction: 'UP' | 'DOWN',
    stake: number,
    duration: DurationType,
    payoutRatio: number,
    modelProb: number,
    signalId?: string
  ) => void;
}

export const RealtimeContractChart: React.FC<RealtimeContractChartProps> = ({
  symbol,
  snapshot,
  activeDuration,
  onChangeDuration,
  trades,
  signals = [],
  signalOrders = [],
  onPlaceTrade,
}) => {
  // K-Line timeframe: Default is 5m as requested by user
  const [klineTf, setKlineTf] = useState<'1m' | '5m' | '15m' | '30m' | '1h'>('5m');
  const [selectedStake, setSelectedStake] = useState<number>(100);
  const [selectedSignalDetail, setSelectedSignalDetail] = useState<any | null>(null);

  // Local clock tick to ensure countdowns update every second with zero drift
  const [currentTime, setCurrentTime] = useState<number>(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const rawKlines = snapshot?.recentKlines || [];
  const currentPrice = snapshot?.price || 0;
  const p0 = snapshot?.currentRound?.lockPrice || currentPrice;

  // Active prediction for the selected contract duration
  const pred: PredictionResult | null =
    (snapshot?.predictions && snapshot.predictions[activeDuration]) ||
    snapshot?.prediction ||
    null;

  // Find currently ACTIVE or WAITING_ENTRY signal order for this symbol and duration
  const activeSignalOrder = useMemo(() => {
    return signalOrders.find(
      (s) =>
        s.symbol === symbol &&
        s.duration === activeDuration &&
        (s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY')
    );
  }, [signalOrders, symbol, activeDuration]);

  // Find most recent SETTLED signal order for this symbol and duration
  const recentSettledSignal = useMemo(() => {
    return signalOrders.find(
      (s) => s.symbol === symbol && s.duration === activeDuration && s.status === 'SETTLED'
    );
  }, [signalOrders, symbol, activeDuration]);

  // Dynamic Payout Ratios
  const payoutRatio =
    activeSignalOrder?.payoutRatio ??
    (pred?.payoutRatio !== undefined
      ? pred.payoutRatio
      : activeDuration === '10m'
      ? 0.8
      : 0.85);

  const breakEvenProb =
    activeSignalOrder?.breakEvenProb ??
    (pred?.breakEvenProb ?? Number(((100 / (100 + payoutRatio * 100)) * 100).toFixed(2)));

  const modelProb =
    activeSignalOrder?.modelProb ??
    (pred?.direction === 'UP'
      ? pred.upProb
      : pred?.direction === 'DOWN'
      ? pred.downProb
      : Math.max(pred?.upProb || 0, pred?.downProb || 0));

  const edge =
    activeSignalOrder?.edge ??
    (pred?.edge ?? Number((modelProb - breakEvenProb).toFixed(2)));

  const expectedValue =
    activeSignalOrder?.expectedValue ??
    (pred?.expectedValue ??
      Number(
        ((modelProb / 100) * (selectedStake * payoutRatio) -
          ((100 - modelProb) / 100) * selectedStake).toFixed(2)
      ));

  // Dynamic aggregation from 1m raw klines into selected viewing timeframe
  const displayKlines = useMemo(() => {
    if (!rawKlines || rawKlines.length === 0) return [];
    if (klineTf === '1m') return rawKlines;

    const groupSize = klineTf === '5m' ? 5 : klineTf === '15m' ? 15 : klineTf === '30m' ? 30 : 60;
    const aggregated: KlineData[] = [];

    for (let i = 0; i < rawKlines.length; i += groupSize) {
      const slice = rawKlines.slice(i, i + groupSize);
      if (slice.length === 0) continue;
      const open = slice[0].open;
      const close = slice[slice.length - 1].close;
      const high = Math.max(...slice.map((s) => s.high));
      const low = Math.min(...slice.map((s) => s.low));
      const volume = slice.reduce((acc, s) => acc + s.volume, 0);
      const quoteVolume = slice.reduce((acc, s) => acc + s.quoteVolume, 0);
      const buyVolume = slice.reduce((acc, s) => acc + s.buyVolume, 0);
      const sellVolume = slice.reduce((acc, s) => acc + s.sellVolume, 0);
      const cvd = slice[slice.length - 1].cvd;

      aggregated.push({
        time: slice[0].time,
        open,
        high,
        low,
        close,
        volume,
        quoteVolume,
        buyVolume,
        sellVolume,
        cvd,
      });
    }
    return aggregated;
  }, [rawKlines, klineTf]);

  const candleMs =
    (klineTf === '1m' ? 1 : klineTf === '5m' ? 5 : klineTf === '15m' ? 15 : klineTf === '30m' ? 30 : 60) *
    60 *
    1000;

  // Chart dimensions & scaling
  const chartHeight = 220;
  const volumeHeight = 50;
  const totalSvgHeight = chartHeight + volumeHeight + 25;
  const svgWidth = 720;

  const { minPrice, maxPrice, maxVolume } = useMemo(() => {
    if (displayKlines.length === 0) {
      return { minPrice: 0, maxPrice: 1, maxVolume: 1 };
    }
    const lows = displayKlines.map((k) => k.low);
    const highs = displayKlines.map((k) => k.high);
    if (currentPrice > 0) {
      lows.push(currentPrice);
      highs.push(currentPrice);
    }
    if (p0 > 0) {
      lows.push(p0);
      highs.push(p0);
    }
    if (activeSignalOrder?.entryPriceIndex) {
      lows.push(activeSignalOrder.entryPriceIndex);
      highs.push(activeSignalOrder.entryPriceIndex);
    }
    const minP = Math.min(...lows) * 0.9995;
    const maxP = Math.max(...highs) * 1.0005;
    const maxV = Math.max(...displayKlines.map((k) => k.volume), 1);
    return { minPrice: minP, maxPrice: maxP, maxVolume: maxV };
  }, [displayKlines, currentPrice, p0, activeSignalOrder]);

  const priceRange = maxPrice - minPrice || 1;
  const getY = (price: number) => {
    return chartHeight - ((price - minPrice) / priceRange) * chartHeight;
  };
  const getVolY = (vol: number) => {
    return chartHeight + volumeHeight - (vol / maxVolume) * volumeHeight;
  };

  const candleCount = displayKlines.length;
  const candleGap = svgWidth / (candleCount || 1);
  const candleWidth = Math.max(3, Math.min(14, candleGap * 0.7));

  // Determine Signal State
  const isUp = activeSignalOrder ? activeSignalOrder.direction === 'UP' : pred?.direction === 'UP';
  const isDown = activeSignalOrder ? activeSignalOrder.direction === 'DOWN' : pred?.direction === 'DOWN';
  const isWait = !activeSignalOrder && (!pred || pred.direction === 'WAIT');

  const durationLabel =
    activeDuration === '10m'
      ? '10分钟'
      : activeDuration === '30m'
      ? '30分钟'
      : activeDuration === '1h'
      ? '1小时'
      : '1天';

  // Entry Price & Price Delta Calculation
  const entryPrice = activeSignalOrder?.entryPriceIndex ?? p0;
  const priceDelta = currentPrice - entryPrice;
  const deltaSign = priceDelta >= 0 ? '+' : '';
  const isFavorable =
    activeSignalOrder &&
    ((activeSignalOrder.direction === 'UP' && priceDelta > 0) ||
      (activeSignalOrder.direction === 'DOWN' && priceDelta < 0));

  // Real Countdown calculation based on actual timestamps
  const remainingSeconds = activeSignalOrder
    ? activeSignalOrder.status === 'WAITING_ENTRY'
      ? Math.max(0, Math.ceil((activeSignalOrder.entryTime - currentTime) / 1000))
      : Math.max(0, Math.floor((activeSignalOrder.expiryTime - currentTime) / 1000))
    : 0;

  const remMin = Math.floor(remainingSeconds / 60);
  const remSec = remainingSeconds % 60;
  const countdownFormatted = `${String(remMin).padStart(2, '0')}:${String(remSec).padStart(2, '0')}`;

  // Visible Signals on Chart: map historical signal orders to candles
  const visibleSignalMarkers = useMemo(() => {
    if (displayKlines.length === 0 || signalOrders.length === 0) return [];
    const markers: {
      candleIndex: number;
      order: SignalOrder;
      x: number;
      isUp: boolean;
      candle: KlineData;
    }[] = [];

    // Filter relevant signal orders for this symbol & duration
    const relevantOrders = signalOrders
      .filter((o) => o.symbol === symbol && o.duration === activeDuration)
      .slice(0, 30);

    relevantOrders.forEach((ord) => {
      const targetTime = ord.signalTime || ord.entryTime;
      const idx = displayKlines.findIndex(
        (c) => targetTime >= c.time && targetTime < c.time + candleMs
      );
      if (idx !== -1) {
        // avoid overlapping multiple markers on same candle
        if (!markers.some((m) => m.candleIndex === idx)) {
          markers.push({
            candleIndex: idx,
            order: ord,
            x: idx * candleGap + candleGap / 2,
            isUp: ord.direction === 'UP',
            candle: displayKlines[idx],
          });
        }
      }
    });

    return markers;
  }, [displayKlines, signalOrders, symbol, activeDuration, candleGap, candleMs]);

  return (
    <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-3.5 sm:p-5 shadow-2xl relative">
      {/* Top Bar: Symbol, K-Line Timeframe Selector, Contract Duration Selector, Payout Ratio */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-zinc-800/80">
        {/* Symbol & Price */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span
              className={`h-3 w-3 rounded-full ${
                symbol === 'BTCUSDT' ? 'bg-amber-400' : 'bg-sky-400'
              } animate-pulse`}
            />
            <h2 className="text-lg sm:text-xl font-black text-white tracking-tight font-mono">
              {symbol}
            </h2>
            <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 font-mono">
              实时K线
            </span>
          </div>

          <div className="flex items-baseline gap-2 font-mono">
            <span className="text-lg sm:text-xl font-black text-white">
              ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span
              className={`text-xs font-bold ${
                (snapshot?.priceChangePercent24h || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {(snapshot?.priceChangePercent24h || 0) >= 0 ? '+' : ''}
              {snapshot?.priceChangePercent24h?.toFixed(2)}%
            </span>
          </div>
        </div>

        {/* Controls: K-Line Timeframe vs Event Contract Duration */}
        <div className="flex flex-wrap items-center gap-3">
          {/* 1. K-Line viewing period selector (观察周期) */}
          <div className="flex items-center gap-1.5 bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-xs">
            <span className="text-[10px] text-zinc-500 font-sans pl-1 hidden sm:inline">
              K线周期:
            </span>
            {(['1m', '5m', '15m', '30m', '1h'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setKlineTf(tf)}
                className={`px-2 py-0.5 rounded-lg font-mono text-[11px] font-bold transition ${
                  klineTf === tf
                    ? 'bg-amber-400 text-zinc-950 shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
                title={`切换观察市场特征的${tf} K线蜡烛图`}
              >
                {tf}
              </button>
            ))}
          </div>

          {/* 2. Event Contract Expiry Duration selector (事件合约期限) */}
          <div className="flex items-center gap-1.5 bg-zinc-950 p-1 rounded-xl border border-amber-500/30 text-xs">
            <span className="text-[10px] text-amber-400 font-bold font-sans pl-1 flex items-center gap-1">
              <Clock className="h-3 w-3" /> 合约期限:
            </span>
            {(
              [
                { id: '10m', label: '10分钟' },
                { id: '30m', label: '30分钟' },
                { id: '1h', label: '1小时' },
                { id: '1d', label: '1天' },
              ] as const
            ).map((dur) => (
              <button
                key={dur.id}
                onClick={() => onChangeDuration(dur.id)}
                className={`px-2.5 py-0.5 rounded-lg font-bold text-[11px] transition ${
                  activeDuration === dur.id
                    ? 'bg-amber-500 text-zinc-950 shadow-md ring-1 ring-amber-400/50'
                    : 'text-zinc-400 hover:text-white'
                }`}
                title={`切换为针对${dur.label}事件合约的预测模型`}
              >
                {dur.label}
              </button>
            ))}
          </div>

          {/* Dynamic Payout Ratio Badge */}
          <div className="bg-zinc-950 px-2.5 py-1 rounded-lg border border-zinc-800 text-[11px] font-mono flex items-center gap-1 text-zinc-300">
            <Percent className="h-3 w-3 text-amber-400" />
            <span>支付比率:</span>
            <strong className="text-amber-300">{(payoutRatio * 100).toFixed(0)}%</strong>
          </div>
        </div>
      </div>

      {/* Main Grid: Interactive K-Line Chart (Left) + Actionable Signal & Order Lifecycle Card (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3">
        {/* Chart View (8-9 Cols) */}
        <div className="lg:col-span-8 xl:col-span-9 bg-zinc-950 rounded-xl p-2.5 border border-zinc-800/80 relative overflow-hidden flex flex-col justify-between">
          {/* Top Indicators Overlay */}
          <div className="flex flex-wrap items-center justify-between text-[10px] font-mono text-zinc-400 px-2 py-1 bg-zinc-900/60 rounded-lg mb-1 gap-2">
            <div className="flex items-center gap-3">
              <span>基准价 P0: <strong className="text-amber-300">${p0.toFixed(2)}</strong></span>
              <span>
                现价差:
                <strong className={currentPrice >= p0 ? 'text-emerald-400 ml-1' : 'text-rose-400 ml-1'}>
                  {currentPrice >= p0 ? '+' : ''}{(currentPrice - p0).toFixed(2)}
                </strong>
              </span>
              <span>K线: <strong className="text-zinc-200">{klineTf}</strong></span>
            </div>

            {activeSignalOrder && (
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 text-amber-300 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  <Activity className="h-3 w-3 animate-pulse" />
                  信号进行中 · 到期倒计时: {countdownFormatted}
                </span>
              </div>
            )}
          </div>

          {/* SVG Real-time Candlestick Chart */}
          <div className="w-full relative overflow-x-auto">
            {displayKlines.length === 0 ? (
              <div className="h-64 flex items-center justify-center text-zinc-500 text-xs animate-pulse">
                正在载入 {symbol} 真实K线蜡烛图与订单流信号...
              </div>
            ) : (
              <svg
                viewBox={`0 0 ${svgWidth} ${totalSvgHeight}`}
                className="w-full h-auto select-none overflow-visible"
                style={{ minHeight: '260px' }}
              >
                {/* Horizontal Grid lines */}
                {[0.2, 0.4, 0.6, 0.8].map((pct, idx) => {
                  const p = minPrice + priceRange * (1 - pct);
                  const y = chartHeight * pct;
                  return (
                    <g key={idx}>
                      <line
                        x1={0}
                        y1={y}
                        x2={svgWidth}
                        y2={y}
                        stroke="#27272a"
                        strokeDasharray="3 3"
                        strokeWidth={0.8}
                      />
                      <text
                        x={svgWidth - 5}
                        y={y - 3}
                        fill="#71717a"
                        fontSize={9}
                        textAnchor="end"
                        fontFamily="monospace"
                      >
                        ${p.toFixed(symbol === 'BTCUSDT' ? 1 : 2)}
                      </text>
                    </g>
                  );
                })}

                {/* Entry Price Index Line (if active signal order exists) */}
                {activeSignalOrder?.entryPriceIndex && (
                  <g>
                    <line
                      x1={0}
                      y1={getY(activeSignalOrder.entryPriceIndex)}
                      x2={svgWidth}
                      y2={getY(activeSignalOrder.entryPriceIndex)}
                      stroke={activeSignalOrder.direction === 'UP' ? '#10b981' : '#f43f5e'}
                      strokeDasharray="4 2"
                      strokeWidth={1.5}
                    />
                    <rect
                      x={svgWidth - 145}
                      y={getY(activeSignalOrder.entryPriceIndex) - 10}
                      width={140}
                      height={20}
                      fill={activeSignalOrder.direction === 'UP' ? '#064e3b' : '#881337'}
                      stroke={activeSignalOrder.direction === 'UP' ? '#10b981' : '#f43f5e'}
                      strokeWidth={1}
                      rx={4}
                    />
                    <text
                      x={svgWidth - 75}
                      y={getY(activeSignalOrder.entryPriceIndex) + 4}
                      fill="#ffffff"
                      fontSize={9.5}
                      fontWeight="bold"
                      textAnchor="middle"
                      fontFamily="monospace"
                    >
                      Entry: ${activeSignalOrder.entryPriceIndex.toFixed(1)} 剩 {countdownFormatted}
                    </text>
                  </g>
                )}

                {/* Reference Price P0 Dotted Horizontal Line */}
                {p0 > 0 && !activeSignalOrder?.entryPriceIndex && (
                  <g>
                    <line
                      x1={0}
                      y1={getY(p0)}
                      x2={svgWidth}
                      y2={getY(p0)}
                      stroke="#f59e0b"
                      strokeDasharray="4 2"
                      strokeWidth={1.2}
                    />
                    <rect
                      x={svgWidth - 85}
                      y={getY(p0) - 9}
                      width={80}
                      height={18}
                      fill="#78350f"
                      rx={4}
                    />
                    <text
                      x={svgWidth - 45}
                      y={getY(p0) + 3}
                      fill="#fef3c7"
                      fontSize={9}
                      fontWeight="bold"
                      textAnchor="middle"
                      fontFamily="monospace"
                    >
                      P0 ${p0.toFixed(symbol === 'BTCUSDT' ? 1 : 2)}
                    </text>
                  </g>
                )}

                {/* Current Live Price Line */}
                {currentPrice > 0 && (
                  <g>
                    <line
                      x1={0}
                      y1={getY(currentPrice)}
                      x2={svgWidth}
                      y2={getY(currentPrice)}
                      stroke={currentPrice >= (activeSignalOrder?.entryPriceIndex || p0) ? '#10b981' : '#f43f5e'}
                      strokeWidth={1.5}
                    />
                    <rect
                      x={svgWidth - 95}
                      y={getY(currentPrice) - 10}
                      width={90}
                      height={20}
                      fill={currentPrice >= (activeSignalOrder?.entryPriceIndex || p0) ? '#065f46' : '#881337'}
                      rx={4}
                    />
                    <text
                      x={svgWidth - 50}
                      y={getY(currentPrice) + 4}
                      fill="#ffffff"
                      fontSize={10}
                      fontWeight="black"
                      textAnchor="middle"
                      fontFamily="monospace"
                    >
                      ${currentPrice.toFixed(symbol === 'BTCUSDT' ? 1 : 2)}
                    </text>
                  </g>
                )}

                {/* Volume Divider */}
                <line
                  x1={0}
                  y1={chartHeight}
                  x2={svgWidth}
                  y2={chartHeight}
                  stroke="#3f3f46"
                  strokeWidth={1}
                />
                <text
                  x={5}
                  y={chartHeight + 12}
                  fill="#71717a"
                  fontSize={8}
                  fontFamily="monospace"
                >
                  成交量 (Volume)
                </text>

                {/* Render Candlesticks and Volume Bars */}
                {displayKlines.map((candle, i) => {
                  const x = i * candleGap + candleGap / 2;
                  const isGreen = candle.close >= candle.open;
                  const candleColor = isGreen ? '#10b981' : '#f43f5e';

                  const openY = getY(candle.open);
                  const closeY = getY(candle.close);
                  const highY = getY(candle.high);
                  const lowY = getY(candle.low);

                  const bodyTop = Math.min(openY, closeY);
                  const bodyHeight = Math.max(1.5, Math.abs(closeY - openY));

                  // Volume
                  const volY = getVolY(candle.volume);
                  const volH = chartHeight + volumeHeight - volY;

                  return (
                    <g key={candle.time || i}>
                      {/* Volume Bar */}
                      <rect
                        x={x - candleWidth / 2}
                        y={volY}
                        width={candleWidth}
                        height={volH}
                        fill={candleColor}
                        opacity={0.35}
                      />

                      {/* Wick */}
                      <line
                        x1={x}
                        y1={highY}
                        x2={x}
                        y2={lowY}
                        stroke={candleColor}
                        strokeWidth={1}
                      />

                      {/* Candle Body */}
                      <rect
                        x={x - candleWidth / 2}
                        y={bodyTop}
                        width={candleWidth}
                        height={bodyHeight}
                        fill={candleColor}
                        rx={0.5}
                      />
                    </g>
                  );
                })}

                {/* Historical and Active Signal Markers bound directly to (timestamp + price) */}
                {visibleSignalMarkers.map(({ candleIndex, order, x, isUp: ordIsUp, candle }) => {
                  const isOngoing = order.status === 'ACTIVE' || order.status === 'WAITING_ENTRY';
                  const isWin = order.result === 'WIN';
                  const isLoss = order.result === 'LOSS';

                  if (ordIsUp) {
                    const lowY = getY(candle.low);
                    const badgeY = Math.min(chartHeight - 34, lowY + 12);
                    return (
                      <g
                        key={order.signalId || candleIndex}
                        className="cursor-pointer transition hover:opacity-90"
                        onClick={() => setSelectedSignalDetail(order)}
                      >
                        {/* Anchor Line */}
                        <line
                          x1={x}
                          y1={lowY}
                          x2={x}
                          y2={badgeY}
                          stroke="#10b981"
                          strokeWidth={1.5}
                          strokeDasharray="2 2"
                        />
                        {/* Badge Box */}
                        <rect
                          x={x - 44}
                          y={badgeY}
                          width={88}
                          height={28}
                          rx={5}
                          fill={isOngoing ? '#064e3b' : isWin ? '#065f46' : isLoss ? '#4c0519' : '#18181b'}
                          stroke={isOngoing ? '#34d399' : isWin ? '#10b981' : '#f43f5e'}
                          strokeWidth={isOngoing ? 1.8 : 1}
                          filter="drop-shadow(0px 2px 5px rgba(16, 185, 129, 0.35))"
                        />
                        <text
                          x={x}
                          y={badgeY + 12}
                          fill="#a7f3d0"
                          fontSize={9}
                          fontWeight="900"
                          textAnchor="middle"
                          fontFamily="sans-serif"
                        >
                          ↑ UP 买涨
                        </text>
                        <text
                          x={x}
                          y={badgeY + 23}
                          fill="#ffffff"
                          fontSize={8.5}
                          fontWeight="bold"
                          textAnchor="middle"
                          fontFamily="monospace"
                        >
                          {order.modelProb}% {isOngoing ? '进行中' : order.result}
                        </text>
                      </g>
                    );
                  } else {
                    const highY = getY(candle.high);
                    const badgeY = Math.max(10, highY - 36);
                    return (
                      <g
                        key={order.signalId || candleIndex}
                        className="cursor-pointer transition hover:opacity-90"
                        onClick={() => setSelectedSignalDetail(order)}
                      >
                        {/* Anchor Line */}
                        <line
                          x1={x}
                          y1={highY}
                          x2={x}
                          y2={badgeY + 28}
                          stroke="#f43f5e"
                          strokeWidth={1.5}
                          strokeDasharray="2 2"
                        />
                        {/* Badge Box */}
                        <rect
                          x={x - 44}
                          y={badgeY}
                          width={88}
                          height={28}
                          rx={5}
                          fill={isOngoing ? '#881337' : isWin ? '#065f46' : isLoss ? '#4c0519' : '#18181b'}
                          stroke={isOngoing ? '#fb7185' : isWin ? '#10b981' : '#f43f5e'}
                          strokeWidth={isOngoing ? 1.8 : 1}
                          filter="drop-shadow(0px 2px 5px rgba(244, 63, 94, 0.35))"
                        />
                        <text
                          x={x}
                          y={badgeY + 12}
                          fill="#fecdd3"
                          fontSize={9}
                          fontWeight="900"
                          textAnchor="middle"
                          fontFamily="sans-serif"
                        >
                          ↓ DOWN 买跌
                        </text>
                        <text
                          x={x}
                          y={badgeY + 23}
                          fill="#ffffff"
                          fontSize={8.5}
                          fontWeight="bold"
                          textAnchor="middle"
                          fontFamily="monospace"
                        >
                          {order.modelProb}% {isOngoing ? '进行中' : order.result}
                        </text>
                      </g>
                    );
                  }
                })}
              </svg>
            )}
          </div>
        </div>

        {/* Compact Right Signal & Order Lifecycle Card (3-4 Cols) */}
        <div className="lg:col-span-4 xl:col-span-3 flex flex-col justify-between bg-zinc-950 rounded-xl p-3.5 border border-zinc-800 space-y-3">
          {/* Card Top: Symbol & Contract Label */}
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <span className="font-bold text-white text-sm">
                {symbol} · {durationLabel}
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                  activeSignalOrder
                    ? activeSignalOrder.status === 'WAITING_ENTRY'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                      : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : !isWait
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                {activeSignalOrder
                  ? activeSignalOrder.status === 'WAITING_ENTRY'
                    ? '⏳ 等待确立Entry'
                    : '🟢 进行中'
                  : !isWait
                  ? '🟢 可开单'
                  : '⚪ 等待中 (WAIT)'}
              </span>
            </div>

            {/* Signal Verdict Banner */}
            <div className="my-2.5">
              {isUp ? (
                <div className="bg-emerald-950/60 border border-emerald-500/50 rounded-xl p-3 text-center shadow-lg shadow-emerald-500/10">
                  <div className="text-xl sm:text-2xl font-black text-emerald-400 flex items-center justify-center gap-1.5">
                    <TrendingUp className="h-6 w-6 stroke-[3]" />
                    🟢 买涨 / UP
                  </div>
                  <div className="text-[11px] text-emerald-300/90 font-medium mt-1">
                    预测结算价高于开仓价 Entry
                  </div>
                </div>
              ) : isDown ? (
                <div className="bg-rose-950/60 border border-rose-500/50 rounded-xl p-3 text-center shadow-lg shadow-rose-500/10">
                  <div className="text-xl sm:text-2xl font-black text-rose-400 flex items-center justify-center gap-1.5">
                    <TrendingDown className="h-6 w-6 stroke-[3]" />
                    🔴 买跌 / DOWN
                  </div>
                  <div className="text-[11px] text-rose-300/90 font-medium mt-1">
                    预测结算价低于开仓价 Entry
                  </div>
                </div>
              ) : (
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-center">
                  <div className="text-lg font-black text-zinc-300 flex items-center justify-center gap-1.5">
                    ⚪ WAIT / 空仓观望
                  </div>
                  <div className="text-[11px] text-zinc-400 mt-1">
                    当前无有效开单信号，严格空仓保护
                  </div>
                </div>
              )}
            </div>

            {/* Live In-Progress Signal Box with Live Countdown & Delta */}
            {activeSignalOrder ? (
              <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 p-3 rounded-xl border border-amber-500/30 space-y-2 text-xs font-mono mb-2 shadow-inner">
                <div className="flex justify-between items-center pb-1.5 border-b border-zinc-800">
                  <span className="text-zinc-400">开仓基准价 (Entry):</span>
                  <strong className="text-white">
                    ${activeSignalOrder.entryPriceIndex?.toFixed(2) || 'T+1s确立中...'}
                  </strong>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-zinc-400">当前价格:</span>
                  <span className="text-zinc-200">${currentPrice.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-zinc-400">距离开仓价:</span>
                  <span className={`font-bold ${isFavorable ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {deltaSign}{priceDelta.toFixed(2)}
                  </span>
                </div>

                <div className="flex justify-between items-center pt-1 border-t border-zinc-800/80">
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5 animate-spin" />
                    到期倒计时:
                  </span>
                  <span className="text-amber-300 font-black text-sm tracking-wider">
                    {countdownFormatted}
                  </span>
                </div>
              </div>
            ) : null}

            {/* Numerical Probability & Quantitative Edge Checklist */}
            <div className="space-y-1.5 text-xs font-mono bg-zinc-900/60 p-2.5 rounded-xl border border-zinc-800/80">
              <div className="flex justify-between">
                <span className="text-zinc-400">模型胜率:</span>
                <strong className={!isWait ? (isUp ? 'text-emerald-400' : 'text-rose-400') : 'text-zinc-200'}>
                  {modelProb.toFixed(1)}%
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">支付比率:</span>
                <span className="text-amber-300 font-bold">
                  {(payoutRatio * 100).toFixed(0)}% (1:{(payoutRatio).toFixed(2)})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">盈亏平衡:</span>
                <span className="text-zinc-300">{breakEvenProb.toFixed(2)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">统计优势 (Edge):</span>
                <span className={`font-bold ${edge > 0 ? 'text-emerald-400' : 'text-zinc-400'}`}>
                  {edge > 0 ? '+' : ''}{edge.toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">单笔理论 EV:</span>
                <span className={`font-bold ${expectedValue > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {expectedValue > 0 ? '+' : ''}{expectedValue.toFixed(2)} USDT
                </span>
              </div>
            </div>

            {/* Recent Settled Signal Info Strip */}
            {recentSettledSignal && !activeSignalOrder && (
              <div className="mt-2.5 p-2 bg-zinc-900/70 border border-zinc-800 rounded-lg text-[11px] font-mono">
                <div className="flex items-center justify-between text-zinc-400 mb-1">
                  <span>最近完成信号:</span>
                  <span
                    className={`font-bold flex items-center gap-0.5 ${
                      recentSettledSignal.result === 'WIN'
                        ? 'text-emerald-400'
                        : recentSettledSignal.result === 'LOSS'
                        ? 'text-rose-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {recentSettledSignal.result === 'WIN' ? (
                      <CheckCircle2 className="h-3 w-3" />
                    ) : recentSettledSignal.result === 'LOSS' ? (
                      <XCircle className="h-3 w-3" />
                    ) : (
                      <MinusCircle className="h-3 w-3" />
                    )}
                    {recentSettledSignal.result}
                  </span>
                </div>
                <div className="flex justify-between text-zinc-300 text-[10px]">
                  <span>Entry: ${recentSettledSignal.entryPriceIndex?.toFixed(1)}</span>
                  <span>Expiry: ${recentSettledSignal.expiryPriceIndex?.toFixed(1)}</span>
                </div>
              </div>
            )}

            {/* WAIT Reason / Quantitative Explanation */}
            {isWait && (
              <div className="mt-2 p-2 bg-amber-950/20 border border-amber-500/20 rounded-lg text-[11px] text-amber-300/90 leading-relaxed">
                <span className="font-bold flex items-center gap-1 text-amber-400 mb-0.5">
                  <AlertTriangle className="h-3 w-3" /> WAIT 原因:
                </span>
                {pred?.waitReasons && pred.waitReasons.length > 0
                  ? pred.waitReasons.join('；')
                  : '微观订单流(OFI/CVD)优势或胜率未达正期望值门槛，触发保护机制。'}
              </div>
            )}
          </div>

          {/* Quick Simulated Order Execution Buttons */}
          <div className="space-y-2 pt-2 border-t border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-400 text-[11px]">模拟投注金额</span>
              <div className="flex gap-1 font-mono text-[10px]">
                {[50, 100, 200, 500].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setSelectedStake(amt)}
                    className={`px-1.5 py-0.5 rounded border transition ${
                      selectedStake === amt
                        ? 'border-amber-400 bg-amber-400/20 text-amber-300 font-bold'
                        : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() =>
                  onPlaceTrade(
                    symbol,
                    'UP',
                    selectedStake,
                    activeDuration,
                    payoutRatio,
                    pred?.upProb || 50,
                    activeSignalOrder?.signalId
                  )
                }
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/20 transition cursor-pointer"
              >
                <TrendingUp className="h-4 w-4" />
                模拟买涨
              </button>

              <button
                onClick={() =>
                  onPlaceTrade(
                    symbol,
                    'DOWN',
                    selectedStake,
                    activeDuration,
                    payoutRatio,
                    pred?.downProb || 50,
                    activeSignalOrder?.signalId
                  )
                }
                className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-rose-600/20 transition cursor-pointer"
              >
                <TrendingDown className="h-4 w-4" />
                模拟买跌
              </button>
            </div>
            <div className="text-[10px] text-zinc-500 text-center font-mono">
              信号订单全自动产生并记录 · 点击上方仅建立额外模拟资金跟单
            </div>
          </div>
        </div>
      </div>

      {/* Signal Detail Modal Popup (when on-chart signal marker clicked) */}
      {selectedSignalDetail && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-zinc-900 border border-zinc-700 rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Target className="h-4 w-4 text-amber-400" />
                {selectedSignalDetail.symbol} · {selectedSignalDetail.duration} 信号订单详情
              </h3>
              <button
                onClick={() => setSelectedSignalDetail(null)}
                className="text-zinc-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">Signal ID:</span>
                <span className="text-zinc-300 text-[10px]">{selectedSignalDetail.signalId || selectedSignalDetail.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">信号方向:</span>
                <span className={selectedSignalDetail.direction === 'UP' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {selectedSignalDetail.direction === 'UP' ? '🟢 买涨 / UP' : '🔴 买跌 / DOWN'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">模型胜率:</span>
                <span className="text-white font-bold">{selectedSignalDetail.modelProb || selectedSignalDetail.upProb || selectedSignalDetail.downProb}%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">开仓 Entry Price:</span>
                <span className="text-amber-300 font-bold">
                  ${selectedSignalDetail.entryPriceIndex?.toFixed(2) || selectedSignalDetail.signalPrice?.toFixed(2) || '---'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">到期 Expiry Price:</span>
                <span className="text-white font-bold">
                  {selectedSignalDetail.expiryPriceIndex ? `$${selectedSignalDetail.expiryPriceIndex.toFixed(2)}` : '进行中...'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">最终裁决结果:</span>
                <span
                  className={`font-black ${
                    selectedSignalDetail.result === 'WIN'
                      ? 'text-emerald-400'
                      : selectedSignalDetail.result === 'LOSS'
                      ? 'text-rose-400'
                      : 'text-zinc-300'
                  }`}
                >
                  {selectedSignalDetail.result || selectedSignalDetail.outcome || '进行中 (ACTIVE)'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">统计优势 (Edge):</span>
                <span className="text-emerald-400 font-bold">+{selectedSignalDetail.edge}%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800">
                <span className="text-zinc-400">单笔理论 EV:</span>
                <span className="text-emerald-400 font-bold">+{selectedSignalDetail.expectedValue} USDT</span>
              </div>
            </div>

            <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800 text-xs">
              <span className="font-bold text-zinc-300 block mb-1">量化特征与归因：</span>
              <p className="text-zinc-400 leading-relaxed text-[11px]">
                {selectedSignalDetail.factorsSummary ||
                  selectedSignalDetail.rationale?.join('；') ||
                  '微观订单流失衡(OFI)与主动吃单(CVD)同向确认，多周期动量共振。'}
              </p>
            </div>

            <button
              onClick={() => setSelectedSignalDetail(null)}
              className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl text-xs transition"
            >
              关闭
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
