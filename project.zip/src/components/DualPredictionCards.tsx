import React, { useState, useEffect } from 'react';
import { DurationType, MarketSnapshot, SymbolType } from '../types/market.js';
import {
  Clock,
  TrendingUp,
  TrendingDown,
  PauseCircle,
  AlertTriangle,
  Zap,
  Target,
  ShieldAlert,
  Play,
  Pause,
  HelpCircle,
  Percent,
} from 'lucide-react';

interface DualPredictionCardsProps {
  btcSnapshot: MarketSnapshot | null;
  ethSnapshot: MarketSnapshot | null;
  selectedSymbol: SymbolType;
  onSelectSymbol: (symbol: SymbolType) => void;
  onQuickTrade: (symbol: SymbolType, direction: 'UP' | 'DOWN', stake: number) => void;
  selectedDuration?: DurationType;
  onSelectDuration?: (duration: DurationType) => void;
  isPredictionActive?: boolean;
}

export const DualPredictionCards: React.FC<DualPredictionCardsProps> = ({
  btcSnapshot,
  ethSnapshot,
  selectedSymbol,
  onSelectSymbol,
  onQuickTrade,
  selectedDuration = '10m',
  onSelectDuration,
  isPredictionActive = true,
}) => {
  return (
    <div className="space-y-3">
      {/* Duration Switcher Row */}
      {onSelectDuration && (
        <div className="flex items-center justify-between bg-zinc-900/80 px-3 py-1.5 rounded-xl border border-zinc-800 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-zinc-400 font-medium">事件合约预测周期：</span>
            <div className="flex bg-zinc-950 p-0.5 rounded-lg border border-zinc-800 font-mono">
              {(
                [
                  { id: '10m', label: '10分钟' },
                  { id: '30m', label: '30分钟' },
                  { id: '1h', label: '1小时' },
                  { id: '1d', label: '1天' },
                ] as const
              ).map((d) => (
                <button
                  key={d.id}
                  onClick={() => onSelectDuration(d.id)}
                  className={`px-2.5 py-0.5 rounded font-bold transition ${
                    selectedDuration === d.id
                      ? 'bg-amber-400 text-zinc-950 shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          <div className="text-[11px] text-zinc-500 font-mono hidden sm:flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>基准价 P0 实时锚定 • 100% 真实公开行情流</span>
          </div>
        </div>
      )}

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SingleCard
          snapshot={btcSnapshot}
          isSelected={selectedSymbol === 'BTCUSDT'}
          onSelect={() => onSelectSymbol('BTCUSDT')}
          onQuickTrade={(dir, amt) => onQuickTrade('BTCUSDT', dir, amt)}
          duration={selectedDuration}
          isPredictionActive={isPredictionActive}
        />
        <SingleCard
          snapshot={ethSnapshot}
          isSelected={selectedSymbol === 'ETHUSDT'}
          onSelect={() => onSelectSymbol('ETHUSDT')}
          onQuickTrade={(dir, amt) => onQuickTrade('ETHUSDT', dir, amt)}
          duration={selectedDuration}
          isPredictionActive={isPredictionActive}
        />
      </div>
    </div>
  );
};

interface SingleCardProps {
  snapshot: MarketSnapshot | null;
  isSelected: boolean;
  onSelect: () => void;
  onQuickTrade: (direction: 'UP' | 'DOWN', stake: number) => void;
  duration: DurationType;
  isPredictionActive: boolean;
}

const SingleCard: React.FC<SingleCardProps> = ({
  snapshot,
  isSelected,
  onSelect,
  onQuickTrade,
  duration,
  isPredictionActive,
}) => {
  const [timeLeftSec, setTimeLeftSec] = useState<number>(600);
  const [quickStake, setQuickStake] = useState<number>(100);

  const round = snapshot?.currentRound;
  // Get prediction for specific duration if available
  const pred =
    (snapshot?.predictions && snapshot.predictions[duration]) || snapshot?.prediction;

  useEffect(() => {
    if (!round) return;
    const calc = () => {
      const now = Date.now();
      const diff = Math.max(0, Math.floor((round.expiryTime - now) / 1000));
      setTimeLeftSec(diff);
    };
    calc();
    const interval = setInterval(calc, 1000);
    return () => clearInterval(interval);
  }, [round?.expiryTime]);

  if (!snapshot || !pred || !round) {
    return (
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 text-center text-zinc-500 animate-pulse">
        <div className="h-6 w-32 bg-zinc-800 rounded mx-auto mb-3" />
        正在拉取币安真实公开数据流与微观结构盘口...
      </div>
    );
  }

  const minutes = Math.floor(timeLeftSec / 60);
  const seconds = timeLeftSec % 60;
  const progressPct = Math.min(100, Math.max(0, ((600 - timeLeftSec) / 600) * 100));

  const p0 = round.lockPrice; // Anchored reference price P0
  const currentPrice = snapshot.price;
  const delta = currentPrice - p0;
  const deltaPct = p0 > 0 ? (delta / p0) * 100 : 0;
  const isCurrentlyUp = delta >= 0;

  // Signal State
  const isUp = pred.direction === 'UP';
  const isDown = pred.direction === 'DOWN';
  const isWait = pred.direction === 'WAIT';

  const confidenceText =
    pred.confidence >= 70 ? '高 (HIGH)' : pred.confidence >= 52 ? '中 (MEDIUM)' : '低 (LOW)';
  const expectedSettlementTime = new Date(round.expiryTime).toLocaleTimeString();
  const breakEven = pred.breakEvenProb ?? 55.56;
  const payout = pred.payoutRatio ?? 0.8;
  const evVal = pred.expectedValue ?? 0;
  const edgeVal = pred.edge ?? 0;

  return (
    <div
      onClick={onSelect}
      className={`rounded-2xl border transition-all cursor-pointer relative overflow-hidden p-4 sm:p-5 flex flex-col justify-between ${
        isSelected
          ? 'bg-zinc-900/95 border-amber-500/60 shadow-xl shadow-amber-500/5 ring-1 ring-amber-500/30'
          : 'bg-zinc-900/70 border-zinc-800 hover:border-zinc-700'
      }`}
    >
      <div>
        {/* Top Row: Symbol, Price, Countdown */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80">
          <div className="flex items-center gap-2.5">
            <span
              className={`h-2.5 w-2.5 rounded-full ${
                snapshot.symbol === 'BTCUSDT' ? 'bg-amber-400' : 'bg-sky-400'
              }`}
            />
            <span className="font-black text-base sm:text-lg text-white tracking-tight">
              {snapshot.symbol}
            </span>
            <span className="text-[10px] text-zinc-400 font-mono px-2 py-0.5 rounded bg-zinc-800">
              {duration === '10m'
                ? '10分钟'
                : duration === '30m'
                ? '30分钟'
                : duration === '1h'
                ? '1小时'
                : '1天'}{' '}
              事件合约
            </span>
            {!isPredictionActive && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono font-bold">
                已暂停
              </span>
            )}
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-2 bg-zinc-950 px-2.5 py-1 rounded-lg border border-zinc-800">
            <Clock className="h-3.5 w-3.5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span className="font-mono text-xs font-bold text-amber-300">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
            <div className="w-10 h-1.5 bg-zinc-800 rounded-full overflow-hidden ml-1">
              <div
                className="h-full bg-amber-400 transition-all duration-1000"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        </div>

        {/* Real-time Price & Reference P0 Comparison */}
        <div className="grid grid-cols-2 gap-3 py-3 font-mono">
          <div className="bg-zinc-950/70 p-2.5 rounded-xl border border-zinc-800/60">
            <div className="text-[10px] text-zinc-400 flex items-center gap-1 font-sans">
              <Target className="h-3 w-3 text-amber-400" /> 参考基准价 P0 (锁定)
            </div>
            <div className="text-base sm:text-lg font-black text-amber-300 mt-0.5">
              ${p0.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>

          <div className="bg-zinc-950/70 p-2.5 rounded-xl border border-zinc-800/60">
            <div className="text-[10px] text-zinc-400 font-sans">实时现价 vs P0</div>
            <div className="flex items-baseline justify-between mt-0.5">
              <span className="text-base sm:text-lg font-black text-white">
                ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
              <span
                className={`text-xs font-bold ${
                  isCurrentlyUp ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {isCurrentlyUp ? '+' : ''}
                {delta.toFixed(1)} ({deltaPct > 0 ? '+' : ''}
                {deltaPct.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>

        {/* Main Signal Display */}
        {isWait ? (
          /* Dedicated Rich WAIT Panel satisfying Requirement 16 */
          <div className="bg-zinc-950/95 border border-amber-500/40 rounded-2xl p-4 my-2 shadow-lg space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
              <div className="flex items-center gap-2.5">
                <div className="h-9 w-9 rounded-xl bg-zinc-800 flex items-center justify-center text-zinc-300">
                  <PauseCircle className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-base sm:text-lg font-black text-amber-400 tracking-tight">
                    ⚪ WAIT (空仓观望)
                  </div>
                  <div className="text-[11px] text-zinc-300 font-medium">
                    阻断原因: {pred.waitReasons?.[0]?.replace(/^[❌\s]+/, '') || '当前无满足正期望统计优势的开单信号'}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-zinc-300">
                  置信度: {pred.confidence}%
                </span>
              </div>
            </div>

            {/* Complete metrics required by Requirement 16 */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">UP 概率</span>
                <span className="font-bold text-emerald-400 text-sm">{pred.upProb}%</span>
              </div>
              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">DOWN 概率</span>
                <span className="font-bold text-rose-400 text-sm">{pred.downProb}%</span>
              </div>
              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">盈亏平衡概率</span>
                <span className="font-bold text-amber-300 text-sm">{breakEven}%</span>
              </div>
              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">当前支付比率</span>
                <span className="font-bold text-sky-400 text-sm">{Math.round(payout * 100)}% (1:{(payout).toFixed(2)})</span>
              </div>

              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">理论 EV (期望值)</span>
                <span className={`font-bold text-sm ${evVal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {evVal >= 0 ? '+' : ''}{evVal.toFixed(2)} USDT
                </span>
              </div>
              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">Edge 优势</span>
                <span className={`font-bold text-sm ${edgeVal >= 0 ? 'text-emerald-400' : 'text-zinc-400'}`}>
                  {edgeVal >= 0 ? '+' : ''}{edgeVal.toFixed(1)}%
                </span>
              </div>
              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">当前开仓参考价</span>
                <span className="font-bold text-white text-sm">
                  ${p0.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="bg-zinc-900/90 p-2 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-500 block font-sans">预计到期时间</span>
                <span className="font-bold text-amber-300 text-sm">{expectedSettlementTime}</span>
              </div>
            </div>

            {/* WAIT Reason */}
            <div className="bg-amber-950/20 border border-amber-500/30 p-2.5 rounded-lg text-xs">
              <div className="text-amber-400 font-bold mb-1 flex items-center gap-1.5">
                <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                WAIT 触发原因：
              </div>
              <div className="text-amber-200/90 text-[11px] leading-relaxed">
                {pred.waitReasons.length > 0
                  ? pred.waitReasons.join('；')
                  : '当前多周期均线动量、微观订单流(OFI)与主动吃单(CVD)优势不足，未达开单正期望值阈值，建议空仓观望。'}
              </div>
            </div>

            {/* Model timestamp */}
            <div className="flex flex-wrap items-center justify-between text-[10px] text-zinc-500 font-mono pt-1">
              <span>最近一次模型计算时间: {new Date(pred.timestamp).toLocaleTimeString()}</span>
              <span className="text-emerald-400 flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                实时高频循环评估中 (每秒推流 / 每15秒状态复核)
              </span>
            </div>
          </div>
        ) : (
          /* Prominent Actionable UP or DOWN Signal */
          <div
            className={`rounded-2xl p-4 border my-2 flex items-center justify-between ${
              isUp
                ? 'bg-emerald-950/60 border-emerald-500/60 shadow-xl shadow-emerald-500/20'
                : 'bg-rose-950/60 border-rose-500/60 shadow-xl shadow-rose-500/20'
            }`}
          >
            {/* Signal Icon & Text */}
            <div className="flex items-center gap-3.5">
              <div
                className={`h-12 w-12 rounded-2xl flex items-center justify-center text-white shrink-0 ${
                  isUp
                    ? 'bg-emerald-500 shadow-lg shadow-emerald-500/40 animate-pulse'
                    : 'bg-rose-500 shadow-lg shadow-rose-500/40 animate-pulse'
                }`}
              >
                {isUp ? <TrendingUp className="h-7 w-7 stroke-[3]" /> : <TrendingDown className="h-7 w-7 stroke-[3]" />}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`text-2xl sm:text-3xl font-black tracking-tight ${
                      isUp ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isUp ? '🟢 OPEN LONG (买涨)' : '🔴 OPEN SHORT (买跌)'}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider bg-zinc-900 text-zinc-300">
                    {pred.signalLevel}
                  </span>
                </div>
                <div className="text-xs text-zinc-200 mt-0.5 font-medium">
                  {isUp ? (
                    <span className="text-emerald-300 font-bold">
                      【建议】买涨 / UP (预测到期结算价高于 ${p0.toFixed(2)})
                    </span>
                  ) : (
                    <span className="text-rose-300 font-bold">
                      【建议】买跌 / DOWN (预测到期结算价低于 ${p0.toFixed(2)})
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Model Probability Display */}
            <div className="text-right font-mono">
              <div className="text-[10px] text-zinc-400 uppercase">模型胜率</div>
              <div
                className={`text-2xl sm:text-3xl font-black ${
                  isUp ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {pred.winProbability || Math.max(pred.upProb, pred.downProb)}%
              </div>
              {pred.edge !== undefined && pred.edge > 0 && (
                <div className="text-[10px] text-amber-400 font-bold">
                  Edge: +{pred.edge}%
                </div>
              )}
            </div>
          </div>
        )}

        {/* Action Parameters Checklist */}
        <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 text-xs font-mono grid grid-cols-2 sm:grid-cols-4 gap-2 text-zinc-300 my-2">
          <div>
            <span className="text-[10px] text-zinc-500 block font-sans">【当前信号】</span>
            <span className="font-bold text-white">{snapshot.symbol}: {pred.direction}</span>
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 block font-sans">【模型概率】</span>
            <span className="font-bold text-emerald-400">UP {pred.upProb}%</span> / <span className="font-bold text-rose-400">DN {pred.downProb}%</span>
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 block font-sans">【置信度】</span>
            <span className="font-bold text-zinc-200">{confidenceText} ({pred.confidence}%)</span>
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 block font-sans">【预计结算】</span>
            <span className="font-bold text-amber-300">{expectedSettlementTime}</span>
          </div>
        </div>

        {/* Probability Breakdown Bar */}
        <div className="my-2 bg-zinc-950 p-2.5 rounded-xl border border-zinc-800/80">
          <div className="flex justify-between text-[11px] font-mono mb-1">
            <span className="text-emerald-400 font-bold">买涨 UP: {pred.upProb}%</span>
            <span className="text-zinc-400 font-bold">等待 WAIT: {pred.waitProb}%</span>
            <span className="text-rose-400 font-bold">买跌 DOWN: {pred.downProb}%</span>
          </div>
          <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden flex">
            <div
              className="h-full bg-emerald-500 transition-all duration-500"
              style={{ width: `${pred.upProb}%` }}
            />
            <div
              className="h-full bg-zinc-600 transition-all duration-500"
              style={{ width: `${pred.waitProb}%` }}
            />
            <div
              className="h-full bg-rose-500 transition-all duration-500"
              style={{ width: `${pred.downProb}%` }}
            />
          </div>
        </div>

        {/* Real-time Factor Attribution */}
        <div className="bg-zinc-950/80 rounded-xl p-3 border border-zinc-800/80 text-xs">
          <div className="font-bold text-zinc-300 flex items-center gap-1.5 mb-1.5">
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            为什么产生这个信号 (量化多因子微观归因):
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] mb-2 font-mono">
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800/60">
              <span className="text-zinc-500 block font-sans">多周期趋势</span>
              <span className={pred.factors.multiTf.score > 0 ? 'text-emerald-400' : pred.factors.multiTf.score < 0 ? 'text-rose-400' : 'text-zinc-300'}>
                {pred.factors.multiTf.label}
              </span>
            </div>

            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800/60">
              <span className="text-zinc-500 block font-sans">CVD 主动买卖</span>
              <span className={pred.factors.cvd.score > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {pred.factors.cvd.label}
              </span>
            </div>

            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800/60">
              <span className="text-zinc-500 block font-sans">OFI 订单流失衡</span>
              <span className={pred.factors.ofi.score > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {pred.factors.ofi.label}
              </span>
            </div>

            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800/60">
              <span className="text-zinc-500 block font-sans">盘口深度倾斜</span>
              <span className={pred.factors.depth.score > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {pred.factors.depth.label}
              </span>
            </div>

            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800/60">
              <span className="text-zinc-500 block font-sans">RSI / 动量</span>
              <span className="text-zinc-300">
                RSI {snapshot.indicators.rsi} ({pred.factors.momentum.label})
              </span>
            </div>

            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800/60">
              <span className="text-zinc-500 block font-sans">波动率 (ATR)</span>
              <span className="text-zinc-300">
                {snapshot.indicators.volatilityPercent}% (正常)
              </span>
            </div>
          </div>

          <div className="text-[11px] text-zinc-400 leading-relaxed font-sans">
            <strong>综合研判：</strong>
            {pred.recommendedAction}
          </div>
        </div>
      </div>

      {/* Quick Simulated Trade Execution */}
      <div className="pt-3 border-t border-zinc-800/80 mt-3">
        <div className="flex items-center justify-between gap-2 mb-2 text-xs">
          <span className="text-zinc-400 font-medium text-[11px]">模拟开仓金额</span>
          <div className="flex gap-1">
            {[50, 100, 200, 500].map((amt) => (
              <button
                key={amt}
                onClick={(e) => {
                  e.stopPropagation();
                  setQuickStake(amt);
                }}
                className={`px-2 py-0.5 rounded text-[10px] font-mono border transition ${
                  quickStake === amt
                    ? 'border-amber-400 bg-amber-400/20 text-amber-300 font-bold'
                    : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
                }`}
              >
                ${amt}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onQuickTrade('UP', quickStake);
            }}
            className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/20 active:scale-95 transition"
          >
            <TrendingUp className="h-4 w-4" />
            模拟买涨 (UP)
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onQuickTrade('DOWN', quickStake);
            }}
            className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-rose-600/20 active:scale-95 transition"
          >
            <TrendingDown className="h-4 w-4" />
            模拟买跌 (DOWN)
          </button>
        </div>
      </div>
    </div>
  );
};
