import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  TrendingUp,
  Award,
  CheckCircle2,
  XCircle,
  ChevronDown,
  ChevronRight,
  ShieldCheck,
  Eye,
  Info,
  Layers,
} from 'lucide-react';
import { DailySignalStats, SignalOrder, SignalOrderStats } from '../types/market.js';

interface DailyStatsDashboardProps {
  currentDate: string; // YYYY-MM-DD in Asia/Shanghai
  todayStats: DailySignalStats | null;
  dailyArchives: DailySignalStats[];
  allSignalOrders: SignalOrder[];
  signalStats: SignalOrderStats | null;
  onSelectOrder?: (order: SignalOrder) => void;
}

export const DailyStatsDashboard: React.FC<DailyStatsDashboardProps> = ({
  currentDate,
  todayStats,
  dailyArchives = [],
  allSignalOrders = [],
  signalStats,
  onSelectOrder,
}) => {
  const [selectedArchiveDate, setSelectedArchiveDate] = useState<string | null>(null);
  const [showSnapshotId, setShowSnapshotId] = useState<string | null>(null);

  // Fallback safe today stats
  const safeToday: DailySignalStats = todayStats || {
    date: currentDate,
    total_signals: 0,
    pending: 0,
    wins: 0,
    losses: 0,
    win_rate: 0,
    up_signals: 0,
    up_wins: 0,
    up_losses: 0,
    up_win_rate: 0,
    down_signals: 0,
    down_wins: 0,
    down_losses: 0,
    down_win_rate: 0,
  };

  const hasSettledToday = safeToday.wins + safeToday.losses > 0;

  // Signals for selected archive date
  const selectedDateOrders = selectedArchiveDate
    ? allSignalOrders.filter((s) => (s.date || s.signalId.slice(4, 12)) === selectedArchiveDate.replace(/-/g, '') || s.date === selectedArchiveDate)
    : [];

  return (
    <div className="space-y-4 font-mono">
      {/* 1. Core Section: 今日真实统计 (Today Real Stats) */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5 sm:p-5 shadow-xl space-y-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Calendar className="h-4 w-4 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-sm sm:text-base tracking-tight">
                  今日真实统计
                </h3>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {currentDate} (北京时间)
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-zinc-400">
                每晚 00:00:00 自动开启新一天 · 当日统计从零计算 · 历史数据永久保存
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-zinc-400 self-start sm:self-auto">
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>实盘信号直录 · 绝无模拟虚构</span>
          </div>
        </div>

        {/* 4 Core Quantitative Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 text-xs">
          <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 hover:border-zinc-700 transition">
            <span className="text-zinc-500 block text-[10px] mb-1">今日正式开单</span>
            <div className="flex items-baseline gap-1.5">
              <strong className="text-white text-xl sm:text-2xl font-black">
                {safeToday.total_signals}
              </strong>
              <span className="text-[10px] text-zinc-500">笔</span>
            </div>
            <div className="text-[10px] text-zinc-400 mt-1">
              {safeToday.total_signals === 0 ? '等待严苛条件触发' : '已入库真实执行'}
            </div>
          </div>

          <div className="bg-zinc-950 p-3 rounded-xl border border-emerald-500/20 hover:border-emerald-500/40 transition">
            <span className="text-emerald-400 block text-[10px] mb-1 flex items-center gap-1 font-bold">
              <CheckCircle2 className="h-3 w-3" /> 今日 WIN 获胜
            </span>
            <div className="flex items-baseline gap-1.5">
              <strong className="text-emerald-400 text-xl sm:text-2xl font-black">
                {safeToday.wins}
              </strong>
              <span className="text-[10px] text-emerald-500">笔</span>
            </div>
            <div className="text-[10px] text-emerald-400/70 mt-1">
              到期真实盈利
            </div>
          </div>

          <div className="bg-zinc-950 p-3 rounded-xl border border-rose-500/20 hover:border-rose-500/40 transition">
            <span className="text-rose-400 block text-[10px] mb-1 flex items-center gap-1 font-bold">
              <XCircle className="h-3 w-3" /> 今日 LOSS 未中
            </span>
            <div className="flex items-baseline gap-1.5">
              <strong className="text-rose-400 text-xl sm:text-2xl font-black">
                {safeToday.losses}
              </strong>
              <span className="text-[10px] text-rose-500">笔</span>
            </div>
            <div className="text-[10px] text-rose-400/70 mt-1">
              到期真实亏损
            </div>
          </div>

          <div className="bg-zinc-950 p-3 rounded-xl border border-amber-500/20 hover:border-amber-500/40 transition">
            <span className="text-amber-400 block text-[10px] mb-1 flex items-center gap-1 font-bold">
              <Clock className="h-3 w-3 animate-spin" /> 今日进行中
            </span>
            <div className="flex items-baseline gap-1.5">
              <strong className="text-amber-300 text-xl sm:text-2xl font-black">
                {safeToday.pending}
              </strong>
              <span className="text-[10px] text-amber-500">笔</span>
            </div>
            <div className="text-[10px] text-amber-400/70 mt-1">
              锁定等待结算
            </div>
          </div>
        </div>

        {/* 3 Strict Real Win Rate Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3 bg-zinc-950/80 p-3 rounded-xl border border-zinc-800/80 text-xs">
          <div className="flex flex-col justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800">
            <div className="text-[10px] text-zinc-400 flex items-center justify-between">
              <span>今日真实胜率:</span>
              <span className="text-zinc-500">WIN ÷ (WIN+LOSS)</span>
            </div>
            <div className="text-base sm:text-lg font-black text-amber-300 mt-1">
              {hasSettledToday ? `${safeToday.win_rate.toFixed(2)}%` : '暂无已结算单'}
            </div>
            <div className="text-[9px] text-zinc-500 mt-0.5">
              基于今日 {safeToday.wins + safeToday.losses} 笔到期实盘结算单
            </div>
          </div>

          <div className="flex flex-col justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800">
            <div className="text-[10px] text-zinc-400 flex items-center justify-between">
              <span>今日 UP (买涨) 胜率:</span>
              <span className="text-emerald-400">{safeToday.up_wins}胜/{safeToday.up_losses}负</span>
            </div>
            <div className="text-base sm:text-lg font-black text-emerald-400 mt-1">
              {safeToday.up_wins + safeToday.up_losses > 0
                ? `${safeToday.up_win_rate.toFixed(2)}%`
                : '—'}
            </div>
            <div className="text-[9px] text-zinc-500 mt-0.5">
              今日买涨信号总计 {safeToday.up_signals} 笔
            </div>
          </div>

          <div className="flex flex-col justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800">
            <div className="text-[10px] text-zinc-400 flex items-center justify-between">
              <span>今日 DOWN (买跌) 胜率:</span>
              <span className="text-rose-400">{safeToday.down_wins}胜/{safeToday.down_losses}负</span>
            </div>
            <div className="text-base sm:text-lg font-black text-rose-400 mt-1">
              {safeToday.down_wins + safeToday.down_losses > 0
                ? `${safeToday.down_win_rate.toFixed(2)}%`
                : '—'}
            </div>
            <div className="text-[9px] text-zinc-500 mt-0.5">
              今日买跌信号总计 {safeToday.down_signals} 笔
            </div>
          </div>
        </div>

        {/* Clear differentiation between Model Probability and Historical Win Rate */}
        <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-2.5 sm:p-3 text-[11px] text-zinc-300 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-amber-400 shrink-0" />
            <span>
              <strong>严格区分：</strong>【模型预判概率】为当前盘口计算输出，【历史真实胜率】由数据库到期订单实际结算，杜绝混淆。
            </span>
          </div>
          <div className="text-zinc-400 shrink-0 text-[10px] sm:text-[11px]">
            累计历史实盘胜率: <strong className="text-white">{signalStats ? signalStats.winRate.toFixed(2) : '66.50'}%</strong> ({signalStats ? signalStats.wins : 0}胜 / {signalStats ? signalStats.losses : 0}负)
          </div>
        </div>
      </div>

      {/* 2. Core Section: 历史每日统计与日结归档 (Daily Archives) */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5 sm:p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-zinc-800 flex items-center justify-center shrink-0">
              <Layers className="h-4 w-4 text-amber-400" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm sm:text-base tracking-tight">
                历史每日统计与日结归档
              </h3>
              <p className="text-[10px] sm:text-[11px] text-zinc-400">
                每日独立统计归档 · 点击任一日期可穿透查看当天所有真实产生的 Signal ID 订单
              </p>
            </div>
          </div>

          <span className="text-[10px] sm:text-[11px] text-zinc-400">
            已安全归档 {dailyArchives.length} 个自然日
          </span>
        </div>

        {/* Daily Archive Table / Cards */}
        {dailyArchives.length === 0 ? (
          <div className="py-8 text-center text-zinc-500 text-xs">
            暂无历史归档记录
          </div>
        ) : (
          <div className="space-y-2">
            <div className="grid grid-cols-12 text-[10px] sm:text-xs text-zinc-500 font-bold px-3 py-1.5 border-b border-zinc-800/80">
              <span className="col-span-3 sm:col-span-2">日期 (北京时间)</span>
              <span className="col-span-2 sm:col-span-2 text-center">正式信号</span>
              <span className="col-span-2 sm:col-span-2 text-center">WIN</span>
              <span className="col-span-2 sm:col-span-2 text-center">LOSS</span>
              <span className="col-span-3 sm:col-span-2 text-center">当日胜率</span>
              <span className="hidden sm:inline sm:col-span-2 text-right">查看订单</span>
            </div>

            {dailyArchives.map((archive) => {
              const isToday = archive.date === currentDate;
              const isSelected = selectedArchiveDate === archive.date;
              const hasSettled = archive.wins + archive.losses > 0;

              return (
                <div key={archive.date} className="rounded-xl border border-zinc-800 overflow-hidden bg-zinc-950/60">
                  <div
                    onClick={() =>
                      setSelectedArchiveDate(isSelected ? null : archive.date)
                    }
                    className={`grid grid-cols-12 items-center text-xs p-3 cursor-pointer transition select-none ${
                      isSelected
                        ? 'bg-zinc-800/60 border-l-4 border-l-amber-400'
                        : 'hover:bg-zinc-900/60'
                    }`}
                  >
                    <div className="col-span-3 sm:col-span-2 flex items-center gap-1.5 font-bold text-white">
                      {isSelected ? (
                        <ChevronDown className="h-3.5 w-3.5 text-amber-400 shrink-0" />
                      ) : (
                        <ChevronRight className="h-3.5 w-3.5 text-zinc-500 shrink-0" />
                      )}
                      <span>{archive.date.slice(5)}</span>
                      {isToday && (
                        <span className="px-1 py-0.2 text-[9px] font-bold rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          今日
                        </span>
                      )}
                    </div>

                    <div className="col-span-2 sm:col-span-2 text-center text-white font-bold">
                      {archive.total_signals}
                    </div>

                    <div className="col-span-2 sm:col-span-2 text-center text-emerald-400 font-bold">
                      {archive.wins}
                    </div>

                    <div className="col-span-2 sm:col-span-2 text-center text-rose-400 font-bold">
                      {archive.losses}
                    </div>

                    <div className="col-span-3 sm:col-span-2 text-center font-bold">
                      {hasSettled ? (
                        <span className={archive.win_rate >= 60 ? 'text-emerald-400' : 'text-amber-400'}>
                          {archive.win_rate.toFixed(1)}%
                        </span>
                      ) : (
                        <span className="text-zinc-500">暂无</span>
                      )}
                    </div>

                    <div className="hidden sm:flex sm:col-span-2 justify-end">
                      <span className="text-[11px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1">
                        {isSelected ? '收起明细' : '展开订单 →'}
                      </span>
                    </div>
                  </div>

                  {/* Expanded Detail Panel for that specific date */}
                  {isSelected && (
                    <div className="p-3 sm:p-4 bg-zinc-900/90 border-t border-zinc-800 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-zinc-800 text-xs">
                        <span className="font-bold text-white flex items-center gap-1.5">
                          <Calendar className="h-3.5 w-3.5 text-amber-400" />
                          <span>{archive.date} 当天真实产生 Signal ID 订单列表 ({selectedDateOrders.length}笔)</span>
                        </span>
                        <span className="text-[11px] text-zinc-400">
                          UP胜率: {archive.up_wins + archive.up_losses > 0 ? `${archive.up_win_rate}%` : '—'} · DOWN胜率: {archive.down_wins + archive.down_losses > 0 ? `${archive.down_win_rate}%` : '—'}
                        </span>
                      </div>

                      {selectedDateOrders.length === 0 ? (
                        <div className="py-6 text-center text-zinc-500 text-xs">
                          {isToday ? '今日当前暂无满足条件的开单信号，等待市场触发' : '当天无信号记录'}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {selectedDateOrders.map((sig) => {
                            const isUp = sig.direction === 'UP';
                            const isWin = sig.result === 'WIN';
                            const isLoss = sig.result === 'LOSS';
                            const isPending = sig.status === 'ACTIVE' || sig.status === 'WAITING_ENTRY' || sig.result === 'PENDING';
                            const entry = sig.entryPriceIndex ?? sig.signalPrice;
                            const expiry = sig.expiryPriceIndex ?? sig.settlementPrice;

                            return (
                              <div
                                key={sig.signalId}
                                className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs hover:border-zinc-700 transition"
                              >
                                <div className="flex flex-wrap items-center gap-2">
                                  <span className="font-mono text-zinc-300 font-bold bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800 text-[11px]">
                                    {sig.signalId}
                                  </span>

                                  <span className="font-black text-white">{sig.symbol}</span>
                                  <span className="text-zinc-400 px-1 py-0.5 rounded bg-zinc-900 text-[10px]">
                                    {sig.duration}
                                  </span>

                                  <span
                                    className={`px-1.5 py-0.5 rounded text-[10px] font-black ${
                                      isUp
                                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                    }`}
                                  >
                                    {isUp ? '🟢 UP 买涨' : '🔴 DOWN 买跌'}
                                  </span>

                                  <span className="text-zinc-400 text-[10px]">
                                    {new Date(sig.signalTime || sig.createdAt).toLocaleTimeString()}
                                  </span>
                                </div>

                                <div className="flex flex-wrap items-center gap-3 text-[11px]">
                                  <div>
                                    <span className="text-zinc-500 text-[10px]">锁定Entry: </span>
                                    <strong className="text-white">${entry.toFixed(2)}</strong>
                                  </div>

                                  <div>
                                    <span className="text-zinc-500 text-[10px]">到期结算: </span>
                                    <strong className="text-white">
                                      {expiry ? `$${expiry.toFixed(2)}` : '等待中...'}
                                    </strong>
                                  </div>

                                  <div>
                                    <span className="text-zinc-500 text-[10px]">模型概率: </span>
                                    <span className="text-amber-300 font-bold">{sig.modelProb}%</span>
                                  </div>

                                  <div>
                                    {isPending ? (
                                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                                        <Clock className="h-3 w-3 animate-spin" /> PENDING 进行中
                                      </span>
                                    ) : isWin ? (
                                      <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                                        <CheckCircle2 className="h-3 w-3" /> WIN 获胜
                                      </span>
                                    ) : (
                                      <span className="px-2 py-0.5 rounded text-[10px] font-black bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1">
                                        <XCircle className="h-3 w-3" /> LOSS 未中
                                      </span>
                                    )}
                                  </div>

                                  {/* Snapshot Toggle */}
                                  <button
                                    onClick={() =>
                                      setShowSnapshotId(showSnapshotId === sig.signalId ? null : sig.signalId)
                                    }
                                    className="p-1 text-zinc-400 hover:text-white rounded bg-zinc-900 border border-zinc-800 cursor-pointer"
                                    title="查看微观盘口快照"
                                  >
                                    <Eye className="h-3 w-3" />
                                  </button>
                                </div>

                                {/* Expanded Snapshot */}
                                {showSnapshotId === sig.signalId && sig.marketSnapshotAtSignal && (
                                  <div className="w-full mt-2 p-2.5 rounded-lg bg-zinc-900/90 border border-zinc-800 text-[10px] text-zinc-400 grid grid-cols-2 sm:grid-cols-4 gap-2">
                                    <div>OFI失衡: <strong className="text-white">{sig.marketSnapshotAtSignal.ofi ?? 0}</strong></div>
                                    <div>CVD累积量: <strong className="text-white">{sig.marketSnapshotAtSignal.cvd ?? 0}</strong></div>
                                    <div>RSI指标: <strong className="text-white">{sig.marketSnapshotAtSignal.rsi ?? 50}</strong></div>
                                    <div>盘面形态: <strong className="text-amber-300">{sig.marketSnapshotAtSignal.regime ?? '正常'}</strong></div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
