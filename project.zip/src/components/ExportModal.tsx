import React, { useState } from 'react';
import { ExternalLink, Copy, Check, Terminal, Download, ShieldCheck, Globe, Server, Package, Archive } from 'lucide-react';
import { SignalOrder } from '../types/market.js';

interface ExportModalProps {
  signals: SignalOrder[];
  stats?: any;
}

export const ExportModal: React.FC<ExportModalProps> = ({ signals, stats }) => {
  const [copiedDev, setCopiedDev] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const [copiedHealth, setCopiedHealth] = useState(false);
  const [copiedZip, setCopiedZip] = useState(false);

  const devUrl = 'https://ais-dev-ryx6iotxo45avybvjffv7n-565490221983.europe-west3.run.app';
  const sharedUrl = 'https://ais-pre-ryx6iotxo45avybvjffv7n-565490221983.europe-west3.run.app';
  const healthUrl = `${window.location.origin}/health`;
  const zipUrl = `${window.location.origin}/project.zip`;

  const copyToClipboard = (text: string, setter: (val: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setter(true);
    setTimeout(() => setter(false), 2000);
  };

  const exportAllData = () => {
    const exportBundle = {
      exportedAt: new Date().toISOString(),
      signalsCount: signals.length,
      stats,
      signals,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportBundle, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `binance_event_signal_orders_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      {/* Project Source Code Package Download Card */}
      <div className="bg-gradient-to-br from-zinc-900 via-zinc-900 to-zinc-950 border border-amber-500/40 rounded-xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
              <Package className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">项目全量源码打包下载 (project.zip)</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
                  Ready (~238 KB)
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                已将本项目全套源码、币安实时流引擎、机会池择优策略、Firestore云端持久化配置及快速启动文档完整打包。
              </p>
            </div>
          </div>
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => copyToClipboard(zipUrl, setCopiedZip)}
              className="py-2 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              {copiedZip ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              {copiedZip ? '已复制ZIP下载链接' : '复制下载链接'}
            </button>
            <a
              href="/project.zip"
              download="project.zip"
              className="flex-1 sm:flex-none py-2 px-4 rounded-lg bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-lg shadow-amber-500/20"
            >
              <Download className="h-4 w-4" /> 点击直接下载 project.zip
            </a>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-4 text-xs">
          <div className="bg-zinc-950/70 p-3 rounded-lg border border-zinc-800/80">
            <div className="text-zinc-200 font-bold mb-1 flex items-center gap-1.5">
              <span>📁</span> 前端 React 组件
            </div>
            <div className="text-[11px] text-zinc-400">Lightweight Charts, 深度图谱, 实时预测看板</div>
          </div>
          <div className="bg-zinc-950/70 p-3 rounded-lg border border-zinc-800/80">
            <div className="text-zinc-200 font-bold mb-1 flex items-center gap-1.5">
              <span>⚙️</span> 后端高频服务
            </div>
            <div className="text-[11px] text-zinc-400">Express, Socket.IO, 机会池评分与回测引擎</div>
          </div>
          <div className="bg-zinc-950/70 p-3 rounded-lg border border-zinc-800/80">
            <div className="text-zinc-200 font-bold mb-1 flex items-center gap-1.5">
              <span>☁️</span> 双层持久化存储
            </div>
            <div className="text-[11px] text-zinc-400">SQLite 本地库 + Firestore 云数据库规则</div>
          </div>
          <div className="bg-zinc-950/70 p-3 rounded-lg border border-zinc-800/80">
            <div className="text-zinc-200 font-bold mb-1 flex items-center gap-1.5">
              <span>📖</span> 开箱即用支持
            </div>
            <div className="text-[11px] text-zinc-400">包含 README.md 文档与 npm install 运行指令</div>
          </div>
        </div>
      </div>

      {/* Exclusive URLs Card */}
      <div className="bg-gradient-to-br from-zinc-900 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-xl p-6 shadow-xl">
        <div className="flex items-center gap-3 pb-4 border-b border-zinc-800">
          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Globe className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">项目专属网址链接与在线预览</h3>
            <p className="text-xs text-zinc-400">
              云端实时运行中，支持多人同时访问、实时币安 WebSocket 深度行情推流与模型有效信号实盘看盘
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-5">
          {/* Shared Preview URL */}
          <div className="bg-zinc-950/80 border border-zinc-800 rounded-xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4" /> 专属公开预览链接 (Shared App URL)
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  可直接分享
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 mb-3">
                任何拥有该链接的人均可直接体验完整的币安实盘 K 线看盘、实时信号订单与胜率追踪。
              </p>
              <div className="bg-zinc-900 border border-zinc-700/60 rounded-lg p-2.5 font-mono text-xs text-zinc-300 break-all select-all">
                {sharedUrl}
              </div>
            </div>

            <div className="flex items-center gap-2 mt-4 pt-3 border-t border-zinc-800/80">
              <button
                onClick={() => copyToClipboard(sharedUrl, setCopiedShare)}
                className="flex-1 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                {copiedShare ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedShare ? '已复制链接' : '复制预览链接'}
              </button>
              <a
                href={sharedUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs flex items-center gap-1 transition"
              >
                <ExternalLink className="h-3.5 w-3.5" /> 打开
              </a>
            </div>
          </div>

          {/* Development App URL */}
          <div className="bg-zinc-950/80 border border-zinc-800 rounded-xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                  <Server className="h-4 w-4 text-sky-400" /> 开发环境链接 (Development URL)
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
                  开发节点
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 mb-3">
                面向开发者调试、实时查看构建与全栈热重载的云端运行环境。
              </p>
              <div className="bg-zinc-900 border border-zinc-700/60 rounded-lg p-2.5 font-mono text-xs text-zinc-300 break-all select-all">
                {devUrl}
              </div>
            </div>

            <div className="flex items-center gap-2 mt-4 pt-3 border-t border-zinc-800/80">
              <button
                onClick={() => copyToClipboard(devUrl, setCopiedDev)}
                className="flex-1 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                {copiedDev ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedDev ? '已复制开发链接' : '复制开发链接'}
              </button>
              <a
                href={devUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs flex items-center gap-1 transition"
              >
                <ExternalLink className="h-3.5 w-3.5" /> 打开
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* API Health & Full Data Export */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Health Check */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Server className="h-5 w-5 text-emerald-400" />
              <h4 className="text-sm font-bold text-white">健康检查接口 (Health Check)</h4>
            </div>
            <p className="text-xs text-zinc-400 mb-3">
              提供标准 JSON 格式的系统运行监控端点，包含服务存活状态、系统运行时间与当前时间戳：
            </p>
            <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 font-mono text-xs text-emerald-400 select-all">
              {healthUrl}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-center gap-2">
            <button
              onClick={() => copyToClipboard(healthUrl, setCopiedHealth)}
              className="flex-1 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              {copiedHealth ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              复制接口URL
            </button>
          </div>
        </div>

        {/* Data Export */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Download className="h-5 w-5 text-amber-400" />
              <h4 className="text-sm font-bold text-white">完整数据导出 (Export)</h4>
            </div>
            <p className="text-xs text-zinc-400 mb-3">
              将当前的模型信号订单记录、胜率统计以及模型参数整体导出为 JSON 格式：
            </p>
            <div className="text-xs text-zinc-400 space-y-1 font-mono">
              <div>• 历史信号订单: {signals.length} 笔</div>
              <div>• 胜率统计: {stats?.winRate ? `${stats.winRate.toFixed(2)}%` : '---'}</div>
              <div>• 数据格式: 完整包含 Signal ID, Entry, Expiry, WIN/LOSS</div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-zinc-800/80">
            <button
              onClick={exportAllData}
              className="w-full py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Download className="h-4 w-4" /> 导出全部信号订单数据 (.json)
            </button>
          </div>
        </div>
      </div>

      {/* Local Run & Deployment Guide */}
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-5 shadow-lg">
        <div className="flex items-center gap-2 mb-3">
          <Terminal className="h-5 w-5 text-amber-400" />
          <h4 className="text-sm font-bold text-white">本地运行与部署说明 (Local Setup & Run)</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800">
            <div className="font-bold text-zinc-200 mb-2">1. 开发调试运行</div>
            <p className="text-zinc-400 mb-3">
              项目使用 Node.js + tsx 直接驱动 <code>server.ts</code>，并在其上挂载 Socket.io 与 Vite 开发中间件：
            </p>
            <pre className="bg-zinc-900 p-2.5 rounded text-amber-300 font-mono text-[11px] overflow-x-auto">
              # 启动高性能全栈服务 (端口 3000)<br />
              npm run dev
            </pre>
          </div>

          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800">
            <div className="font-bold text-zinc-200 mb-2">2. 生产打包与部署</div>
            <p className="text-zinc-400 mb-3">
              前端静态资源编译至 <code>dist</code> 目录，服务端通过 Express 高效托管并承载 WebSocket 高频撮合：
            </p>
            <pre className="bg-zinc-900 p-2.5 rounded text-emerald-300 font-mono text-[11px] overflow-x-auto">
              # 编译前端构建产物<br />
              npm run build<br />
              # 启动生产服务<br />
              npm start
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
