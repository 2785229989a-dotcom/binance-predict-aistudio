import React, { useState, useMemo, useEffect } from 'react';
import {
  DailySignalStats,
  DurationType,
  SignalOrder,
  SignalOrderStats,
  SymbolType,
} from '../types/market.js';
import {
  CheckCircle2,
  XCircle,
  Clock,
  Filter,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Calendar,
  Layers,
} from 'lucide-react';

interface HistoryOrdersPanelProps {
  signalOrders?: SignalOrder[];
  stats?: SignalOrderStats | null;
  currentPrices?: Record<SymbolType, number>;
  btcPrice?: number;
  ethPrice?: number;
  currentDate?: string;
  todayStats?: DailySignalStats | null;
  dailyArchives?: DailySignalStats[];
}

// Strict Reconstructed WIN / LOSS rule (No TIE):
// UP: Expiry > Entry -> WIN, else LOSS
// DOWN: Expiry < Entry -> WIN, else LOSS
export const isSignalWon = (s: SignalOrder): boolean => {
  if (s.result === 'WIN') return true;
  if (s.result === 'LOSS') return false;
  const entry = s.entryPriceIndex ?? s.signalPrice ?? 0;
  const expiry = s.expiryPriceIndex ?? entry;
  return s.direction === 'UP' ? expiry > entry : expiry < entry;
};

export const HistoryOrdersPanel: React.FC<HistoryOrdersPanelProps> = ({
  signalOrders = [],
  stats,
  currentPrices,
  btcPrice = 0,
  ethPrice = 0,
  currentDate = '2026-10-07',
  todayStats,
  dailyArchives = [],
}) => {
  const [filterDate, setFilterDate] = useState<string>('ALL');
  const [filterSymbol, setFilterSymbol] = useState<'ALL' | SymbolType>('ALL');
  const [filterDuration, setFilterDuration] = useState<'ALL' | DurationType>('ALL');
  const [filterDirection, setFilterDirection] = useState<'ALL' | 'UP' | 'DOWN'>('ALL');
  const [filterResult, setFilterResult] = useState<'ALL' | 'WIN' | 'LOSS' | 'ACTIVE'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Clock tick for countdown
  const [now, setNow] = useState<number>(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Filtered Signal Orders (No TIE filter)
  const filteredSignalOrders = useMemo(() => {
    return signalOrders.filter((s) => {
      if (filterDate !== 'ALL') {
        const orderDate = s.date || (s.signalTime ? new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Shanghai' }).format(new Date(s.signalTime)) : '');
        if (orderDate !== filterDate) return false;
      }
      if (filterSymbol !== 'ALL' && s.symbol !== filterSymbol) return false;
      if (filterDuration !== 'ALL' && s.duration !== filterDuration) return false;
      if (filterDirection !== 'ALL' && s.direction !== filterDirection) return false;

      const isOngoing = s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY';
      if (filterResult === 'ACTIVE' && !isOngoing) return false;
      if (filterResult === 'WIN' && (isOngoing || !isSignalWon(s))) return false;
      if (filterResult === 'LOSS' && (isOngoing || isSignalWon(s))) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          s.signalId.toLowerCase().includes(q) ||
          s.symbol.toLowerCase().includes(q) ||
          s.duration.toLowerCase().includes(q)
        );
      }

      return true;
    });
  }, [signalOrders, filterDate, filterSymbol, filterDuration, filterDirection, filterResult, searchQuery]);

  // Compute Signal Stats accurately (Strict WIN / LOSS, no TIE)
  const computedStats = useMemo(() => {
    const totalSignals = signalOrders.length;
    const settled = signalOrders.filter((s) => s.status === 'SETTLED');
    const active = signalOrders.filter((s) => s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY');

    const wins = settled.filter(isSignalWon).length;
    const losses = settled.length - wins;
    const winRate = wins + losses > 0 ? Number(((wins / (wins + losses)) * 100).toFixed(2)) : 0;

    const calcRate = (w: number, l: number) =>
      w + l > 0 ? Number(((w / (w + l)) * 100).toFixed(2)) : 0;

    const upOrders = settled.filter((s) => s.direction === 'UP');
    const upWins = upOrders.filter(isSignalWon).length;
    const upLosses = upOrders.length - upWins;

    const downOrders = settled.filter((s) => s.direction === 'DOWN');
    const downWins = downOrders.filter(isSignalWon).length;
    const downLosses = downOrders.length - downWins;

    const btcOrders = settled.filter((s) => s.symbol === 'BTCUSDT');
    const btcWins = btcOrders.filter(isSignalWon).length;
    const btcLosses = btcOrders.length - btcWins;

    const ethOrders = settled.filter((s) => s.symbol === 'ETHUSDT');
    const ethWins = ethOrders.filter(isSignalWon).length;
    const ethLosses = ethOrders.length - ethWins;

    const ALL_DURATIONS: DurationType[] = ['30s', '3m', '5m', '10m', '15m', '30m', '1h', '4h', '1d'];
    const durStats: Record<DurationType, { total: number; winRate: number }> = {
      '30s': { total: 0, winRate: 0 },
      '3m': { total: 0, winRate: 0 },
      '5m': { total: 0, winRate: 0 },
      '10m': { total: 0, winRate: 0 },
      '15m': { total: 0, winRate: 0 },
      '30m': { total: 0, winRate: 0 },
      '1h': { total: 0, winRate: 0 },
      '4h': { total: 0, winRate: 0 },
      '1d': { total: 0, winRate: 0 },
    };

    ALL_DURATIONS.forEach((d) => {
      const dOrders = settled.filter((s) => s.duration === d);
      const dW = dOrders.filter(isSignalWon).length;
      const dL = dOrders.length - dW;
      durStats[d] = {
        total: signalOrders.filter((s) => s.duration === d).length,
        winRate: calcRate(dW, dL),
      };
    });

    return {
      totalSignals,
      activeCount: active.length,
      settledCount: settled.length,
      wins,
      losses,
      winRate,
      upWinRate: calcRate(upWins, upLosses),
      downWinRate: calcRate(downWins, downLosses),
      btcWinRate: calcRate(btcWins, btcLosses),
      ethWinRate: calcRate(ethWins, ethLosses),
      durStats,
    };
  }, [signalOrders]);

  return (
    <div className="space-y-4 sm:space-y-6 max-w-full overflow-x-hidden">
      {/* Top Banner: Model Signal Order Performance & Win Rate Statistics */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-3 sm:p-5 lg:p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4 pb-3 sm:pb-4 border-b border-zinc-800/80">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-amber-400 animate-ping" />
              <h2 className="text-sm sm:text-base md:text-lg font-black text-white tracking-tight flex items-center gap-1.5 sm:gap-2">
                <Sparkles className="h-4 sm:h-5 w-4 sm:w-5 text-amber-400 shrink-0" />
                模型有效信号订单历史与胜率统计
              </h2>
            </div>
            <p className="text-[11px] sm:text-xs text-zinc-400 mt-1">
              模型自动产生，T+1s 锁定 Entry，到期以 Expiry Index 判定胜负（WIN / LOSS），无人工模拟干扰
            </p>
          </div>

          {/* Core Overall Win Rate Badge */}
          <div className="flex items-center justify-between sm:justify-start gap-3 bg-zinc-950 px-3 py-2 sm:px-4 sm:py-2.5 rounded-xl border border-zinc-800 font-mono shrink-0">
            <div>
              <div className="text-[9px] sm:text-[10px] text-zinc-500 uppercase tracking-wider">
                模型总胜率 (WIN ÷ (WIN+LOSS))
              </div>
              <div className="text-xl sm:text-2xl md:text-3xl font-black text-emerald-400 flex items-center gap-1">
                <span>{computedStats.winRate.toFixed(2)}%</span>
              </div>
            </div>
            <div className="border-l border-zinc-800 pl-2.5 sm:pl-3 text-[11px] text-zinc-400 space-y-0.5">
              <div>有效信号: <strong className="text-white">{computedStats.totalSignals}</strong></div>
              <div>进行中: <strong className="text-amber-300">{computedStats.activeCount}</strong></div>
            </div>
          </div>
        </div>

        {/* Primary Metric Grid (Total, WIN, LOSS - Clean 3 columns, No TIE) */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 pt-3 sm:pt-4 font-mono text-center">
          <div className="bg-zinc-900/80 p-2.5 sm:p-3 rounded-xl border border-zinc-800">
            <span className="text-[11px] sm:text-xs text-zinc-400 block mb-0.5 sm:mb-1">总有效信号</span>
            <span className="text-lg sm:text-2xl font-black text-white">{computedStats.totalSignals}</span>
          </div>

          <div className="bg-emerald-950/20 p-2.5 sm:p-3 rounded-xl border border-emerald-500/30">
            <span className="text-[11px] sm:text-xs text-emerald-400 flex items-center justify-center gap-1 mb-0.5 sm:mb-1 font-bold">
              <CheckCircle2 className="h-3 sm:h-3.5 w-3 sm:w-3.5" /> WIN 获胜
            </span>
            <span className="text-lg sm:text-2xl font-black text-emerald-400">{computedStats.wins}</span>
          </div>

          <div className="bg-rose-950/20 p-2.5 sm:p-3 rounded-xl border border-rose-500/30">
            <span className="text-[11px] sm:text-xs text-rose-400 flex items-center justify-center gap-1 mb-0.5 sm:mb-1 font-bold">
              <XCircle className="h-3 sm:h-3.5 w-3 sm:w-3.5" /> LOSS 未中
            </span>
            <span className="text-lg sm:text-2xl font-black text-rose-400">{computedStats.losses}</span>
          </div>
        </div>

        {/* Sub-Category Win Rates Matrix (UP, DOWN, BTC, ETH, Durations) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-1.5 sm:gap-2 pt-2.5 sm:pt-3 font-mono text-[10px] sm:text-[11px]">
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">UP 买涨胜率</span>
            <strong className="text-emerald-400 font-bold">{computedStats.upWinRate.toFixed(1)}%</strong>
          </div>
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">DOWN 买跌胜率</span>
            <strong className="text-rose-400 font-bold">{computedStats.downWinRate.toFixed(1)}%</strong>
          </div>
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">BTC 胜率</span>
            <strong className="text-amber-300 font-bold">{computedStats.btcWinRate.toFixed(1)}%</strong>
          </div>
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">ETH 胜率</span>
            <strong className="text-sky-300 font-bold">{computedStats.ethWinRate.toFixed(1)}%</strong>
          </div>
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">10m 胜率</span>
            <strong className="text-white font-bold">{computedStats.durStats['10m'].winRate.toFixed(1)}%</strong>
          </div>
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">30m 胜率</span>
            <strong className="text-white font-bold">{computedStats.durStats['30m'].winRate.toFixed(1)}%</strong>
          </div>
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">1h 胜率</span>
            <strong className="text-white font-bold">{computedStats.durStats['1h'].winRate.toFixed(1)}%</strong>
          </div>
          <div className="bg-zinc-950 p-1.5 sm:p-2 rounded-lg border border-zinc-800 text-center">
            <span className="text-zinc-500 block text-[9px] sm:text-[10px]">1d 胜率</span>
            <strong className="text-white font-bold">{computedStats.durStats['1d'].winRate.toFixed(1)}%</strong>
          </div>
        </div>
      </div>

      {/* Responsive Filters Toolbar (Swipeable on mobile, min 40px touch height) */}
      <div className="bg-zinc-900/60 p-2.5 sm:p-3.5 rounded-xl border border-zinc-800 space-y-2.5 text-xs">
        <div className="flex items-center justify-between">
          <span className="text-zinc-400 font-bold flex items-center gap-1 text-[11px] sm:text-xs">
            <Filter className="h-3.5 w-3.5 text-amber-400" /> 多维信号筛选:
          </span>
          <span className="text-zinc-500 font-mono text-[10px] sm:text-[11px]">
            共筛选出 <strong className="text-amber-400">{filteredSignalOrders.length}</strong> 笔有效信号
          </span>
        </div>

        {/* Scrollable Filter Chips with 40px touch target (NO TIE) */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5 whitespace-nowrap">
          {/* Natural Date Filter (Asia/Shanghai) */}
          <div className="flex bg-zinc-950 p-1 rounded-xl border border-amber-500/30 font-mono shrink-0">
            <button
              onClick={() => setFilterDate('ALL')}
              className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs flex items-center gap-1 ${
                filterDate === 'ALL' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow' : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Calendar className="h-3 w-3 text-amber-400" />
              <span>全部日期</span>
            </button>
            <button
              onClick={() => setFilterDate(currentDate)}
              className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs flex items-center gap-1 ${
                filterDate === currentDate ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow' : 'text-zinc-400 hover:text-white'
              }`}
            >
              <span>今日 ({currentDate.slice(5)})</span>
            </button>
            {dailyArchives
              .filter((a) => a.date !== currentDate)
              .slice(0, 5)
              .map((arch) => (
                <button
                  key={arch.date}
                  onClick={() => setFilterDate(arch.date)}
                  className={`min-h-[38px] px-2.5 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                    filterDate === arch.date ? 'bg-zinc-800 text-amber-300 shadow' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {arch.date.slice(5)}
                </button>
              ))}
          </div>

          {/* Symbol Filter */}
          <div className="flex bg-zinc-950 p-1 rounded-xl border border-zinc-800 font-mono shrink-0">
            {(['ALL', 'BTCUSDT', 'ETHUSDT'] as const).map((sym) => (
              <button
                key={sym}
                onClick={() => setFilterSymbol(sym)}
                className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                  filterSymbol === sym ? 'bg-zinc-800 text-amber-300 shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {sym === 'ALL' ? '全部币种' : sym.slice(0, 3)}
              </button>
            ))}
          </div>

          {/* Duration Filter */}
          <div className="flex bg-zinc-950 p-1 rounded-xl border border-zinc-800 font-mono shrink-0">
            {(['ALL', '10m', '30m', '1h', '1d'] as const).map((d) => (
              <button
                key={d}
                onClick={() => setFilterDuration(d)}
                className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                  filterDuration === d ? 'bg-zinc-800 text-amber-300 shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {d === 'ALL' ? '全部期限' : d}
              </button>
            ))}
          </div>

          {/* Direction Filter */}
          <div className="flex bg-zinc-950 p-1 rounded-xl border border-zinc-800 font-mono shrink-0">
            {(['ALL', 'UP', 'DOWN'] as const).map((dir) => (
              <button
                key={dir}
                onClick={() => setFilterDirection(dir)}
                className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                  filterDirection === dir
                    ? dir === 'UP'
                      ? 'bg-emerald-500/20 text-emerald-400 shadow'
                      : dir === 'DOWN'
                      ? 'bg-rose-500/20 text-rose-400 shadow'
                      : 'bg-zinc-800 text-white shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {dir === 'ALL' ? '全部方向' : dir === 'UP' ? '买涨 (UP)' : '买跌 (DOWN)'}
              </button>
            ))}
          </div>

          {/* Result Filter (Only ALL, WIN, LOSS, ACTIVE - NO TIE) */}
          <div className="flex bg-zinc-950 p-1 rounded-xl border border-zinc-800 font-mono shrink-0">
            {(['ALL', 'WIN', 'LOSS', 'ACTIVE'] as const).map((res) => (
              <button
                key={res}
                onClick={() => setFilterResult(res)}
                className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs ${
                  filterResult === res ? 'bg-zinc-800 text-amber-300 shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {res === 'ALL'
                  ? '全部状态'
                  : res === 'WIN'
                  ? '🟢 WIN (获胜)'
                  : res === 'LOSS'
                  ? '🔴 LOSS (未中)'
                  : '⏳ 进行中'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 1. MOBILE CARD VIEW (Active on screens < 768px: block md:hidden) */}
      {/* ======================================================== */}
      <div className="block md:hidden space-y-3">
        {filteredSignalOrders.length === 0 ? (
          <div className="bg-zinc-950 rounded-2xl border border-zinc-800 p-8 text-center text-zinc-500 text-xs">
            当前暂无符合条件的信号订单记录
          </div>
        ) : (
          filteredSignalOrders.map((sig) => {
            const isOngoing = sig.status === 'ACTIVE' || sig.status === 'WAITING_ENTRY';
            const isWaitingEntry = sig.status === 'WAITING_ENTRY';
            const isWin = isSignalWon(sig);

            // Real-time market data calculation for active orders
            const livePrice =
              currentPrices?.[sig.symbol] ||
              (sig.symbol === 'BTCUSDT' ? btcPrice : ethPrice) ||
              sig.entryPriceIndex ||
              sig.signalPrice ||
              0;
            const entry = sig.entryPriceIndex || sig.signalPrice || livePrice;
            const priceDiff = livePrice - entry;
            const diffSign = priceDiff >= 0 ? '+' : '';
            // Floating profit/loss:
            // For UP: livePrice >= entry -> floating profit (green), else loss (red)
            // For DOWN: livePrice <= entry -> floating profit (green), else loss (red)
            const isFloatingProfit = sig.direction === 'UP' ? priceDiff >= 0 : priceDiff <= 0;

            const remainingSec = isOngoing
              ? isWaitingEntry
                ? Math.max(0, Math.ceil((sig.entryTime - now) / 1000))
                : Math.max(0, Math.floor((sig.expiryTime - now) / 1000))
              : 0;

            const rMin = Math.floor(remainingSec / 60);
            const rSec = remainingSec % 60;
            const isExpanded = expandedId === sig.signalId;

            return (
              <div
                key={sig.signalId || sig.id}
                onClick={() => setExpandedId(isExpanded ? null : sig.signalId)}
                className="bg-zinc-950 rounded-2xl border border-zinc-800 p-3.5 shadow-lg space-y-2.5 font-mono text-xs cursor-pointer active:scale-[0.99] transition"
              >
                {/* Mobile Card Header */}
                <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-white text-sm">{sig.symbol}</span>
                    <span className="text-[10px] text-amber-300 font-bold px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800">
                      {sig.duration}
                    </span>
                    <span
                      className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded font-black text-[11px] ${
                        sig.direction === 'UP'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {sig.direction === 'UP' ? '🟢 买涨' : '🔴 买跌'}
                    </span>
                  </div>

                  {/* Outcome Badge: Only Ongoing, WIN, or LOSS (NO TIE) */}
                  <div>
                    {isOngoing ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-300 bg-amber-500/15 px-2.5 py-0.5 rounded-full border border-amber-500/30 animate-pulse">
                        <Clock className="h-3 w-3 animate-spin" />
                        {isWaitingEntry
                          ? `确立中 (${remainingSec}s)`
                          : `剩余 ${String(rMin).padStart(2, '0')}:${String(rSec).padStart(2, '0')}`}
                      </span>
                    ) : isWin ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-black text-emerald-400 bg-emerald-500/15 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                        <CheckCircle2 className="h-3 w-3" /> WIN 获胜
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-black text-rose-400 bg-rose-500/15 px-2.5 py-0.5 rounded-full border border-rose-500/30">
                        <XCircle className="h-3 w-3" /> LOSS 未中
                      </span>
                    )}
                  </div>
                </div>

                {/* Mobile Card Key-Value Grid */}
                <div className="grid grid-cols-2 gap-2 bg-zinc-900/60 p-2.5 rounded-xl border border-zinc-800 text-[11px]">
                  {/* Left: Entry Info */}
                  <div>
                    <span className="text-zinc-500 block text-[10px]">开仓参考 (Entry):</span>
                    <strong className="text-white text-xs">
                      {sig.entryPriceIndex ? `$${sig.entryPriceIndex.toFixed(2)}` : 'T+1s 确立中'}
                    </strong>
                    <div className="text-[9px] text-zinc-500">
                      {new Date(sig.entryTime).toLocaleTimeString()}
                    </div>
                  </div>

                  {/* Right: Real-time Live Price & Diff for Ongoing, or Expiry for Settled */}
                  <div>
                    {isOngoing ? (
                      <div className="space-y-0.5">
                        <div className="flex items-center justify-between">
                          <span className="text-zinc-400 text-[10px]">实时价格:</span>
                          <strong className="text-white text-xs">
                            ${livePrice > 0 ? livePrice.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '---'}
                          </strong>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-zinc-400 text-[10px]">实时价差:</span>
                          <span
                            className={`font-black text-xs flex items-center gap-1 ${
                              isFloatingProfit ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            <span>
                              {diffSign}{priceDiff.toFixed(2)}
                            </span>
                            <span
                              className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                                isFloatingProfit
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                              }`}
                            >
                              {isFloatingProfit ? '浮盈' : '浮亏'}
                            </span>
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <span className="text-zinc-500 block text-[10px]">到期结算 (Expiry):</span>
                        <strong className="text-zinc-200 text-xs">
                          ${sig.expiryPriceIndex ? sig.expiryPriceIndex.toFixed(2) : '---'}
                        </strong>
                        <div className="text-[9px] text-zinc-500">
                          {new Date(sig.expiryTime).toLocaleTimeString()}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Model Probability & Payout */}
                  <div>
                    <span className="text-zinc-500 block text-[10px]">模型胜率 / 赔率:</span>
                    <span className="text-amber-300 font-bold text-xs">
                      {sig.modelProb}% ({(sig.payoutRatio * 100).toFixed(0)}%)
                    </span>
                  </div>

                  {/* Edge & Expected Value */}
                  <div>
                    <span className="text-zinc-500 block text-[10px]">统计优势 / 期望值:</span>
                    <span className="text-emerald-400 font-bold text-xs">
                      +{sig.edge}% / +{sig.expectedValue ?? '0'}U
                    </span>
                  </div>
                </div>

                {/* Mobile Card Footer */}
                <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1">
                  <span className="truncate max-w-[200px]" title={sig.signalId}>
                    ID: {sig.signalId.slice(0, 18)}...
                  </span>
                  <span className="text-zinc-400 flex items-center gap-0.5">
                    {isExpanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                    {isExpanded ? '收起详情' : '展开详情'}
                  </span>
                </div>

                {/* Expanded Details Drawer for Mobile */}
                {isExpanded && (
                  <div className="pt-2 border-t border-zinc-800/80 text-[10px] text-zinc-400 space-y-1.5 animate-fadeIn">
                    <div className="flex justify-between">
                      <span>完整 Signal ID:</span>
                      <span className="text-zinc-300 select-all font-mono">{sig.signalId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>信号产生时间:</span>
                      <span className="text-zinc-300">{new Date(sig.signalTime || sig.createdAt).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>信号触发瞬时价:</span>
                      <span className="text-zinc-300">${sig.signalPrice?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>盈亏平衡门槛:</span>
                      <span className="text-zinc-300">{sig.breakEvenProb}%</span>
                    </div>
                    {sig.resultDetail && (
                      <div className="p-2 bg-zinc-900 rounded-lg text-zinc-300 border border-zinc-800 mt-1">
                        {sig.resultDetail}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* ======================================================== */}
      {/* 2. DESKTOP TABLE VIEW (Active on screens >= 768px: hidden md:block) */}
      {/* ======================================================== */}
      <div className="hidden md:block bg-zinc-950 rounded-2xl border border-zinc-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-zinc-900/90 text-zinc-400 uppercase text-[10px] tracking-wider border-b border-zinc-800">
              <tr>
                <th className="py-3 px-3.5">Signal ID / 产生时间</th>
                <th className="py-3 px-3.5">标的 · 期限</th>
                <th className="py-3 px-3.5">信号方向</th>
                <th className="py-3 px-3.5">Entry Price Index (T+1s)</th>
                <th className="py-3 px-3.5">到期结算价 / 实时监控</th>
                <th className="py-3 px-3.5">模型胜率 / 赔率 / EV</th>
                <th className="py-3 px-3.5">状态 / 裁决结果</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80 text-zinc-300">
              {filteredSignalOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-zinc-500 font-sans">
                    当前暂无符合条件的信号订单记录
                  </td>
                </tr>
              ) : (
                filteredSignalOrders.map((sig) => {
                  const isOngoing = sig.status === 'ACTIVE' || sig.status === 'WAITING_ENTRY';
                  const isWaitingEntry = sig.status === 'WAITING_ENTRY';
                  const isWin = isSignalWon(sig);

                  // Real-time market data calculation
                  const livePrice =
                    currentPrices?.[sig.symbol] ||
                    (sig.symbol === 'BTCUSDT' ? btcPrice : ethPrice) ||
                    sig.entryPriceIndex ||
                    sig.signalPrice ||
                    0;
                  const entry = sig.entryPriceIndex || sig.signalPrice || livePrice;
                  const priceDiff = livePrice - entry;
                  const diffSign = priceDiff >= 0 ? '+' : '';
                  const isFloatingProfit = sig.direction === 'UP' ? priceDiff >= 0 : priceDiff <= 0;

                  const remainingSec = isOngoing
                    ? isWaitingEntry
                      ? Math.max(0, Math.ceil((sig.entryTime - now) / 1000))
                      : Math.max(0, Math.floor((sig.expiryTime - now) / 1000))
                    : 0;

                  const rMin = Math.floor(remainingSec / 60);
                  const rSec = remainingSec % 60;

                  return (
                    <tr
                      key={sig.signalId || sig.id}
                      className="hover:bg-zinc-900/40 transition cursor-pointer"
                      onClick={() => setExpandedId(expandedId === sig.signalId ? null : sig.signalId)}
                    >
                      <td className="py-3 px-3.5">
                        <div className="font-bold text-white text-[11px] truncate max-w-[150px]" title={sig.signalId}>
                          {sig.signalId}
                        </div>
                        <div className="text-[10px] text-zinc-500">
                          {new Date(sig.signalTime || sig.createdAt).toLocaleTimeString()}
                        </div>
                      </td>

                      <td className="py-3 px-3.5">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span>{sig.symbol}</span>
                          <span className="text-[10px] text-amber-300 font-bold px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800">
                            {sig.duration}
                          </span>
                        </div>
                      </td>

                      <td className="py-3 px-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded font-black text-[11px] ${
                            sig.direction === 'UP'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          }`}
                        >
                          {sig.direction === 'UP' ? '🟢 买涨 UP' : '🔴 买跌 DOWN'}
                        </span>
                      </td>

                      <td className="py-3 px-3.5">
                        {isWaitingEntry ? (
                          <span className="text-amber-400 flex items-center gap-1 font-bold animate-pulse text-[11px]">
                            <Clock className="h-3 w-3" /> T+1s 确立中 ({remainingSec}s)
                          </span>
                        ) : (
                          <div>
                            <strong className="text-white">
                              ${sig.entryPriceIndex?.toFixed(2) || sig.signalPrice?.toFixed(2)}
                            </strong>
                            <div className="text-[10px] text-zinc-500">
                              {new Date(sig.entryTime).toLocaleTimeString()}
                            </div>
                          </div>
                        )}
                      </td>

                      {/* Expiry Price Index OR Real-time Monitoring for Active Orders */}
                      <td className="py-3 px-3.5">
                        {isOngoing ? (
                          <div className="text-xs">
                            <div className="flex items-center gap-1">
                              <span className="text-zinc-500 text-[10px]">实时:</span>
                              <strong className="text-white">${livePrice > 0 ? livePrice.toFixed(2) : '---'}</strong>
                            </div>
                            <div className="text-[10px] flex items-center gap-1">
                              <span className="text-zinc-500">价差:</span>
                              <span className={`font-bold ${isFloatingProfit ? 'text-emerald-400' : 'text-rose-400'}`}>
                                {diffSign}{priceDiff.toFixed(2)} ({isFloatingProfit ? '浮盈' : '浮亏'})
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div>
                            <strong className="text-white">
                              ${sig.expiryPriceIndex?.toFixed(2) || '---'}
                            </strong>
                            <div className="text-[10px] text-zinc-500">
                              {new Date(sig.expiryTime).toLocaleTimeString()}
                            </div>
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-3.5">
                        <div className="text-zinc-200">
                          胜率: <strong>{sig.modelProb}%</strong> · 赔率: {(sig.payoutRatio * 100).toFixed(0)}%
                        </div>
                        <div className="text-[10px] text-zinc-500">
                          Edge: +{sig.edge}% · EV: +{sig.expectedValue ?? '0'}U
                        </div>
                      </td>

                      {/* Outcome: Ongoing, WIN, or LOSS (NO TIE) */}
                      <td className="py-3 px-3.5">
                        {isOngoing ? (
                          <span className="inline-flex items-center gap-1 text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/20 font-bold">
                            <Clock className="h-3 w-3 animate-spin" />
                            进行中 ({String(rMin).padStart(2, '0')}:{String(rSec).padStart(2, '0')})
                          </span>
                        ) : isWin ? (
                          <span className="inline-flex items-center gap-1 text-emerald-400 font-black bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/20">
                            <CheckCircle2 className="h-3.5 w-3.5" /> 🟢 WIN 获胜
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-rose-400 font-black bg-rose-500/10 px-2.5 py-0.5 rounded border border-rose-500/20">
                            <XCircle className="h-3.5 w-3.5" /> 🔴 LOSS 未中
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
