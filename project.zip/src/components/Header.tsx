import React from 'react';
import { DurationType, MarketSnapshot, SymbolType } from '../types/market.js';
import {
  Volume2,
  VolumeX,
  ArrowDownRight,
  ArrowUpRight,
  RefreshCw,
  TrendingUp,
  Zap,
  Play,
  Pause,
  Clock,
  Radio,
} from 'lucide-react';
import { soundManager } from '../utils/soundAlert.js';

interface HeaderProps {
  currentSymbol: SymbolType;
  onSelectSymbol: (symbol: SymbolType) => void;
  btcSnapshot: MarketSnapshot | null;
  ethSnapshot: MarketSnapshot | null;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  isConnected: boolean;
  paperBalance: number;
  onResetBalance: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  selectedDuration?: DurationType;
  onSelectDuration?: (duration: DurationType) => void;
  isPredictionActive: boolean;
  onTogglePrediction: () => void;
  onManualRefresh: () => void;
  isRefreshing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentSymbol,
  onSelectSymbol,
  btcSnapshot,
  ethSnapshot,
  activeTab,
  onSelectTab,
  isConnected,
  paperBalance,
  onResetBalance,
  soundEnabled,
  onToggleSound,
  selectedDuration = '10m',
  onSelectDuration,
  isPredictionActive,
  onTogglePrediction,
  onManualRefresh,
  isRefreshing,
}) => {
  const currentSnap = currentSymbol === 'BTCUSDT' ? btcSnapshot : ethSnapshot;
  const isUp = (currentSnap?.priceChangePercent24h || 0) >= 0;

  const tabs = [
    { id: 'live', label: '实时双币预测' },
    { id: 'diagnostics', label: '开单信号诊断' },
    { id: 'trade', label: '模拟交易' },
    { id: 'orders', label: '历史订单' },
    { id: 'signals', label: '历史信号' },
    { id: 'backtest', label: '策略回测' },
    { id: 'exam', label: '模型考试' },
    { id: 'export', label: '专属链接与导出' },
  ];

  const latency = currentSnap?.latencyMs || 35;
  const lastTimeStr = currentSnap?.lastUpdated
    ? new Date(currentSnap.lastUpdated).toLocaleTimeString()
    : new Date().toLocaleTimeString();

  const predTimeStr = currentSnap?.prediction?.timestamp
    ? new Date(currentSnap.prediction.timestamp).toLocaleTimeString()
    : lastTimeStr;

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/95 backdrop-blur sticky top-0 z-50">
      {/* Top Banner: Real-time Status, Latency, WebSocket, Audio & Refresh Controls */}
      <div className="bg-zinc-900/95 border-b border-zinc-800/80 px-3 py-1.5 text-[11px] text-zinc-400">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Connection status, WebSocket, Latency, Timestamps */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Binance Public Stream Status */}
            <span className="flex items-center gap-1.5 font-medium">
              <span
                className={`h-2 w-2 rounded-full ${
                  isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
                }`}
              />
              <span className={isConnected ? 'text-emerald-400' : 'text-rose-400'}>
                {isConnected ? 'Binance 官方公开实时数据流: 已连接' : '行情连接中...'}
              </span>
            </span>

            <span className="text-zinc-600 hidden xs:inline">|</span>

            {/* WebSocket Status */}
            <span className="flex items-center gap-1 font-mono text-zinc-300">
              <Radio className="h-3 w-3 text-emerald-400" />
              <span>WS: {isConnected ? '实时推流中' : '自愈轮询'}</span>
            </span>

            <span className="text-zinc-600 hidden sm:inline">|</span>

            {/* Latency */}
            <span className="flex items-center gap-1 font-mono">
              <Zap className="h-3 w-3 text-amber-400" />
              延迟: <span className="text-zinc-200">{latency}ms</span>
            </span>

            <span className="text-zinc-600 hidden md:inline">|</span>

            {/* Last Data Time */}
            <span className="hidden md:flex items-center gap-1 font-mono text-zinc-300">
              <Clock className="h-3 w-3 text-zinc-500" />
              数据更新: <span className="text-zinc-200">{lastTimeStr}</span>
            </span>

            <span className="text-zinc-600 hidden lg:inline">|</span>

            {/* Prediction Evaluation Time */}
            <span className="hidden lg:flex items-center gap-1 font-mono text-amber-300/90">
              模型计算: <span>{predTimeStr}</span>
            </span>
          </div>

          {/* Action Buttons: Start/Pause Prediction, Refresh, Audio, Quick Ticker */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Start / Stop Prediction Toggle Button */}
            <button
              onClick={onTogglePrediction}
              className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold transition border ${
                isPredictionActive
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
              }`}
              title={isPredictionActive ? '点击暂停实时预测计算' : '点击恢复实时预测计算'}
            >
              {isPredictionActive ? (
                <>
                  <Pause className="h-3 w-3 text-emerald-400" />
                  <span>预测: 运行中</span>
                </>
              ) : (
                <>
                  <Play className="h-3 w-3 text-amber-400" />
                  <span>预测: 已暂停</span>
                </>
              )}
            </button>

            {/* Manual Refresh Button */}
            <button
              onClick={onManualRefresh}
              disabled={isRefreshing}
              className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-zinc-900 text-zinc-300 border border-zinc-700 hover:text-white hover:border-zinc-500 transition disabled:opacity-50"
              title="立即强制向后端拉取最新行情与模型预测"
            >
              <RefreshCw className={`h-3 w-3 text-amber-400 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? '刷新中' : '刷新'}</span>
            </button>

            {/* Audio Alert Toggle */}
            <button
              onClick={() => {
                soundManager.initAudio();
                onToggleSound();
              }}
              className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium transition border ${
                soundEnabled
                  ? 'bg-amber-400/20 text-amber-300 border-amber-400/40 hover:bg-amber-400/30'
                  : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:text-zinc-300'
              }`}
              title="当出现有效买涨/买跌信号时发出语音与音效提示"
            >
              {soundEnabled ? (
                <>
                  <Volume2 className="h-3 w-3 text-amber-400 animate-pulse" />
                  <span className="hidden sm:inline">声音: 开</span>
                </>
              ) : (
                <>
                  <VolumeX className="h-3 w-3" />
                  <span className="hidden sm:inline">声音: 关</span>
                </>
              )}
            </button>

            {/* Dual Live Price badges */}
            <div className="hidden xs:flex items-center gap-1.5 font-mono font-bold text-xs">
              <div className="bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800 text-amber-400">
                BTC: ${btcSnapshot?.price ? btcSnapshot.price.toLocaleString(undefined, { minimumFractionDigits: 1 }) : '---'}
              </div>
              <div className="bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800 text-sky-400">
                ETH: ${ethSnapshot?.price ? ethSnapshot.price.toLocaleString(undefined, { minimumFractionDigits: 1 }) : '---'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Logo & Symbol Selector */}
          <div className="flex items-center justify-between sm:justify-start gap-3">
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center shadow-lg shadow-amber-500/20 shrink-0">
                <TrendingUp className="h-4.5 w-4.5 text-zinc-950 font-black" />
              </div>
              <div>
                <h1 className="font-bold text-sm sm:text-base text-white tracking-tight flex items-center gap-1.5">
                  Binance 10分钟事件合约预测工作台
                  <span className="text-[9px] uppercase font-bold tracking-widest px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    实盘量化
                  </span>
                </h1>
                <div className="text-[10px] text-zinc-400">
                  真实基准价 P0 锚定 • 微观订单流 OFI/CVD • 严格 WAIT 风控过滤
                </div>
              </div>
            </div>

            {/* Symbol Switcher */}
            <div className="flex items-center bg-zinc-900 p-0.5 rounded-lg border border-zinc-800 shrink-0">
              <button
                onClick={() => onSelectSymbol('BTCUSDT')}
                className={`px-3 py-1 text-xs font-bold rounded-md transition ${
                  currentSymbol === 'BTCUSDT'
                    ? 'bg-amber-400 text-zinc-950 shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                BTC
              </button>
              <button
                onClick={() => onSelectSymbol('ETHUSDT')}
                className={`px-3 py-1 text-xs font-bold rounded-md transition ${
                  currentSymbol === 'ETHUSDT'
                    ? 'bg-amber-400 text-zinc-950 shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                ETH
              </button>
            </div>
          </div>

          {/* Quick Stats & Virtual Balance */}
          <div className="flex items-center justify-between sm:justify-end gap-3 text-xs">
            {currentSnap && (
              <div className="flex items-center gap-1.5 bg-zinc-900 px-2.5 py-1 rounded-lg border border-zinc-800">
                <span className="text-[10px] text-zinc-400 font-sans">{currentSymbol}</span>
                <span
                  className={`font-mono font-bold flex items-center ${
                    isUp ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                  {currentSnap.priceChangePercent24h > 0 ? '+' : ''}
                  {currentSnap.priceChangePercent24h.toFixed(2)}%
                </span>
              </div>
            )}

            {/* Paper Trading Balance */}
            <div className="flex items-center gap-2 bg-gradient-to-r from-emerald-950/40 to-zinc-900 border border-emerald-500/30 px-2.5 py-1 rounded-lg">
              <div>
                <div className="text-[9px] text-emerald-400/80 font-medium">模拟账户资金</div>
                <div className="font-mono font-bold text-xs text-emerald-400">
                  ${paperBalance.toLocaleString(undefined, { minimumFractionDigits: 1 })}
                </div>
              </div>
              <button
                onClick={onResetBalance}
                title="重置模拟资金至 $10,000"
                className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <RefreshCw className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Tab Navigation (Horizontal Scrollable for Mobile) */}
        <div className="flex space-x-1 border-t border-zinc-800/80 pt-2 mt-2 overflow-x-auto scrollbar-none">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-t-lg transition whitespace-nowrap border-b-2 ${
                  isActive
                    ? 'border-amber-400 text-amber-300 bg-zinc-900/80 shadow-sm'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/30'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
