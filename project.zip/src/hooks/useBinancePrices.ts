import { useState, useEffect } from 'react';
import {
  binanceRealtime,
  ConnectionMode,
  RealtimeTickerData,
} from '../services/binanceRealtime.js';

export function useBinancePrices() {
  const [tickers, setTickers] = useState<Record<string, RealtimeTickerData>>(() =>
    binanceRealtime.getLatestTickers()
  );
  const [connectionMode, setConnectionMode] = useState<ConnectionMode>(() =>
    binanceRealtime.getConnectionMode()
  );

  useEffect(() => {
    const unsubscribe = binanceRealtime.subscribe((newTickers, mode) => {
      setTickers({ ...newTickers });
      setConnectionMode(mode);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const btcPrice = tickers.BTCUSDT?.price || 0;
  const ethPrice = tickers.ETHUSDT?.price || 0;

  return {
    btcPrice,
    ethPrice,
    prices: {
      BTCUSDT: btcPrice,
      ETHUSDT: ethPrice,
    },
    tickers,
    btcTicker: tickers.BTCUSDT,
    ethTicker: tickers.ETHUSDT,
    connectionMode,
    isWsConnected: connectionMode === 'websocket',
  };
}
