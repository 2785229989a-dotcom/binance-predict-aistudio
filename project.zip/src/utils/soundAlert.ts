// Sound Alert Utility using Web Audio API and SpeechSynthesis
// Completely self-contained, zero external asset dependencies, browser-friendly

class SoundAlertManager {
  private audioCtx: AudioContext | null = null;
  private isEnabled: boolean = true;
  private lastAlerts: Record<string, { direction: string; timestamp: number }> = {};

  constructor() {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('binance_sound_enabled');
      if (saved !== null) {
        this.isEnabled = saved === 'true';
      }
    }
  }

  public getIsEnabled(): boolean {
    return this.isEnabled;
  }

  public setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
    if (typeof window !== 'undefined') {
      localStorage.setItem('binance_sound_enabled', enabled ? 'true' : 'false');
    }
    if (enabled) {
      this.initAudio();
    }
  }

  // Initialize or resume AudioContext on user interaction
  public initAudio(): boolean {
    try {
      if (!this.audioCtx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          this.audioCtx = new AudioContextClass();
        }
      }
      if (this.audioCtx && this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }
      return true;
    } catch (e) {
      console.warn('AudioContext init error:', e);
      return false;
    }
  }

  // Play synthesized tone
  public playTone(type: 'UP' | 'DOWN'): void {
    if (!this.isEnabled) return;
    this.initAudio();

    if (!this.audioCtx) return;

    try {
      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      if (type === 'UP') {
        // Cheerful ascending chime (C5 -> E5 -> G5)
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.1); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.2); // G5
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      } else {
        // Warning descending chime (G4 -> Eb4 -> C4)
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(392.0, now); // G4
        osc.frequency.setValueAtTime(311.13, now + 0.1); // Eb4
        osc.frequency.setValueAtTime(261.63, now + 0.2); // C4
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      }
    } catch (e) {
      console.warn('Error playing tone:', e);
    }
  }

  // Optional voice notification in Chinese
  public speak(text: string): void {
    if (!this.isEnabled) return;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel(); // cancel any pending speech
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'zh-CN';
        utterance.rate = 1.05;
        utterance.pitch = 1.1;
        window.speechSynthesis.speak(utterance);
      } catch (err) {
        // ignore speech error
      }
    }
  }

  public isUnlocked(): boolean {
    return !!(this.audioCtx && this.audioCtx.state === 'running');
  }

  // De-duplicated trigger: Only notify on NEW valid signals or direction changes
  public notifySignal(
    symbol: string,
    duration: string = '10m',
    direction: 'UP' | 'DOWN' | 'WAIT',
    upProb: number,
    downProb: number
  ): void {
    if (!this.isEnabled || direction === 'WAIT') return;

    const now = Date.now();
    const key = `${symbol}-${duration}`;
    const last = this.lastAlerts[key];

    // Only notify if direction changed or at least 5 minutes have passed
    if (last && last.direction === direction && now - last.timestamp < 300 * 1000) {
      return;
    }

    this.lastAlerts[key] = { direction, timestamp: now };

    // Play distinct audio tone
    this.playTone(direction);

    // Speak announcement
    const coinName = symbol === 'BTCUSDT' ? '比特币' : '以太坊';
    const durLabel =
      duration === '30m'
        ? '30分钟'
        : duration === '1h'
        ? '1小时'
        : duration === '1d'
        ? '1天'
        : '10分钟';
    const dirText = direction === 'UP' ? '买涨' : '买跌';
    const prob = direction === 'UP' ? upProb : downProb;
    this.speak(`${coinName} ${durLabel}开单信号：${dirText}，概率 ${prob}%`);
  }
}

export const soundManager = new SoundAlertManager();
