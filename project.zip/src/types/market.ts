export type SymbolType = 'BTCUSDT' | 'ETHUSDT';

export type DurationType =
  | '30s'
  | '3m'
  | '5m'
  | '10m'
  | '15m'
  | '30m'
  | '1h'
  | '4h'
  | '1d';

export type SignalDirection = 'UP' | 'DOWN' | 'WAIT';

export type SignalLevel = 'STRONG' | 'MODERATE' | 'WEAK' | 'WAIT';

export type MarketRegime =
  | 'TRENDING_UP'
  | 'TRENDING_DOWN'
  | 'RANGING'
  | 'HIGH_VOLATILITY'
  | 'LOW_LIQUIDITY'
  | 'DATA_DELAY';

export type EnhancedMarketRegime =
  | 'TREND_UP'
  | 'TREND_DOWN'
  | 'RANGE'
  | 'HIGH_VOLATILITY'
  | 'LOW_VOLATILITY'
  | 'BREAKOUT'
  | 'BREAKDOWN'
  | 'REVERSAL'
  | 'CHAOTIC';

export type SignalStrengthLevel =
  | 'WAIT'
  | 'WATCH'
  | 'WEAK'
  | 'VALID'
  | 'STRONG'
  | 'VERY_STRONG';

export type ContractResultType =
  | 'UP_WIN'
  | 'DOWN_WIN'
  | 'WIN'
  | 'LOSS'
  | 'FLAT'
  | 'PENDING'
  | 'WAIT_SKIPPED';

export interface OrderBookEntry {
  price: number;
  quantity: number;
  total?: number;
}

export interface OrderBookData {
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  spread: number;
  spreadPercent: number;
  bidTotal: number;
  askTotal: number;
  imbalanceRatio: number; // bids / (bids + asks)
}

export interface KlineData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  quoteVolume: number;
  buyVolume: number;
  sellVolume: number;
  cvd: number;
}

export interface TechnicalIndicators {
  ema7: number;
  ema20: number;
  ema50: number;
  rsi: number;
  atr14: number;
  volatilityPercent: number;
  bollinger: {
    upper: number;
    middle: number;
    lower: number;
    bandwidth: number;
  };
  macd: {
    macd: number;
    signal: number;
    histogram: number;
  };
}

export interface TimeframeTrendInfo {
  timeframe: '1m' | '3m' | '5m' | '15m' | '30m' | '1h';
  direction: 'UP' | 'DOWN' | 'NEUTRAL';
  emaDiffPercent: number;
  rsi: number;
}

export interface MultiTimeframeAnalysis {
  trends: TimeframeTrendInfo[];
  alignmentScore: number; // -100 to +100
  alignmentText: string;
  hasConflict: boolean;
  conflictDescription?: string;
}

export interface TradeMicrostructure {
  tradesPerSecond: number;
  volumePerSecond: number;
  takerBuyRatio: number; // buyVolume / totalVolume
  tickDelta: number; // buyTicks - sellTicks in rolling window
  speedRating: 'HIGH' | 'NORMAL' | 'LOW';
}

export interface FactorBreakdown {
  ofi: {
    score: number; // -100 to +100
    weight: number;
    value: number; // raw OFI
    label: string;
  };
  cvd: {
    score: number;
    weight: number;
    value: number; // CVD change
    slope: number;
    label: string;
  };
  depth: {
    score: number;
    weight: number;
    imbalanceRatio: number;
    skewRatio: number;
    label: string;
  };
  momentum: {
    score: number;
    weight: number;
    rsi: number;
    emaDiff: number;
    label: string;
  };
  multiTf: {
    score: number;
    weight: number;
    alignmentScore: number;
    label: string;
  };
  oi: {
    score: number;
    weight: number;
    openInterest: number;
    oiChange24h: number;
    priceCorrelation: string;
    label: string;
  };
  funding: {
    score: number;
    weight: number;
    rate: number;
    predictedRate: number;
    label: string;
  };
  longShortRatio?: {
    score: number;
    value: number | null;
    label: string;
  };
}

export interface PredictionResult {
  symbol: SymbolType;
  duration?: DurationType;
  timestamp: number;
  referencePrice: number; // Entry reference index price P0
  indexPrice: number; // Current live Price Index
  markPrice: number;
  targetThreshold?: number;
  direction: SignalDirection;
  signalLevel: SignalLevel;
  compositeScore: number; // -100 to +100
  confidence: number; // 0 to 100%
  upProb: number; // 0 to 100%
  downProb: number; // 0 to 100%
  waitProb: number; // 0 to 100%
  breakEvenProb?: number; // 100 / (100 + payoutRatio * 100) * 100
  payoutRatio?: number; // e.g. 0.80 (80%)
  edge?: number; // Model Prob - Break-even Prob
  expectedValue?: number | null; // Expected Value per 100 USDT stake
  winProbability?: number; // Overall model winning probability
  userOdds?: {
    up: number;
    down: number;
  };
  regime: MarketRegime;
  regimeLabel: string;
  isWait: boolean;
  waitReasons: string[];
  recommendedAction: string;
  rationale: string[];
  factors: FactorBreakdown;
  multiTimeframe: MultiTimeframeAnalysis;
  indicators: TechnicalIndicators;
}

export interface PaperTrade {
  id: string;
  roundId: string;
  symbol: SymbolType;
  timestamp: number;
  direction: 'UP' | 'DOWN';
  stake: number;
  duration?: DurationType;
  signalTime?: number;
  orderTime?: number;
  openTime?: number;
  entryPrice?: number;
  strikePrice: number; // Anchored Entry Price Index
  settlementPrice: number | null;
  payoutRatio?: number;
  odds: number;
  status: 'PENDING_OPEN' | 'ACTIVE' | 'WON' | 'LOST';
  result?: ContractResultType;
  pnl: number;
  payout: number;
  settledAt?: number;
  expiryTime?: number;
  modelProbAtEntry?: number;
  breakEvenProb?: number;
  edge?: number;
  expectedValue?: number;
}

export interface EventContractOrder extends PaperTrade {
  order_time?: number;
  open_time?: number;
  entry_index_price?: number;
  expiry_time?: number;
  expiry_index_price?: number | null;
  payout_ratio?: number;
  payout_amount?: number;
  profit_loss?: number;
  break_even_probability?: number;
  model_probability?: number;
  expected_value?: number;
  result?: ContractResultType;
}

export interface EventContractRound {
  roundId: string;
  symbol: SymbolType;
  duration?: DurationType;
  roundNumber: number;
  startTime: number;
  lockTime?: number;
  openTime?: number;
  expiryTime: number;
  durationSeconds: number;
  lockPrice: number; // Entry Price Index P0
  currentPrice: number;
  settlementPrice: number | null;
  status: 'OPEN' | 'LOCKED' | 'SETTLED';
  outcome: 'UP' | 'DOWN' | 'FLAT' | 'UP_WIN' | 'DOWN_WIN' | null;
  upOdds: number;
  downOdds: number;
  payoutRatio?: number;
}

export interface SignalOrder {
  signalId: string;
  id?: string; // backward compat with SignalRecord
  date?: string; // 'YYYY-MM-DD' (Asia/Shanghai)
  symbol: SymbolType;
  duration: DurationType;
  direction: 'UP' | 'DOWN';
  signalTime: number;
  timestamp?: number; // backward compat
  signalPrice: number;
  referencePrice?: number; // backward compat
  modelProb: number;
  rawProb?: number;
  calibratedProb?: number;
  marketProb?: number;
  strengthLevel?: SignalStrengthLevel;
  timeframeRole?: string;
  historicalSampleCount?: number;
  historicalConfidence?: string;
  upProb?: number;
  downProb?: number;
  waitProb?: number;
  payoutRatio: number;
  breakEvenProb: number;
  edge: number;
  expectedValue: number | null;
  entryTime: number;
  entryPriceIndex: number | null;
  expiryTime: number;
  settlementTime?: number; // backward compat
  expiryPriceIndex: number | null;
  settlementPrice?: number | null; // backward compat
  priceChange: number | null;
  status: 'WAITING_ENTRY' | 'ACTIVE' | 'SETTLED';
  result: 'PENDING' | 'WIN' | 'LOSS';
  outcome?: 'WIN' | 'LOSS' | 'FLAT' | 'UP_WIN' | 'DOWN_WIN' | 'PENDING' | 'WAIT_SKIPPED'; // backward compat
  resultDetail: string;
  rationale?: string[];
  factorsSummary?: string;
  score?: number;
  confirmations?: string[];
  riskNotes?: string[];
  signalStrength?: number;
  isFormalSignal?: boolean;
  marketSnapshotAtSignal?: {
    ofi: number;
    cvd: number;
    depthImbalance: number;
    rsi: number;
    atr: number;
    spread: number;
    regime: string;
  };
  simulatedTradeId?: string;
  createdAt: number;
  settledAt?: number;
}

export interface SignalOrderStats {
  totalSignals: number;
  activeCount: number;
  settledCount: number;
  wins: number;
  losses: number;
  ties: number;
  winRate: number; // WIN / (WIN + LOSS) * 100
  upWins: number;
  upLosses: number;
  upTies: number;
  upWinRate: number;
  downWins: number;
  downLosses: number;
  downTies: number;
  downWinRate: number;
  btcWins: number;
  btcLosses: number;
  btcTies: number;
  btcWinRate: number;
  ethWins: number;
  ethLosses: number;
  ethTies: number;
  ethWinRate: number;
  durationStats: Record<
    DurationType,
    {
      total: number;
      wins: number;
      losses: number;
      ties: number;
      winRate: number;
    }
  >;
}

export interface DailySignalStats {
  date: string; // 'YYYY-MM-DD' (Asia/Shanghai)
  total_signals: number;
  pending: number;
  wins: number;
  losses: number;
  win_rate: number; // 0 if no settled signals
  up_signals: number;
  up_wins: number;
  up_losses: number;
  up_win_rate: number;
  down_signals: number;
  down_wins: number;
  down_losses: number;
  down_win_rate: number;
  btc_signals?: number;
  eth_signals?: number;
}

export interface SignalRecord extends Omit<Partial<SignalOrder>, 'direction'> {
  id: string;
  timestamp: number;
  symbol: SymbolType;
  duration?: DurationType;
  direction: SignalDirection;
  signalLevel?: SignalLevel;
  referencePrice: number; // Entry Price Index P0
  upProb: number;
  downProb: number;
  waitProb: number;
  breakEvenProb?: number;
  edge?: number;
  expectedValue?: number | null;
  payoutRatio?: number;
  confidence?: number;
  score?: number;
  regime?: MarketRegime;
  settlementTime: number;
  settlementPrice: number | null; // Expiry Price Index P10
  priceChange: number | null;
  outcome: 'WIN' | 'LOSS' | 'FLAT' | 'UP_WIN' | 'DOWN_WIN' | 'PENDING' | 'WAIT_SKIPPED';
  profit_loss?: number | null;
  pnl?: number | null;
  factorsSummary?: string;
  marketSnapshotAtSignal?: {
    ofi: number;
    cvd: number;
    depthImbalance: number;
    rsi: number;
    atr: number;
    spread: number;
    regime: string;
  };
}

export interface DailyRiskStatus {
  dailyMaxRisk: number; // Default 10,000 USDT
  todayUsedRisk: number; // Realized losses today + active open stakes
  remainingRisk: number; // dailyMaxRisk - todayUsedRisk
  activePendingStakes: number;
  isCoolingOff: boolean;
  coolingOffUntil: number | null;
  totalCumulativeLoss: number;
}

export interface MarketSnapshot {
  symbol: SymbolType;
  price: number;
  markPrice: number;
  indexPrice?: number; // Official Binance Price Index
  high24h: number;
  low24h: number;
  volume24h: number;
  priceChange24h: number;
  priceChangePercent24h: number;
  orderBook: OrderBookData;
  recentKlines: KlineData[];
  cvdHistory: { time: number; cvd: number }[];
  currentCvd: number;
  cvdSlope?: number;
  cvd5mChange?: number;
  rawOfi?: number;
  openInterest: number;
  fundingRate: number;
  nextFundingTime: number;
  longShortRatio: number | null;
  prediction: PredictionResult;
  predictions?: Record<DurationType, PredictionResult>;
  currentRound: EventContractRound;
  indicators: TechnicalIndicators;
  microstructure: TradeMicrostructure;
  multiTimeframe: MultiTimeframeAnalysis;
  recentTrades?: { time: number; qty: number; price: number; isBuyerMaker: boolean }[];
  latencyMs: number;
  lastUpdated: number;
  isRealData: boolean;
}

export interface BacktestParams {
  symbol: SymbolType;
  duration?: DurationType;
  days: number;
  threshold: number;
  stakePerTrade: number;
  payoutRatio: number;
  strikeBuffer?: number;
  ofiWeight: number;
  cvdWeight: number;
  depthWeight: number;
  momentumWeight: number;
  multiTfWeight?: number;
  requireTrendAlignment?: boolean;
  requirePositiveEv?: boolean;
}

export interface BacktestTrade {
  time: number;
  symbol: SymbolType;
  duration?: DurationType;
  direction: 'UP' | 'DOWN';
  score: number;
  entryPrice: number; // Entry Price Index
  exitPrice: number; // Expiry Price Index
  outcome: 'UP_WIN' | 'DOWN_WIN' | 'WIN' | 'LOSS';
  stake: number;
  pnl: number;
  cumProfit: number;
  upProb: number;
  downProb: number;
  confidence?: number;
  regime?: string;
  edge?: number;
  ev?: number;
}

export interface BacktestResult {
  params: BacktestParams;
  totalSignals: number;
  totalTrades: number;
  waitCount: number;
  wins: number;
  losses: number;
  ties: number;
  winRate: number;
  totalProfit: number;
  roi: number;
  maxDrawdown: number;
  profitFactor: number;
  sharpeRatio: number;
  maxConsecutiveWins?: number;
  maxConsecutiveLosses?: number;
  trades: BacktestTrade[];
  equityCurve: { time: number; equity: number }[];
}

export interface ModelExamSplit {
  splitName: string;
  timeRange: string;
  tradesCount: number;
  upCount: number;
  downCount: number;
  waitCount: number;
  winRate: number;
  precision: number;
  recall: number;
  profitFactor: number;
  netPnl: number;
}

export interface ModelExamResult {
  symbol: SymbolType;
  duration?: DurationType;
  testedAt: number;
  totalBarsEvaluated: number;
  totalPredictions: number;
  upCount: number;
  downCount: number;
  waitCount: number;
  waitPercentage: number;
  activeTrades: number;
  wins: number;
  losses: number;
  ties: number;
  upWinRate: number;
  downWinRate: number;
  overallWinRate: number;
  precision: number;
  recall: number;
  avgEdge: number;
  avgEv: number;
  maxConsecutiveLosses: number;
  maxDrawdown: number;
  profitFactor: number;
  sharpeRatio: number;
  equityCurve: { time: number; equity: number }[];
  splits: ModelExamSplit[];
  passedAudit: boolean;
  auditNotes: string[];
}

export interface DiagnosticConditionItem {
  id: string;
  name: string;
  passed: boolean;
  value: string | number;
  threshold: string;
  detail: string;
}

export interface CandidateSignalDiagnostic {
  symbol: SymbolType;
  duration: DurationType;
  timestamp: number;
  direction: 'UP' | 'DOWN' | 'WAIT';
  candidateDirection: 'UP' | 'DOWN';
  rawUpProb: number;
  rawDownProb: number;
  upProb: number;
  downProb: number;
  waitProb: number;
  compositeScore: number;
  edge: number;
  expectedValue: number;
  isQualified: boolean;
  rejectionReasons: string[];
  confirmations: string[];
  conditions: DiagnosticConditionItem[];
}

export interface DataFeedHealthItem {
  name: string;
  status: 'OK' | 'ERROR' | 'WARNING';
  latencyMs?: number;
  message: string;
  value?: string | number;
  lastUpdated: number;
}

export interface DataFeedHealthStatus {
  binanceTicker: boolean;
  binanceTickerLatencyMs: number;
  klines: boolean;
  klinesCount: number;
  orderBook: boolean;
  orderBookDepth: number;
  cvd: boolean;
  cvdValue: number;
  ofi: boolean;
  ofiValue: number;
  openInterest: boolean;
  oiValue: number;
  funding: boolean;
  fundingRate: number;
  lastUpdated: number;
  allOk: boolean;
  errorMessages: string[];
  items: DataFeedHealthItem[];
}

export interface DiagnosticStats100 {
  totalEvaluations: number;
  modelProbPassed: number;
  multiTfPassed: number;
  cvdPassed: number;
  ofiPassed: number;
  orderBookPassed: number;
  oiPassed: number;
  volatilityPassed: number;
  evPassed: number;
  formalOrdersCreated: number;
  recentLogs: Array<{
    id: string;
    timestamp: number;
    symbol: SymbolType;
    duration: DurationType;
    direction: 'UP' | 'DOWN' | 'WAIT';
    candidateDirection: 'UP' | 'DOWN';
    upProb: number;
    downProb: number;
    waitProb: number;
    compositeScore: number;
    passedConditions: number;
    totalConditions: number;
    isFormalSignal: boolean;
    mainRejectReason?: string;
  }>;
}

export interface FullDiagnosticsPayload {
  timestamp: number;
  candidates: Record<SymbolType, Record<DurationType, CandidateSignalDiagnostic>>;
  dataHealth: Record<SymbolType, DataFeedHealthStatus>;
  stats100: DiagnosticStats100;
  opportunityPool?: OpportunityPoolResult;
}

export interface OpportunityCandidate {
  id: string;
  symbol: SymbolType;
  duration: DurationType;
  direction: SignalDirection; // 'UP' | 'DOWN' | 'WAIT'
  candidateDirection: 'UP' | 'DOWN';
  status: 'OPEN' | 'WAIT' | 'FILTERED' | 'CONFIRMING';
  regime: EnhancedMarketRegime;
  regimeLabel: string;
  rawProbability: number;
  calibratedProbability: number;
  marketProbability: number;
  edge: number;
  expectedValue: number;
  signalScore: number;
  strengthLevel: SignalStrengthLevel;
  rank: number;
  timeframeRole: string;
  historicalSampleCount: number;
  historicalWinRate: number | null;
  historicalConfidence: 'HIGH' | 'MEDIUM' | 'LOW' | 'INSUFFICIENT';
  isOverextended: boolean;
  filterReason?: string;
  rejectionReasons: string[];
  keyFactors: string[];
  riskNotes: string[];
  timestamp: number;
}

export interface OpportunityPoolResult {
  timestamp: number;
  regimes: Record<SymbolType, { regime: EnhancedMarketRegime; label: string; details: string }>;
  btcEthCorrelation: number; // Pearson correlation between BTC and ETH (-1 to +1)
  candidates: OpportunityCandidate[];
  rankedOpportunities: OpportunityCandidate[];
  bestOpportunity: OpportunityCandidate | null;
  secondOpportunity: OpportunityCandidate | null;
  qualifiedSignalsToOpen: OpportunityCandidate[];
  marketStatusSummary: string;
}

// 5-Dimensional Metrics Isolation (严格指标隔离)
export interface IsolatedMetricsData {
  symbol: SymbolType;
  duration: DurationType;
  // 1. 当前模型预测概率 (Model Forecast)
  currentModelProb: number;
  currentCalibratedProb: number;
  // 2. 历史方向代理回测命中率 (Proxy Backtest Win Rate)
  proxyBacktestWinRate: number;
  proxyBacktestSampleCount: number;
  // 3. 模拟订单盈利率 (Paper Trading Win Rate)
  paperTradingWinRate: number;
  paperTradingOrdersCount: number;
  // 4. 真实事件合约盈利率 (Real Event Contract Win Rate)
  realEventContractWinRate: number;
  realEventContractCount: number;
  // 5. Brier Score 及其样本量 (Brier Score & Sample Count)
  brierScore: number;
  brierSampleCount: number;
  brierQuality: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR';
  // 状态评估
  edge: number;
  expectedValue: number;
  updatedAt: number;
}

// Continuous Learning Loop State (持续学习闭环)
export interface ContinuousLearningState {
  modelVersion: string;
  activeModelTrainedAt: number;
  totalHistoricalSnapshots: number;
  analyzedErrorsCount: number;
  recentFalsePositives: number;
  recentFalseNegatives: number;
  walkForwardValidation: {
    trainWinRate: number;
    validationWinRate: number;
    outOfSampleTestWinRate: number;
    isOverfitted: boolean;
    sharpeRatio: number;
    passedVerification: boolean;
  };
  dataDriftStatus: {
    isDriftDetected: boolean;
    driftScore: number; // 0 to 1
    driftFeatures: string[];
    recommendRetrain: boolean;
  };
  candidateModel: {
    version: string;
    status: 'IDLE' | 'TRAINING' | 'VALIDATED' | 'REJECTED';
    candidateBrierScore?: number;
    candidateWinRate?: number;
    comparisonResult?: string;
  } | null;
  lastRetrainAt?: number;
}



