import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Guard against asynchronous RAF paint events on disposed canvas bindings
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    if (event.message && event.message.includes('Object is disposed')) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  });
  window.addEventListener('unhandledrejection', (event) => {
    if (event.reason && String(event.reason).includes('Object is disposed')) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  });
}

createRoot(document.getElementById('root')!).render(<App />);
