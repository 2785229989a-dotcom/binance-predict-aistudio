import WebSocket from 'ws';
import {
  KlineData,
  MarketSnapshot,
  MultiTimeframeAnalysis,
  OrderBookData,
  OrderBookEntry,
  SymbolType,
  TechnicalIndicators,
  TimeframeTrendInfo,
  TradeMicrostructure,
} from '../types/market.js';
import { computePrediction, computeAllDurationPredictions } from './prediction.js';

interface RecentTrade {
  time: number;
  qty: number;
  price: number;
  isBuyerMaker: boolean; // true = sell, false = buy
}

interface SymbolState {
  symbol: SymbolType;
  price: number;
  markPrice: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  priceChange24h: number;
  priceChangePercent24h: number;
  orderBook: OrderBookData;
  prevBestBid: { price: number; qty: number } | null;
  prevBestAsk: { price: number; qty: number } | null;
  rawOfiAccumulator: number;
  ofiWindow: { time: number; ofi: number }[];
  currentCvd: number;
  cvdHistory: { time: number; cvd: number }[];
  klines: KlineData[]; // 1m klines
  klines5m: KlineData[];
  klines15m: KlineData[];
  openInterest: number;
  oiChange24h: number;
  fundingRate: number;
  nextFundingTime: number;
  longShortRatio: number | null;
  recentTrades: RecentTrade[];
  latencyMs: number;
  lastUpdate: number;
  isRealData: boolean;
}

export class BinanceManager {
  private states: Map<SymbolType, SymbolState> = new Map();
  private ws: WebSocket | null = null;
  private isConnecting: boolean = false;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private restPollTimer: NodeJS.Timeout | null = null;

  constructor() {
    this.initState('BTCUSDT', 88500);
    this.initState('ETHUSDT', 2950);
  }

  private initState(symbol: SymbolType, defaultPrice: number) {
    this.states.set(symbol, {
      symbol,
      price: defaultPrice,
      markPrice: defaultPrice,
      high24h: defaultPrice * 1.02,
      low24h: defaultPrice * 0.98,
      volume24h: symbol === 'BTCUSDT' ? 45000 : 320000,
      priceChange24h: defaultPrice * 0.005,
      priceChangePercent24h: 0.5,
      orderBook: {
        bids: [],
        asks: [],
        spread: 0.1,
        spreadPercent: 0.0001,
        bidTotal: 0,
        askTotal: 0,
        imbalanceRatio: 0.5,
      },
      prevBestBid: null,
      prevBestAsk: null,
      rawOfiAccumulator: 0,
      ofiWindow: [],
      currentCvd: 0,
      cvdHistory: [],
      klines: [],
      klines5m: [],
      klines15m: [],
      openInterest: 0,
      oiChange24h: 0,
      fundingRate: 0.0001,
      nextFundingTime: Date.now() + 3600000 * 4,
      longShortRatio: 1.0,
      recentTrades: [],
      latencyMs: 40,
      lastUpdate: Date.now(),
      isRealData: false,
    });
  }

  public async start() {
    console.log('[BinanceManager] 正在初始化币安真实高频行情接入...');
    // Initial fetch via REST for immediate bootstrapping
    await Promise.all([
      this.fetchRestBootstrap('BTCUSDT'),
      this.fetchRestBootstrap('ETHUSDT'),
    ]);

    this.fetchFundingAndOi('BTCUSDT');
    this.fetchFundingAndOi('ETHUSDT');
    this.fetchLongShortRatio('BTCUSDT');
    this.fetchLongShortRatio('ETHUSDT');

    // Connect WebSocket
    this.connectWs();

    // Periodic polling for derivative statistics (OI, Funding Rate, Long/Short ratio)
    this.restPollTimer = setInterval(() => {
      this.fetchFundingAndOi('BTCUSDT');
      this.fetchFundingAndOi('ETHUSDT');
      this.fetchLongShortRatio('BTCUSDT');
      this.fetchLongShortRatio('ETHUSDT');
    }, 15000);
  }

  private connectWs() {
    if (this.isConnecting || this.ws) return;
    this.isConnecting = true;

    const streams = [
      'btcusdt@aggTrade',
      'btcusdt@depth20@100ms',
      'btcusdt@kline_1m',
      'btcusdt@ticker',
      'ethusdt@aggTrade',
      'ethusdt@depth20@100ms',
      'ethusdt@kline_1m',
      'ethusdt@ticker',
    ].join('/');

    const wsUrl = `wss://stream.binance.com:9443/stream?streams=${streams}`;
    console.log(`[BinanceManager] 连接币安官方 WebSocket 流: ${wsUrl}`);

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.on('open', () => {
        console.log('[BinanceManager] 币安官方 WebSocket 实时流连接成功！');
        this.isConnecting = false;
      });

      this.ws.on('message', (data: WebSocket.RawData) => {
        try {
          const msg = JSON.parse(data.toString());
          this.handleWsMessage(msg);
        } catch (err) {
          // ignore parsing error
        }
      });

      this.ws.on('error', (err) => {
        console.warn('[BinanceManager] WebSocket 异常，准备故障自愈恢复:', err.message);
      });

      this.ws.on('close', () => {
        console.log('[BinanceManager] WebSocket 连接中断，3秒后自动重连...');
        this.ws = null;
        this.isConnecting = false;
        if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => this.connectWs(), 3000);
      });
    } catch (err) {
      console.warn('[BinanceManager] 无法建立 WebSocket 连接:', err);
      this.isConnecting = false;
      if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
      this.reconnectTimer = setTimeout(() => this.connectWs(), 5000);
    }
  }

  private handleWsMessage(payload: any) {
    if (!payload || !payload.stream || !payload.data) return;
    const stream = payload.stream;
    const data = payload.data;

    const symbol: SymbolType = stream.includes('btcusdt') ? 'BTCUSDT' : 'ETHUSDT';
    const state = this.states.get(symbol);
    if (!state) return;

    const now = Date.now();
    state.lastUpdate = now;
    state.isRealData = true;

    // Track latency
    if (data.E) {
      state.latencyMs = Math.max(5, Math.min(2000, now - data.E));
    }

    if (stream.endsWith('@aggTrade')) {
      const tradePrice = parseFloat(data.p);
      const tradeQty = parseFloat(data.q);
      const isBuyerMaker = data.m; // true means sell taker, false means buy taker

      state.price = tradePrice;
      const delta = isBuyerMaker ? -tradeQty : tradeQty;
      state.currentCvd += delta;

      // Add to recent trades buffer
      state.recentTrades.push({
        time: now,
        qty: tradeQty,
        price: tradePrice,
        isBuyerMaker,
      });

      // Keep only trades within last 15 seconds
      state.recentTrades = state.recentTrades.filter((t) => now - t.time <= 15000);

      // CVD History
      state.cvdHistory.push({ time: now, cvd: state.currentCvd });
      if (state.cvdHistory.length > 200) {
        state.cvdHistory.shift();
      }
    } else if (stream.includes('@depth20')) {
      const bidsRaw = data.bids || data.b || [];
      const asksRaw = data.asks || data.a || [];
      this.updateOrderBook(symbol, bidsRaw, asksRaw);
    } else if (stream.endsWith('@kline_1m')) {
      const k = data.k;
      const kline: KlineData = {
        time: k.t,
        open: parseFloat(k.o),
        high: parseFloat(k.h),
        low: parseFloat(k.l),
        close: parseFloat(k.c),
        volume: parseFloat(k.v),
        quoteVolume: parseFloat(k.q),
        buyVolume: parseFloat(k.V),
        sellVolume: parseFloat(k.v) - parseFloat(k.V),
        cvd: state.currentCvd,
      };

      const lastIdx = state.klines.length - 1;
      if (lastIdx >= 0 && state.klines[lastIdx].time === kline.time) {
        state.klines[lastIdx] = kline;
      } else {
        state.klines.push(kline);
        if (state.klines.length > 300) {
          state.klines.shift();
        }
      }
    } else if (stream.endsWith('@ticker')) {
      if (data.h) state.high24h = parseFloat(data.h);
      if (data.l) state.low24h = parseFloat(data.l);
      if (data.v) state.volume24h = parseFloat(data.v);
      if (data.p) state.priceChange24h = parseFloat(data.p);
      if (data.P) state.priceChangePercent24h = parseFloat(data.P);
      if (data.c) state.price = parseFloat(data.c);
    }
  }

  private updateOrderBook(symbol: SymbolType, bidsRaw: [string, string][], asksRaw: [string, string][]) {
    const state = this.states.get(symbol);
    if (!state) return;

    const bids: OrderBookEntry[] = [];
    const asks: OrderBookEntry[] = [];
    let bidTotal = 0;
    let askTotal = 0;

    for (let i = 0; i < Math.min(20, bidsRaw.length); i++) {
      const price = parseFloat(bidsRaw[i][0]);
      const quantity = parseFloat(bidsRaw[i][1]);
      bidTotal += quantity;
      bids.push({ price, quantity, total: bidTotal });
    }

    for (let i = 0; i < Math.min(20, asksRaw.length); i++) {
      const price = parseFloat(asksRaw[i][0]);
      const quantity = parseFloat(asksRaw[i][1]);
      askTotal += quantity;
      asks.push({ price, quantity, total: askTotal });
    }

    if (bids.length > 0 && asks.length > 0) {
      const bestBid = bids[0];
      const bestAsk = asks[0];

      // Calculate Order Flow Imbalance (OFI) based on Cont & Stoikov (2014)
      if (state.prevBestBid && state.prevBestAsk) {
        let ofiDelta = 0;

        // Bid contribution
        if (bestBid.price > state.prevBestBid.price) {
          ofiDelta += bestBid.quantity;
        } else if (bestBid.price === state.prevBestBid.price) {
          ofiDelta += bestBid.quantity - state.prevBestBid.qty;
        } else {
          ofiDelta -= state.prevBestBid.qty;
        }

        // Ask contribution
        if (bestAsk.price < state.prevBestAsk.price) {
          ofiDelta -= bestAsk.quantity;
        } else if (bestAsk.price === state.prevBestAsk.price) {
          ofiDelta -= bestAsk.quantity - state.prevBestAsk.qty;
        } else {
          ofiDelta += state.prevBestAsk.qty;
        }

        state.rawOfiAccumulator += ofiDelta;
        const now = Date.now();
        state.ofiWindow.push({ time: now, ofi: ofiDelta });
        state.ofiWindow = state.ofiWindow.filter((item) => now - item.time < 60000);
      }

      state.prevBestBid = { price: bestBid.price, qty: bestBid.quantity };
      state.prevBestAsk = { price: bestAsk.price, qty: bestAsk.quantity };

      const spread = Math.max(0.01, bestAsk.price - bestBid.price);
      const spreadPercent = bestBid.price > 0 ? (spread / bestBid.price) * 100 : 0;
      const sumDepth = bidTotal + askTotal;
      const imbalanceRatio = sumDepth > 0 ? bidTotal / sumDepth : 0.5;

      state.orderBook = {
        bids,
        asks,
        spread: Number(spread.toFixed(2)),
        spreadPercent: Number(spreadPercent.toFixed(4)),
        bidTotal: Number(bidTotal.toFixed(3)),
        askTotal: Number(askTotal.toFixed(3)),
        imbalanceRatio: Number(imbalanceRatio.toFixed(3)),
      };
    }
  }

  public async fetchRestBootstrap(symbol: SymbolType) {
    try {
      const [k1mRes, k5mRes, depthRes] = await Promise.all([
        fetch(`https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=1m&limit=150`).catch(() =>
          fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=1m&limit=150`)
        ),
        fetch(`https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=5m&limit=60`).catch(() =>
          fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=5m&limit=60`)
        ),
        fetch(`https://data-api.binance.vision/api/v3/depth?symbol=${symbol}&limit=20`).catch(() =>
          fetch(`https://api.binance.com/api/v3/depth?symbol=${symbol}&limit=20`)
        ),
      ]);

      const state = this.states.get(symbol);
      if (!state) return;

      if (k1mRes.ok) {
        const raw1m = await k1mRes.json();
        if (Array.isArray(raw1m)) {
          let cumCvd = 0;
          state.klines = raw1m.map((k: any) => {
            const vol = parseFloat(k[5]);
            const buyVol = parseFloat(k[9]);
            cumCvd += buyVol - (vol - buyVol);
            return {
              time: k[0],
              open: parseFloat(k[1]),
              high: parseFloat(k[2]),
              low: parseFloat(k[3]),
              close: parseFloat(k[4]),
              volume: vol,
              quoteVolume: parseFloat(k[7]),
              buyVolume: buyVol,
              sellVolume: vol - buyVol,
              cvd: cumCvd,
            };
          });
          if (state.klines.length > 0) {
            state.price = state.klines[state.klines.length - 1].close;
            state.currentCvd = cumCvd;
            state.isRealData = true;
          }
        }
      }

      if (k5mRes.ok) {
        const raw5m = await k5mRes.json();
        if (Array.isArray(raw5m)) {
          state.klines5m = raw5m.map((k: any) => ({
            time: k[0],
            open: parseFloat(k[1]),
            high: parseFloat(k[2]),
            low: parseFloat(k[3]),
            close: parseFloat(k[4]),
            volume: parseFloat(k[5]),
            quoteVolume: parseFloat(k[7]),
            buyVolume: parseFloat(k[9]),
            sellVolume: parseFloat(k[5]) - parseFloat(k[9]),
            cvd: 0,
          }));
        }
      }

      if (depthRes.ok) {
        const depthData = await depthRes.json();
        this.updateOrderBook(symbol, depthData.bids || [], depthData.asks || []);
      }
    } catch (err: any) {
      console.warn(`[BinanceManager] REST 启动快照获取失败 (${symbol}): ${err.message}`);
    }
  }

  private async fetchFundingAndOi(symbol: SymbolType) {
    try {
      const [oiRes, fundingRes] = await Promise.all([
        fetch(`https://fapi.binance.com/fapi/v1/openInterest?symbol=${symbol}`),
        fetch(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${symbol}`),
      ]);

      const state = this.states.get(symbol);
      if (!state) return;

      if (oiRes.ok) {
        const oiData = await oiRes.json();
        if (oiData.openInterest) {
          state.openInterest = parseFloat(oiData.openInterest);
        }
      }

      if (fundingRes.ok) {
        const fundingData = await fundingRes.json();
        if (fundingData.lastFundingRate) {
          state.fundingRate = parseFloat(fundingData.lastFundingRate);
        }
        if (fundingData.markPrice) {
          state.markPrice = parseFloat(fundingData.markPrice);
        }
        if (fundingData.nextFundingTime) {
          state.nextFundingTime = fundingData.nextFundingTime;
        }
      }
    } catch (err: any) {
      // Graceful fallback
    }
  }

  private async fetchLongShortRatio(symbol: SymbolType) {
    try {
      const res = await fetch(
        `https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=5m&limit=1`
      );
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0 && data[0].longShortRatio) {
          const state = this.states.get(symbol);
          if (state) {
            state.longShortRatio = parseFloat(data[0].longShortRatio);
          }
        }
      }
    } catch (err) {
      // Graceful degradation
    }
  }

  // Aggregate 1m klines into multi-period klines (3m, 5m, 15m, 30m, 1h)
  private aggregateKlines(klines1m: KlineData[], minutes: number): KlineData[] {
    if (klines1m.length === 0) return [];
    const result: KlineData[] = [];
    const intervalMs = minutes * 60 * 1000;

    let bucket: KlineData[] = [];
    let currentBucketTime = Math.floor(klines1m[0].time / intervalMs) * intervalMs;

    for (const k of klines1m) {
      const bTime = Math.floor(k.time / intervalMs) * intervalMs;
      if (bTime === currentBucketTime) {
        bucket.push(k);
      } else {
        if (bucket.length > 0) {
          result.push(this.mergeBar(bucket, currentBucketTime));
        }
        bucket = [k];
        currentBucketTime = bTime;
      }
    }

    if (bucket.length > 0) {
      result.push(this.mergeBar(bucket, currentBucketTime));
    }

    return result;
  }

  private mergeBar(bars: KlineData[], time: number): KlineData {
    const open = bars[0].open;
    const close = bars[bars.length - 1].close;
    const high = Math.max(...bars.map((b) => b.high));
    const low = Math.min(...bars.map((b) => b.low));
    const volume = bars.reduce((acc, b) => acc + b.volume, 0);
    const quoteVolume = bars.reduce((acc, b) => acc + b.quoteVolume, 0);
    const buyVolume = bars.reduce((acc, b) => acc + b.buyVolume, 0);
    const sellVolume = bars.reduce((acc, b) => acc + b.sellVolume, 0);
    const cvd = bars[bars.length - 1].cvd;

    return { time, open, high, low, close, volume, quoteVolume, buyVolume, sellVolume, cvd };
  }

  // Calculate full technical indicator suite
  public calculateIndicators(klines: KlineData[]): TechnicalIndicators {
    const closes = klines.map((k) => k.close);
    const lastPrice = closes[closes.length - 1] || 1;

    if (closes.length < 20) {
      return {
        ema7: lastPrice,
        ema20: lastPrice,
        ema50: lastPrice,
        rsi: 50,
        atr14: lastPrice * 0.002,
        volatilityPercent: 0.2,
        bollinger: {
          upper: lastPrice * 1.002,
          middle: lastPrice,
          lower: lastPrice * 0.998,
          bandwidth: 0.4,
        },
        macd: { macd: 0, signal: 0, histogram: 0 },
      };
    }

    // EMA(7), EMA(20), EMA(50)
    const ema7 = this.calcEMA(closes, 7);
    const ema20 = this.calcEMA(closes, 20);
    const ema50 = this.calcEMA(closes, Math.min(50, closes.length));

    // RSI(14)
    let gains = 0;
    let losses = 0;
    for (let i = closes.length - 14; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff > 0) gains += diff;
      else losses -= diff;
    }
    const rs = losses === 0 ? 100 : (gains / 14) / (losses / 14 || 0.001);
    const rsi = 100 - 100 / (1 + rs);

    // ATR(14)
    let trSum = 0;
    for (let i = klines.length - 14; i < klines.length; i++) {
      const current = klines[i];
      const prevClose = klines[i - 1]?.close || current.open;
      const tr = Math.max(
        current.high - current.low,
        Math.abs(current.high - prevClose),
        Math.abs(current.low - prevClose)
      );
      trSum += tr;
    }
    const atr14 = trSum / 14;
    const volatilityPercent = lastPrice > 0 ? (atr14 / lastPrice) * 100 : 0.2;

    // Bollinger Bands (20, 2)
    const slice20 = closes.slice(-20);
    const sma20 = slice20.reduce((a, b) => a + b, 0) / 20;
    const variance = slice20.reduce((acc, c) => acc + Math.pow(c - sma20, 2), 0) / 20;
    const stdDev = Math.sqrt(variance);
    const upper = sma20 + 2 * stdDev;
    const lower = sma20 - 2 * stdDev;
    const bandwidth = sma20 > 0 ? ((upper - lower) / sma20) * 100 : 0.4;

    // MACD (12, 26, 9)
    const ema12 = this.calcEMA(closes, 12);
    const ema26 = this.calcEMA(closes, 26);
    const macdLine = ema12 - ema26;
    const macdSignal = macdLine * 0.2; // approx smooth
    const macdHistogram = macdLine - macdSignal;

    return {
      ema7: Number(ema7.toFixed(2)),
      ema20: Number(ema20.toFixed(2)),
      ema50: Number(ema50.toFixed(2)),
      rsi: Number(rsi.toFixed(1)),
      atr14: Number(atr14.toFixed(2)),
      volatilityPercent: Number(volatilityPercent.toFixed(3)),
      bollinger: {
        upper: Number(upper.toFixed(2)),
        middle: Number(sma20.toFixed(2)),
        lower: Number(lower.toFixed(2)),
        bandwidth: Number(bandwidth.toFixed(3)),
      },
      macd: {
        macd: Number(macdLine.toFixed(2)),
        signal: Number(macdSignal.toFixed(2)),
        histogram: Number(macdHistogram.toFixed(2)),
      },
    };
  }

  private calcEMA(prices: number[], period: number): number {
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
      ema = prices[i] * k + ema * (1 - k);
    }
    return ema;
  }

  // Analyze multi-timeframe trends (1m, 3m, 5m, 15m, 30m, 1h)
  public analyzeMultiTimeframe(klines1m: KlineData[]): MultiTimeframeAnalysis {
    const tfs: Array<{ tf: '1m' | '3m' | '5m' | '15m' | '30m' | '1h'; mins: number; weight: number }> = [
      { tf: '1m', mins: 1, weight: 0.15 },
      { tf: '3m', mins: 3, weight: 0.15 },
      { tf: '5m', mins: 5, weight: 0.25 },
      { tf: '15m', mins: 15, weight: 0.25 },
      { tf: '30m', mins: 30, weight: 0.10 },
      { tf: '1h', mins: 60, weight: 0.10 },
    ];

    const trendResults: TimeframeTrendInfo[] = [];
    let weightedScore = 0;
    let upVotes = 0;
    let downVotes = 0;

    for (const item of tfs) {
      const bars = item.mins === 1 ? klines1m : this.aggregateKlines(klines1m, item.mins);
      const closes = bars.map((b) => b.close);

      if (closes.length < 5) {
        trendResults.push({
          timeframe: item.tf,
          direction: 'NEUTRAL',
          emaDiffPercent: 0,
          rsi: 50,
        });
        continue;
      }

      const emaFast = this.calcEMA(closes, 5);
      const emaSlow = this.calcEMA(closes, Math.min(15, closes.length));
      const diffPercent = emaSlow > 0 ? ((emaFast - emaSlow) / emaSlow) * 100 : 0;

      // Quick RSI
      let g = 0;
      let l = 0;
      const rsiBars = Math.min(10, closes.length - 1);
      for (let i = closes.length - rsiBars; i < closes.length; i++) {
        const d = closes[i] - closes[i - 1];
        if (d > 0) g += d;
        else l -= d;
      }
      const rsi = l === 0 ? 100 : 100 - 100 / (1 + (g / rsiBars) / ((l / rsiBars) || 0.001));

      let direction: 'UP' | 'DOWN' | 'NEUTRAL' = 'NEUTRAL';
      if (diffPercent > 0.02 && rsi >= 48) {
        direction = 'UP';
        upVotes += item.weight;
        weightedScore += 100 * item.weight;
      } else if (diffPercent < -0.02 && rsi <= 52) {
        direction = 'DOWN';
        downVotes += item.weight;
        weightedScore -= 100 * item.weight;
      } else {
        direction = 'NEUTRAL';
      }

      trendResults.push({
        timeframe: item.tf,
        direction,
        emaDiffPercent: Number(diffPercent.toFixed(3)),
        rsi: Number(rsi.toFixed(1)),
      });
    }

    const alignmentScore = Math.round(weightedScore);
    const tf1m = trendResults.find((t) => t.timeframe === '1m')?.direction;
    const tf5m = trendResults.find((t) => t.timeframe === '5m')?.direction;
    const tf15m = trendResults.find((t) => t.timeframe === '15m')?.direction;
    const tf1h = trendResults.find((t) => t.timeframe === '1h')?.direction;

    // Detect severe conflict (e.g. short-term 1m opposes medium-term 15m/1h)
    let hasConflict = false;
    let conflictDescription: string | undefined = undefined;

    if (tf1m === 'UP' && (tf15m === 'DOWN' || tf1h === 'DOWN')) {
      hasConflict = true;
      conflictDescription = '短线(1m)假突破或诱多：15m与1h大周期趋势处于下跌承压状态';
    } else if (tf1m === 'DOWN' && (tf15m === 'UP' || tf1h === 'UP')) {
      hasConflict = true;
      conflictDescription = '短线(1m)急跌诱空：15m与1h大周期均线多头支撑仍强劲';
    } else if (tf1m !== 'NEUTRAL' && tf5m !== 'NEUTRAL' && tf1m !== tf5m) {
      hasConflict = true;
      conflictDescription = '1m与5m级别方向发生互斥冲突，震荡摩擦概率高';
    }

    let alignmentText = '多周期趋势中性';
    if (alignmentScore >= 50) {
      alignmentText = '多周期均线强力共振看涨 (1m/3m/5m/15m 同向多头)';
    } else if (alignmentScore <= -50) {
      alignmentText = '多周期均线强力共振看跌 (1m/3m/5m/15m 同向空头)';
    } else if (hasConflict) {
      alignmentText = conflictDescription || '多周期方向冲突严重';
    }

    return {
      trends: trendResults,
      alignmentScore,
      alignmentText,
      hasConflict,
      conflictDescription,
    };
  }

  // Calculate trade microstructure features
  public calculateMicrostructure(trades: RecentTrade[]): TradeMicrostructure {
    if (trades.length === 0) {
      return {
        tradesPerSecond: 0,
        volumePerSecond: 0,
        takerBuyRatio: 0.5,
        tickDelta: 0,
        speedRating: 'NORMAL',
      };
    }

    const windowSec = 10;
    const totalTrades = trades.length;
    const tradesPerSecond = Number((totalTrades / windowSec).toFixed(1));

    const totalVol = trades.reduce((acc, t) => acc + t.qty, 0);
    const volumePerSecond = Number((totalVol / windowSec).toFixed(2));

    const buyTrades = trades.filter((t) => !t.isBuyerMaker); // Taker buys
    const sellTrades = trades.filter((t) => t.isBuyerMaker); // Taker sells

    const buyVol = buyTrades.reduce((acc, t) => acc + t.qty, 0);
    const takerBuyRatio = totalVol > 0 ? Number((buyVol / totalVol).toFixed(3)) : 0.5;
    const tickDelta = buyTrades.length - sellTrades.length;

    let speedRating: 'HIGH' | 'NORMAL' | 'LOW' = 'NORMAL';
    if (tradesPerSecond > 20) speedRating = 'HIGH';
    else if (tradesPerSecond < 3) speedRating = 'LOW';

    return {
      tradesPerSecond,
      volumePerSecond,
      takerBuyRatio,
      tickDelta,
      speedRating,
    };
  }

  public getSnapshot(symbol: SymbolType, currentRound: any): MarketSnapshot {
    const state = this.states.get(symbol)!;
    const indicators = this.calculateIndicators(state.klines);
    const multiTimeframe = this.analyzeMultiTimeframe(state.klines);
    const microstructure = this.calculateMicrostructure(state.recentTrades);

    // CVD 5m change and slope
    const cvd5mChange =
      state.klines.length >= 5
        ? state.currentCvd - (state.klines[state.klines.length - 5]?.cvd || state.currentCvd)
        : 0;
    const cvdSlope = cvd5mChange / 5;

    // OFI sum over 60s
    const rawOfi = state.ofiWindow.reduce((acc, curr) => acc + curr.ofi, 0);

    // Anchor reference price P0 from active round lock price
    const referencePrice = currentRound?.lockPrice || state.price;

    const predInput = {
      symbol,
      price: state.price,
      referencePrice,
      targetThreshold: 0,
      orderBook: state.orderBook,
      rawOfi,
      cvdSlope,
      cvd5mChange,
      openInterest: state.openInterest,
      oiChange24h: state.oiChange24h,
      priceChangePercent: state.priceChangePercent24h,
      fundingRate: state.fundingRate,
      longShortRatio: state.longShortRatio,
      indicators,
      microstructure,
      multiTimeframe,
      latencyMs: state.latencyMs,
      userOdds: currentRound ? { up: currentRound.upOdds, down: currentRound.downOdds } : undefined,
    };

    const predictions = computeAllDurationPredictions(predInput);
    const prediction = predictions['10m'] || computePrediction(predInput);

    return {
      symbol,
      price: state.price,
      markPrice: state.markPrice || state.price,
      high24h: state.high24h,
      low24h: state.low24h,
      volume24h: state.volume24h,
      priceChange24h: state.priceChange24h,
      priceChangePercent24h: state.priceChangePercent24h,
      orderBook: state.orderBook,
      recentKlines: state.klines.slice(-60),
      cvdHistory: state.cvdHistory.slice(-60),
      currentCvd: state.currentCvd,
      cvdSlope: Number(cvdSlope.toFixed(3)),
      cvd5mChange: Number(cvd5mChange.toFixed(2)),
      rawOfi: Number(rawOfi.toFixed(3)),
      openInterest: state.openInterest,
      fundingRate: state.fundingRate,
      nextFundingTime: state.nextFundingTime,
      longShortRatio: state.longShortRatio,
      prediction,
      predictions,
      currentRound,
      indicators,
      microstructure,
      multiTimeframe,
      recentTrades: state.recentTrades.slice(-20),
      latencyMs: state.latencyMs,
      lastUpdated: state.lastUpdate,
      isRealData: state.isRealData,
    };
  }

  public getBothSnapshots(btcRound: any, ethRound: any): Record<SymbolType, MarketSnapshot> {
    return {
      BTCUSDT: this.getSnapshot('BTCUSDT', btcRound),
      ETHUSDT: this.getSnapshot('ETHUSDT', ethRound),
    };
  }

  public getHistoricalKlines(symbol: SymbolType): KlineData[] {
    return this.states.get(symbol)?.klines || [];
  }

  public getStatus() {
    const btc = this.states.get('BTCUSDT');
    const eth = this.states.get('ETHUSDT');
    return {
      wsConnected: this.ws !== null && this.ws.readyState === WebSocket.OPEN,
      lastUpdate: Math.max(btc?.lastUpdate || 0, eth?.lastUpdate || 0),
      btcPrice: btc?.price || 0,
      ethPrice: eth?.price || 0,
      btcLatencyMs: btc?.latencyMs || 0,
      ethLatencyMs: eth?.latencyMs || 0,
      isRealData: (btc?.isRealData || false) && (eth?.isRealData || false),
    };
  }

  public destroy() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.restPollTimer) clearInterval(this.restPollTimer);
  }
}
