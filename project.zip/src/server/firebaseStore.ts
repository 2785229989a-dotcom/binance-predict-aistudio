import fs from 'fs';
import path from 'path';
import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  Firestore,
  doc,
  getDoc,
  setDoc,
  getDocs,
  collection,
  onSnapshot,
  getDocFromServer,
  query,
  orderBy,
  limit,
  Unsubscribe,
} from 'firebase/firestore';
import { SignalOrder } from '../types/market.js';

interface FirebaseConfig {
  projectId: string;
  appId: string;
  apiKey: string;
  authDomain: string;
  firestoreDatabaseId?: string;
  storageBucket?: string;
  messagingSenderId?: string;
  measurementId?: string;
}

export class FirebaseStoreManager {
  private app?: FirebaseApp;
  private db?: Firestore;
  private config?: FirebaseConfig;
  private isConnected: boolean = false;
  private lastSyncTime: number = 0;
  private unsubscribe?: Unsubscribe;

  constructor() {
    this.init();
  }

  private init() {
    try {
      const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
      if (fs.existsSync(configPath)) {
        const raw = fs.readFileSync(configPath, 'utf-8');
        this.config = JSON.parse(raw);
      }
    } catch (err) {
      console.warn('[FirebaseStore] Failed to read firebase-applet-config.json:', err);
    }

    if (!this.config || !this.config.projectId) {
      console.warn('[FirebaseStore] Firebase config not found or invalid projectId.');
      return;
    }

    try {
      if (getApps().length === 0) {
        this.app = initializeApp({
          apiKey: this.config.apiKey,
          authDomain: this.config.authDomain,
          projectId: this.config.projectId,
          storageBucket: this.config.storageBucket,
          messagingSenderId: this.config.messagingSenderId,
          appId: this.config.appId,
        });
      } else {
        this.app = getApps()[0];
      }

      const dbId = this.config.firestoreDatabaseId || '(default)';
      this.db = dbId && dbId !== '(default)'
        ? getFirestore(this.app, dbId)
        : getFirestore(this.app);

      console.log(`[FirebaseStore] Firestore 连接实例初始化就绪 (Project: ${this.config.projectId}, DB: ${dbId})`);
    } catch (err) {
      console.warn('[FirebaseStore] Firebase init error:', err);
    }
  }

  public async testConnection(): Promise<boolean> {
    if (!this.db) return false;
    try {
      // Test server connection via connection check doc
      const testDocRef = doc(this.db, 'metadata', 'connection_test');
      await setDoc(testDocRef, {
        lastConnected: Date.now(),
        service: 'binance-10m-event-contract-workbench',
      }, { merge: true });
      this.isConnected = true;
      console.log('[FirebaseStore] ✔ Firestore 云数据库连接写入验证成功 (Real Persistent Cloud DB Connected)');
      return true;
    } catch (err: any) {
      console.warn('[FirebaseStore] Firestore connection test failed (will fallback to local SQLite):', err?.message || err);
      this.isConnected = false;
      return false;
    }
  }

  public async saveSignal(order: SignalOrder): Promise<void> {
    const id = order?.signalId || order?.id;
    if (!this.db || !order || !id) return;
    try {
      const docRef = doc(this.db, 'signal_orders', id);
      // Clean undefined fields for Firestore compatibility
      const sanitized = JSON.parse(JSON.stringify(order));
      await setDoc(docRef, sanitized, { merge: true });
      this.lastSyncTime = Date.now();
    } catch (err: any) {
      console.warn(`[FirebaseStore] Error saving signal ${id}:`, err?.message || err);
    }
  }

  public async loadAllSignals(): Promise<SignalOrder[]> {
    if (!this.db) return [];
    try {
      const colRef = collection(this.db, 'signal_orders');
      const q = query(colRef, limit(500));
      const snapshot = await getDocs(q);
      const orders: SignalOrder[] = [];
      snapshot.forEach((d) => {
        const data = d.data() as SignalOrder;
        if (data && (data.signalId || data.id)) {
          orders.push(data);
        }
      });
      // Sort chronologically
      orders.sort((a, b) => {
        const timeA = a.signalTime || a.timestamp || 0;
        const timeB = b.signalTime || b.timestamp || 0;
        return timeA - timeB;
      });
      this.lastSyncTime = Date.now();
      return orders;
    } catch (err: any) {
      console.warn('[FirebaseStore] Error loading all signals:', err?.message || err);
      return [];
    }
  }

  public subscribeToSignals(callback: (signals: SignalOrder[]) => void): void {
    if (!this.db) return;
    try {
      if (this.unsubscribe) {
        this.unsubscribe();
      }
      const colRef = collection(this.db, 'signal_orders');
      this.unsubscribe = onSnapshot(
        colRef,
        (snapshot) => {
          const changedSignals: SignalOrder[] = [];
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added' || change.type === 'modified') {
              const data = change.doc.data() as SignalOrder;
              if (data && (data.signalId || data.id)) {
                changedSignals.push(data);
              }
            }
          });
          if (changedSignals.length > 0) {
            callback(changedSignals);
          }
        },
        (err) => {
          console.warn('[FirebaseStore] Firestore snapshot subscription notice:', err.message);
        }
      );
    } catch (err: any) {
      console.warn('[FirebaseStore] subscribeToSignals error:', err?.message || err);
    }
  }

  public async saveDailyStats(stats: any): Promise<void> {
    if (!this.db || !stats) return;
    try {
      const dateKey = stats.date || new Date().toISOString().split('T')[0];
      const docRef = doc(this.db, 'daily_stats', dateKey);
      await setDoc(docRef, JSON.parse(JSON.stringify(stats)), { merge: true });
    } catch (err: any) {
      console.warn('[FirebaseStore] Error saving daily stats:', err?.message || err);
    }
  }

  public getStatus() {
    return {
      isConnected: this.isConnected,
      projectId: this.config?.projectId || '',
      databaseId: this.config?.firestoreDatabaseId || '(default)',
      lastSyncTime: this.lastSyncTime,
    };
  }
}

export const firestoreManager = new FirebaseStoreManager();
