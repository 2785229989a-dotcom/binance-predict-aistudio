import {
  CandidateSignalDiagnostic,
  DataFeedHealthItem,
  DataFeedHealthStatus,
  DiagnosticConditionItem,
  DiagnosticStats100,
  DurationType,
  FullDiagnosticsPayload,
  MarketSnapshot,
  OpportunityPoolResult,
  SignalOrder,
  SymbolType,
} from '../types/market.js';

interface AuditLogEntry {
  id: string;
  timestamp: number;
  symbol: SymbolType;
  duration: DurationType;
  direction: 'UP' | 'DOWN' | 'WAIT';
  candidateDirection: 'UP' | 'DOWN';
  upProb: number;
  downProb: number;
  waitProb: number;
  compositeScore: number;
  passedConditions: number;
  totalConditions: number;
  isFormalSignal: boolean;
  mainRejectReason?: string;
}

export class PredictionDiagnosticsManager {
  private rollingEvaluations: Array<{
    timestamp: number;
    symbol: SymbolType;
    duration: DurationType;
    modelProbPassed: boolean;
    multiTfPassed: boolean;
    cvdPassed: boolean;
    ofiPassed: boolean;
    orderBookPassed: boolean;
    oiPassed: boolean;
    volatilityPassed: boolean;
    evPassed: boolean;
    formalOrderCreated: boolean;
  }> = [];

  private auditLogs: AuditLogEntry[] = [];
  private maxHistory = 100;

  /**
   * 检查底层数据源健康状况 (Binance行情、K线、Order Book、CVD、OFI、OI、Funding)
   */
  public checkDataFeedHealth(snapshot: MarketSnapshot): DataFeedHealthStatus {
    const items: DataFeedHealthItem[] = [];
    const errorMessages: string[] = [];
    const now = Date.now();

    // 1. Binance 实时行情与点差
    const tickerOk = snapshot.price > 0 && snapshot.latencyMs < 5000;
    if (tickerOk) {
      items.push({
        name: 'Binance行情',
        status: 'OK',
        latencyMs: snapshot.latencyMs,
        value: `$${snapshot.price.toLocaleString()}`,
        message: `实时价格稳定，延迟 ${snapshot.latencyMs}ms`,
        lastUpdated: snapshot.lastUpdated || now,
      });
    } else {
      errorMessages.push('❌ Binance行情连接异常或延迟超时');
      items.push({
        name: 'Binance行情',
        status: 'ERROR',
        latencyMs: snapshot.latencyMs,
        value: snapshot.price > 0 ? `$${snapshot.price}` : '0',
        message: `行情异常，延迟 ${snapshot.latencyMs}ms`,
        lastUpdated: snapshot.lastUpdated || now,
      });
    }

    // 2. K线
    const klinesCount = snapshot.recentKlines?.length || 0;
    const klinesOk = klinesCount >= 10;
    if (klinesOk) {
      items.push({
        name: 'K线数据',
        status: 'OK',
        value: `${klinesCount} 根`,
        message: `完整获取多周期K线历史 (${klinesCount} 根)`,
        lastUpdated: now,
      });
    } else {
      errorMessages.push('❌ K线数据获取失败或不足');
      items.push({
        name: 'K线数据',
        status: 'ERROR',
        value: `${klinesCount} 根`,
        message: 'K线数量不足，技术指标计算可能失真',
        lastUpdated: now,
      });
    }

    // 3. Order Book L2 买卖盘
    const depthOk =
      snapshot.orderBook &&
      snapshot.orderBook.bids &&
      snapshot.orderBook.bids.length > 0 &&
      snapshot.orderBook.asks &&
      snapshot.orderBook.asks.length > 0;
    const totalDepth = depthOk
      ? Number((snapshot.orderBook.bidTotal + snapshot.orderBook.askTotal).toFixed(2))
      : 0;
    if (depthOk) {
      items.push({
        name: 'Order Book',
        status: 'OK',
        value: `${totalDepth} ${snapshot.symbol === 'BTCUSDT' ? 'BTC' : 'ETH'}`,
        message: `L2前20档盘口深度正常 (点差: ${snapshot.orderBook.spreadPercent}%)`,
        lastUpdated: now,
      });
    } else {
      errorMessages.push('❌ Order Book盘口深度数据获取失败');
      items.push({
        name: 'Order Book',
        status: 'ERROR',
        value: '0',
        message: '盘口买卖列表为空',
        lastUpdated: now,
      });
    }

    // 4. CVD
    const cvdOk =
      snapshot.currentCvd !== undefined &&
      !isNaN(snapshot.currentCvd) &&
      snapshot.cvdHistory &&
      snapshot.cvdHistory.length > 0;
    const cvdVal = snapshot.currentCvd ?? 0;
    if (cvdOk) {
      items.push({
        name: 'CVD主动成交流',
        status: 'OK',
        value: `${cvdVal >= 0 ? '+' : ''}${cvdVal.toFixed(2)}`,
        message: `高频Tick成交累计CVD正常更新 (5m变化: ${(snapshot.cvd5mChange ?? 0).toFixed(2)})`,
        lastUpdated: now,
      });
    } else {
      errorMessages.push('❌ CVD数据获取失败');
      items.push({
        name: 'CVD主动成交流',
        status: 'ERROR',
        value: 'N/A',
        message: 'CVD数据暂未就绪',
        lastUpdated: now,
      });
    }

    // 5. OFI
    const ofiVal = snapshot.rawOfi ?? 0;
    const ofiOk = snapshot.rawOfi !== undefined && !isNaN(snapshot.rawOfi);
    if (ofiOk) {
      items.push({
        name: 'OFI订单流失衡',
        status: 'OK',
        value: `${ofiVal >= 0 ? '+' : ''}${ofiVal.toFixed(3)}`,
        message: `60秒滑动微观盘口OFI订单流失衡正常计算`,
        lastUpdated: now,
      });
    } else {
      errorMessages.push('❌ OFI数据获取失败');
      items.push({
        name: 'OFI订单流失衡',
        status: 'ERROR',
        value: 'N/A',
        message: 'OFI订单流失衡数据未产生',
        lastUpdated: now,
      });
    }

    // 6. OI
    const oiVal = snapshot.openInterest ?? 0;
    const oiOk = oiVal > 0 && !isNaN(oiVal);
    if (oiOk) {
      items.push({
        name: 'OI未平仓合约',
        status: 'OK',
        value: `${Math.round(oiVal).toLocaleString()} 张`,
        message: '币安合约真实全网持仓量正常更新',
        lastUpdated: now,
      });
    } else {
      errorMessages.push('❌ OI数据获取失败');
      items.push({
        name: 'OI未平仓合约',
        status: 'ERROR',
        value: '0',
        message: '未平仓合约数据未返回',
        lastUpdated: now,
      });
    }

    // 7. Funding
    const fundingRate = snapshot.fundingRate ?? 0;
    const fundingOk = snapshot.fundingRate !== undefined && !isNaN(snapshot.fundingRate);
    if (fundingOk) {
      items.push({
        name: 'Funding资金费率',
        status: 'OK',
        value: `${(fundingRate * 100).toFixed(4)}%`,
        message: `资金费率正常 (基准周期 8h)`,
        lastUpdated: now,
      });
    } else {
      errorMessages.push('❌ Funding资金费率获取失败');
      items.push({
        name: 'Funding资金费率',
        status: 'ERROR',
        value: 'N/A',
        message: '资金费率数据缺失',
        lastUpdated: now,
      });
    }

    const allOk = errorMessages.length === 0;

    return {
      binanceTicker: tickerOk,
      binanceTickerLatencyMs: snapshot.latencyMs,
      klines: klinesOk,
      klinesCount,
      orderBook: depthOk,
      orderBookDepth: totalDepth,
      cvd: cvdOk,
      cvdValue: cvdVal,
      ofi: ofiOk,
      ofiValue: ofiVal,
      openInterest: oiOk,
      oiValue: oiVal,
      funding: fundingOk,
      fundingRate,
      lastUpdated: now,
      allOk,
      errorMessages,
      items,
    };
  }

  /**
   * 针对当前标的与预测周期，执行 14 项全景开单条件核验与诊断
   */
  public evaluateCandidateDiagnostic(
    snapshot: MarketSnapshot,
    duration: DurationType,
    activeOrders: SignalOrder[],
    poolResult?: OpportunityPoolResult
  ): CandidateSignalDiagnostic {
    const pred = snapshot.predictions?.[duration] || snapshot.prediction;
    const now = Date.now();
    const symbol = snapshot.symbol;

    const poolCand = poolResult?.candidates.find(
      (c) => c.symbol === symbol && c.duration === duration
    );

    // 确定候选最高概率方向 (Candidate Direction)
    // 根据多因子评分与概率，探测当前市场的优势倾向
    const rawUp = poolCand?.rawProbability ?? pred?.upProb ?? 50;
    const rawDown = poolCand ? Number((100 - poolCand.rawProbability).toFixed(1)) : (pred?.downProb ?? 50);
    const compScore = poolCand?.signalScore ?? pred?.compositeScore ?? 0;

    const candidateDirection: 'UP' | 'DOWN' = poolCand
      ? poolCand.candidateDirection
      : compScore > 0 ? 'UP' : compScore < 0 ? 'DOWN' : rawUp >= rawDown ? 'UP' : 'DOWN';

    const candidateProb = poolCand
      ? poolCand.calibratedProbability
      : candidateDirection === 'UP' ? rawUp : rawDown;
    const oppositeProb = candidateDirection === 'UP' ? rawDown : rawUp;

    const conditions: DiagnosticConditionItem[] = [];
    const rejectionReasons: string[] = [];
    const confirmations: string[] = [];

    // ================== 14 项开单条件逐项严格核验 ==================

    // 1. 模型概率 (阈值: >= 75.0%)
    const modelProbPassed = candidateProb >= 75.0 && (pred?.waitProb ?? 100) <= 20;
    conditions.push({
      id: 'model_prob',
      name: '模型概率',
      passed: modelProbPassed,
      value: `${candidateProb.toFixed(1)}%`,
      threshold: '>= 75.0% (WAIT <= 20%)',
      detail: modelProbPassed
        ? `模型概率 ${candidateProb.toFixed(1)}% 达到高胜率置信度门槛`
        : `模型概率 ${candidateProb.toFixed(1)}% 低于 75.0% 准入门槛 (不确定性WAIT: ${pred?.waitProb ?? 0}%)`,
    });
    if (!modelProbPassed) {
      rejectionReasons.push(`❌ 模型概率 (${candidateProb.toFixed(1)}%) 未达高置信度门槛 (>=75.0%)`);
    } else {
      confirmations.push(`✓ 模型置信度达标 (${candidateProb.toFixed(1)}%)`);
    }

    // 2. 多周期趋势 (大周期必须无冲突且同向支持)
    const multiTf = snapshot.multiTimeframe;
    const tfScore = multiTf?.alignmentScore ?? 0;
    const hasConflict = multiTf?.hasConflict ?? false;
    const multiTfPassed =
      !hasConflict &&
      ((candidateDirection === 'UP' && tfScore >= 15) || (candidateDirection === 'DOWN' && tfScore <= -15));
    conditions.push({
      id: 'multi_tf',
      name: '多周期趋势',
      passed: multiTfPassed,
      value: `${tfScore >= 0 ? '+' : ''}${tfScore} 分`,
      threshold: candidateDirection === 'UP' ? '共振分 >= +15 且无冲突' : '共振分 <= -15 且无冲突',
      detail: multiTfPassed
        ? `大周期与短周期协同看${candidateDirection === 'UP' ? '涨' : '跌'}，无逆势分歧`
        : hasConflict
        ? `多周期发生方向冲突: ${multiTf?.conflictDescription || '大周期逆风'}`
        : `多周期共振强度不足 (${tfScore} 分未达门槛)`,
    });
    if (!multiTfPassed) {
      rejectionReasons.push(
        hasConflict
          ? `❌ 多周期均线严重冲突 (${multiTf?.conflictDescription || '大周期逆风'})`
          : `❌ 多周期趋势未形成共振确认 (共振得分: ${tfScore}分)`
      );
    } else {
      confirmations.push(`✓ 多周期趋势共振看${candidateDirection === 'UP' ? '多' : '空'}确认`);
    }

    // 3. EMA / MACD
    const ind = snapshot.indicators;
    const emaFast = ind?.ema7 ?? 0;
    const emaSlow = ind?.ema20 ?? 0;
    const macdHist = ind?.macd?.histogram ?? 0;
    const emaMacdPassed =
      candidateDirection === 'UP'
        ? emaFast >= emaSlow || macdHist >= 0
        : emaFast <= emaSlow || macdHist <= 0;
    conditions.push({
      id: 'ema_macd',
      name: 'EMA / MACD',
      passed: emaMacdPassed,
      value: `EMA: ${(emaFast - emaSlow).toFixed(2)}, MACD: ${macdHist.toFixed(2)}`,
      threshold: candidateDirection === 'UP' ? '快线在慢线上方或MACD柱翻红' : '快线在慢线下方或MACD柱翻绿',
      detail: emaMacdPassed ? '均线与动量指标方向一致' : 'EMA/MACD呈现反向压制',
    });
    if (!emaMacdPassed) {
      rejectionReasons.push(`❌ EMA/MACD与开单方向出现背离`);
    }

    // 4. RSI (健康动量区间，杜绝严重超买/超卖假突破)
    const rsi = ind?.rsi ?? 50;
    const rsiPassed =
      candidateDirection === 'UP'
        ? rsi >= 40 && rsi <= 76
        : rsi >= 24 && rsi <= 60;
    conditions.push({
      id: 'rsi',
      name: 'RSI',
      passed: rsiPassed,
      value: `${rsi.toFixed(1)}`,
      threshold: candidateDirection === 'UP' ? '40 <= RSI <= 76' : '24 <= RSI <= 60',
      detail: rsiPassed ? 'RSI 动量位于健康有效启动区间' : `RSI (${rsi.toFixed(1)}) 处于极度超买/超卖危险区`,
    });
    if (!rsiPassed) {
      rejectionReasons.push(`❌ RSI指标处于非安全区间 (${rsi.toFixed(1)})`);
    }

    // 5. CVD (主动买卖吃单流)
    const cvdScore = pred?.factors?.cvd?.score ?? 0;
    const cvdPassed = candidateDirection === 'UP' ? cvdScore >= 10 : cvdScore <= -10;
    conditions.push({
      id: 'cvd',
      name: 'CVD',
      passed: cvdPassed,
      value: `${cvdScore >= 0 ? '+' : ''}${cvdScore} 分`,
      threshold: candidateDirection === 'UP' ? '得分 >= +10' : '得分 <= -10',
      detail: cvdPassed
        ? `主动${candidateDirection === 'UP' ? '买盘吃单突破' : '卖单倾泻下破'}有效`
        : `CVD 主动成交支持力度不足 (得分 ${cvdScore} 分)`,
    });
    if (!cvdPassed) {
      rejectionReasons.push(`❌ CVD主动吃单突破确认不足 (${cvdScore}分)`);
    } else {
      confirmations.push(`✓ CVD主动吃单确认 (${cvdScore > 0 ? '+' : ''}${cvdScore}分)`);
    }

    // 6. OFI (订单流盘口失衡)
    const ofiScore = pred?.factors?.ofi?.score ?? 0;
    const ofiPassed = candidateDirection === 'UP' ? ofiScore >= 10 : ofiScore <= -10;
    conditions.push({
      id: 'ofi',
      name: 'OFI',
      passed: ofiPassed,
      value: `${ofiScore >= 0 ? '+' : ''}${ofiScore} 分`,
      threshold: candidateDirection === 'UP' ? '得分 >= +10' : '得分 <= -10',
      detail: ofiPassed
        ? `L2盘口挂单流动性净${candidateDirection === 'UP' ? '买方注入' : '卖方压迫'}显著`
        : `OFI 盘口挂单失衡未达标 (当前 ${ofiScore} 分)`,
    });
    if (!ofiPassed) {
      rejectionReasons.push(`❌ OFI订单流盘口确认不足 (${ofiScore}分)`);
    } else {
      confirmations.push(`✓ OFI订单流微观盘口共振 (${ofiScore > 0 ? '+' : ''}${ofiScore}分)`);
    }

    // 7. Order Book 买卖盘深度与点差
    const ob = snapshot.orderBook;
    const spreadPct = ob?.spreadPercent ?? 0.01;
    const bidRatio = ob && ob.bidTotal + ob.askTotal > 0 ? ob.bidTotal / (ob.bidTotal + ob.askTotal) : 0.5;
    const obPassed =
      spreadPct <= 0.05 &&
      (candidateDirection === 'UP' ? bidRatio >= 0.46 : bidRatio <= 0.54);
    conditions.push({
      id: 'order_book',
      name: 'Order Book',
      passed: obPassed,
      value: `买方占比 ${(bidRatio * 100).toFixed(1)}%, 点差 ${spreadPct.toFixed(3)}%`,
      threshold: candidateDirection === 'UP' ? '买方占比 >= 46% 且 点差 <= 0.05%' : '卖方占比 >= 46% 且 点差 <= 0.05%',
      detail: obPassed ? '盘口前20档挂单厚度与价差正常' : '盘口深度存在反向压制或点差偏大',
    });
    if (!obPassed) {
      rejectionReasons.push(`❌ Order Book存在反向压力或点差偏大 (${spreadPct.toFixed(3)}%)`);
    }

    // 8. OI (持仓量异动与量价配合)
    const oiVal = snapshot.openInterest ?? 0;
    const oiChange = snapshot.prediction?.factors?.oi?.oiChange24h ?? 0;
    const oiPassed = oiVal > 0 && Math.abs(oiChange) <= 25; // 排除极端爆仓抽离
    conditions.push({
      id: 'oi',
      name: 'OI',
      passed: oiPassed,
      value: `${Math.round(oiVal).toLocaleString()}`,
      threshold: '持仓量平稳且无异常爆仓熔断',
      detail: oiPassed ? '持仓量结构健康' : '持仓量异常波动',
    });
    if (!oiPassed) {
      rejectionReasons.push(`❌ OI持仓量处于异常状态`);
    }

    // 9. Funding Rate 资金费率
    const fundingRate = snapshot.fundingRate ?? 0;
    const fundingPct = fundingRate * 100;
    const fundingPassed =
      candidateDirection === 'UP' ? fundingPct <= 0.035 : fundingPct >= -0.025;
    conditions.push({
      id: 'funding',
      name: 'Funding',
      passed: fundingPassed,
      value: `${fundingPct.toFixed(4)}%`,
      threshold: candidateDirection === 'UP' ? '费率 <= +0.035%' : '费率 >= -0.025%',
      detail: fundingPassed ? '资金费率在正常无过热区间' : '资金费率过热，多空拥挤',
    });
    if (!fundingPassed) {
      rejectionReasons.push(`❌ 资金费率过热 (${fundingPct.toFixed(4)}%)`);
    }

    // 10. 成交量
    const vol24h = snapshot.volume24h ?? 0;
    const volPassed = vol24h > 500;
    conditions.push({
      id: 'volume',
      name: '成交量',
      passed: volPassed,
      value: `${Math.round(vol24h).toLocaleString()}`,
      threshold: '24h 成交活跃量 > 500',
      detail: volPassed ? '成交流动性充裕' : '成交量萎缩',
    });
    if (!volPassed) {
      rejectionReasons.push(`❌ 市场成交量不足`);
    }

    // 11. 市场结构 / 微观结构
    const regime = pred?.regime || 'RANGING';
    const structurePassed = regime !== 'LOW_LIQUIDITY' && regime !== 'DATA_DELAY';
    conditions.push({
      id: 'structure',
      name: '市场结构',
      passed: structurePassed,
      value: pred?.regimeLabel || regime,
      threshold: '非流动性枯竭 / 非延迟保护',
      detail: structurePassed ? '市场微观环境正常' : `市场处于异常保护态: ${regime}`,
    });
    if (!structurePassed) {
      rejectionReasons.push(`❌ 市场处于异常结构保护态 (${regime})`);
    }

    // 12. 波动率 (ATR / 布林带带宽)
    const volaPassed = regime !== 'HIGH_VOLATILITY';
    conditions.push({
      id: 'volatility',
      name: '波动率',
      passed: volaPassed,
      value: volaPassed ? '正常' : '极端异常',
      threshold: '短周期ATR/布林未处于极端洗盘开口',
      detail: volaPassed ? '波动率处于策略安全边际内' : '短周期异常暴涨暴跌，存在插针洗盘风险',
    });
    if (!volaPassed) {
      rejectionReasons.push(`❌ 短周期波动率超标(ATR剧烈开口)，存在假突破洗盘风险`);
    }

    // 13. EV 期望值 (EV > 0 & Edge > 0)
    const ev = pred?.expectedValue ?? 0;
    const edge = pred?.edge ?? 0;
    const evPassed = ev >= 10.0 && edge >= 10.0;
    conditions.push({
      id: 'ev',
      name: 'EV',
      passed: evPassed,
      value: `EV: $${ev.toFixed(2)}, Edge: +${edge.toFixed(2)}%`,
      threshold: 'EV >= +$10.0 且 Edge >= +10.0%',
      detail: evPassed ? '具备显著数学统计优势' : `数学期望值优势未达标 (EV: $${ev.toFixed(2)})`,
    });
    if (!evPassed) {
      rejectionReasons.push(`❌ 理论期望值未达到正期望及格线 (EV: $${ev.toFixed(2)}U, Edge: ${edge.toFixed(2)}%)`);
    } else {
      confirmations.push(`✓ 理论期望值达标 (EV: +$${ev.toFixed(2)}U, Edge: +${edge.toFixed(2)}%)`);
    }

    // 14. 冷却机制 (防抖与重复订单检测)
    const existingSame = activeOrders.find(
      (o) => o.symbol === symbol && o.duration === duration && (o.status === 'ACTIVE' || o.status === 'WAITING_ENTRY')
    );
    // Find newest order for this symbol/duration
    const newestOrder = activeOrders
      .filter((o) => o.symbol === symbol && o.duration === duration)
      .sort((a, b) => b.signalTime - a.signalTime)[0];
    const isCoolingOff = newestOrder ? now - newestOrder.signalTime < 180000 : false;
    const cooldownPassed = !existingSame && !isCoolingOff;
    conditions.push({
      id: 'cooldown',
      name: '冷却机制',
      passed: cooldownPassed,
      value: existingSame ? '有进行中订单' : isCoolingOff ? '冷却防抖中' : '就绪',
      threshold: '同标的同周期无进行中订单且已过3分钟冷却',
      detail: cooldownPassed ? '冷却机制已就绪' : existingSame ? '已有同标的进行中订单' : '距离上笔订单不足3分钟',
    });
    if (!cooldownPassed) {
      rejectionReasons.push(existingSame ? '❌ 当前已有进行中的正式订单' : '❌ 处于3分钟开单冷却防抖期');
    }

    // 15. 信号去重与相关性引擎
    const dedupPassed = poolCand ? poolCand.status !== 'FILTERED' : true;
    conditions.push({
      id: 'dedup_engine',
      name: '去重与相关性',
      passed: dedupPassed,
      value: poolCand
        ? poolCand.status === 'OPEN'
          ? '优先入选'
          : poolCand.status === 'FILTERED'
          ? '已去重抑制'
          : poolCand.status
        : '通过',
      threshold: '无同标的多周期同向冲突且未触发相关性风控',
      detail: poolCand?.filterReason || (dedupPassed ? '通过去重引擎校验' : '被去重引擎过滤'),
    });
    if (poolCand && poolCand.filterReason) {
      rejectionReasons.unshift(`❌ ${poolCand.filterReason}`);
    }

    // 综合判定是否全部条件通过
    const allConditionsPassed = conditions.every((c) => c.passed);
    // 综合评分 (0 - 100)
    const baseScore = poolCand
      ? poolCand.signalScore
      : Math.min(
          100,
          Math.max(
            0,
            Math.round(50 + (candidateProb - 50) * 1.5 + (pred?.edge || 0) * 0.8)
          )
        );

    if (baseScore < 85) {
      rejectionReasons.unshift(`❌ 综合评分 (${baseScore}/100) 低于正式开单基准 (85分)`);
    }

    const isQualified = poolCand
      ? poolCand.status === 'OPEN'
      : allConditionsPassed && baseScore >= 85;

    const finalEdge = poolCand ? poolCand.edge : edge;
    const finalEv = poolCand ? poolCand.expectedValue : ev;

    return {
      symbol,
      duration,
      timestamp: now,
      direction: isQualified ? candidateDirection : 'WAIT',
      candidateDirection,
      rawUpProb: rawUp,
      rawDownProb: rawDown,
      upProb: candidateDirection === 'UP' ? candidateProb : Number((100 - candidateProb).toFixed(1)),
      downProb: candidateDirection === 'DOWN' ? candidateProb : Number((100 - candidateProb).toFixed(1)),
      waitProb: isQualified ? 10 : Math.min(85, Math.max(30, 100 - candidateProb)),
      compositeScore: baseScore,
      edge: finalEdge,
      expectedValue: finalEv,
      isQualified,
      rejectionReasons,
      confirmations,
      conditions,
    };
  }

  /**
   * 记录一次模型预测评估到滑动窗口并统计
   */
  public recordEvaluation(diagnostic: CandidateSignalDiagnostic, isFormalCreated: boolean) {
    const condMap = new Map(diagnostic.conditions.map((c) => [c.id, c.passed]));

    this.rollingEvaluations.push({
      timestamp: diagnostic.timestamp,
      symbol: diagnostic.symbol,
      duration: diagnostic.duration,
      modelProbPassed: condMap.get('model_prob') || false,
      multiTfPassed: condMap.get('multi_tf') || false,
      cvdPassed: condMap.get('cvd') || false,
      ofiPassed: condMap.get('ofi') || false,
      orderBookPassed: condMap.get('order_book') || false,
      oiPassed: condMap.get('oi') || false,
      volatilityPassed: condMap.get('volatility') || false,
      evPassed: condMap.get('ev') || false,
      formalOrderCreated: isFormalCreated,
    });

    if (this.rollingEvaluations.length > this.maxHistory) {
      this.rollingEvaluations.shift();
    }

    // 记录详细审计流水
    const passedCount = diagnostic.conditions.filter((c) => c.passed).length;
    this.auditLogs.unshift({
      id: `${diagnostic.symbol}-${diagnostic.duration}-${diagnostic.timestamp}`,
      timestamp: diagnostic.timestamp,
      symbol: diagnostic.symbol,
      duration: diagnostic.duration,
      direction: diagnostic.direction,
      candidateDirection: diagnostic.candidateDirection,
      upProb: diagnostic.upProb,
      downProb: diagnostic.downProb,
      waitProb: diagnostic.waitProb,
      compositeScore: diagnostic.compositeScore,
      passedConditions: passedCount,
      totalConditions: diagnostic.conditions.length,
      isFormalSignal: isFormalCreated,
      mainRejectReason: diagnostic.rejectionReasons[0],
    });

    if (this.auditLogs.length > 50) {
      this.auditLogs.pop();
    }
  }

  /**
   * 获取最近 100 次预测过滤统计数据
   */
  public getStats100(): DiagnosticStats100 {
    const total = this.rollingEvaluations.length;
    if (total === 0) {
      return {
        totalEvaluations: 0,
        modelProbPassed: 0,
        multiTfPassed: 0,
        cvdPassed: 0,
        ofiPassed: 0,
        orderBookPassed: 0,
        oiPassed: 0,
        volatilityPassed: 0,
        evPassed: 0,
        formalOrdersCreated: 0,
        recentLogs: this.auditLogs.slice(0, 30),
      };
    }

    let modelProb = 0;
    let multiTf = 0;
    let cvd = 0;
    let ofi = 0;
    let orderBook = 0;
    let oi = 0;
    let volatility = 0;
    let ev = 0;
    let formalOrders = 0;

    for (const item of this.rollingEvaluations) {
      if (item.modelProbPassed) modelProb++;
      if (item.multiTfPassed) multiTf++;
      if (item.cvdPassed) cvd++;
      if (item.ofiPassed) ofi++;
      if (item.orderBookPassed) orderBook++;
      if (item.oiPassed) oi++;
      if (item.volatilityPassed) volatility++;
      if (item.evPassed) ev++;
      if (item.formalOrderCreated) formalOrders++;
    }

    return {
      totalEvaluations: total,
      modelProbPassed: modelProb,
      multiTfPassed: multiTf,
      cvdPassed: cvd,
      ofiPassed: ofi,
      orderBookPassed: orderBook,
      oiPassed: oi,
      volatilityPassed: volatility,
      evPassed: ev,
      formalOrdersCreated: formalOrders,
      recentLogs: this.auditLogs.slice(0, 30),
    };
  }
}

export const predictionDiagnostics = new PredictionDiagnosticsManager();
