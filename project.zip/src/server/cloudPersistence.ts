import { SignalOrder } from '../types/market.js';
import { ContractManager } from './contractManager.js';
import { Server as SocketIOServer } from 'socket.io';

export interface CloudSyncStatus {
  isConfigured: boolean;
  activePeerCount: number;
  lastSyncTime: number;
  lastSyncResult: string;
  totalSyncedSignals: number;
  peerUrls: string[];
}

/**
 * 云端与多端中心化数据源同步管理器 (Cross-Environment & Multi-Client Data Hub)
 * 解决开发预览 (ais-dev) 与公共线上链接 (ais-pre) 或不同多端实例之间的环境隔离问题
 */
export class CloudPersistenceManager {
  private contracts: ContractManager;
  private io?: SocketIOServer;
  private peerUrls: string[] = [];
  private lastSyncTime: number = 0;
  private lastSyncResult: string = '尚未开始同步';
  private totalSyncedCount: number = 0;
  private syncInterval?: NodeJS.Timeout;

  constructor(contracts: ContractManager, io?: SocketIOServer) {
    this.contracts = contracts;
    this.io = io;
    this.initPeers();
  }

  public setSocketServer(io: SocketIOServer) {
    this.io = io;
  }

  private initPeers() {
    const candidatePeers: string[] = [];
    if (process.env.PEER_SYNC_URLS) {
      const extra = process.env.PEER_SYNC_URLS.split(',').map((u) => u.trim()).filter(Boolean);
      candidatePeers.push(...extra);
    }
    this.peerUrls = Array.from(new Set(candidatePeers));
  }

  /**
   * 启动后台中心化对等同步轮询（每 8 秒自动拉取对端信号并双向合并）
   */
  public startSyncLoop(intervalMs: number = 8000) {
    if (this.syncInterval) clearInterval(this.syncInterval);

    // 立即执行一次初次同步
    this.syncWithPeers().catch((e) => console.warn('[CloudSync] Initial sync notice:', e.message));

    this.syncInterval = setInterval(() => {
      this.syncWithPeers().catch((e) => console.warn('[CloudSync] Peer sync interval notice:', e.message));
    }, intervalMs);

    console.log(`[CloudSync] 中心化多端同步服务已启动，监听对等节点:`, this.peerUrls);
  }

  public stopSyncLoop() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = undefined;
    }
  }

  /**
   * 与对端环境进行双向全量/增量信号同步
   */
  public async syncWithPeers(): Promise<void> {
    for (const peerUrl of this.peerUrls) {
      try {
        const targetUrl = `${peerUrl.replace(/\/$/, '')}/api/signal-orders`;
        const res = await fetch(targetUrl, {
          headers: { 'User-Agent': 'Workbench-CloudSync/1.0', Accept: 'application/json' },
          signal: AbortSignal.timeout(5000),
        });

        if (res.ok) {
          const contentType = res.headers.get('content-type') || '';
          if (contentType.includes('application/json')) {
            const data = await res.json();
            if (data && Array.isArray(data.orders) && data.orders.length > 0) {
              const { added, updated } = this.contracts.mergeIncomingSignals(data.orders);
              if (added > 0 || updated > 0) {
                this.totalSyncedCount += added + updated;
                this.lastSyncResult = `成功同步来自 ${peerUrl} 的 ${added} 笔新信号, 更新 ${updated} 笔`;
                console.log(`[CloudSync] ${this.lastSyncResult}`);

                // 触发 WebSocket 向全部客户端广播最新状态
                if (this.io) {
                  this.io.emit('signal_orders_entered', this.contracts.getActiveSignalOrders());
                  this.io.emit('signal_stats_updated', this.contracts.getSignalOrderStats());
                  this.io.emit('today_stats_updated', this.contracts.getTodayStats());
                  this.io.emit('daily_archives_updated', this.contracts.getAllDailyArchives());
                }
              } else {
                this.lastSyncResult = `与 ${peerUrl} 保持一致 (共 ${data.orders.length} 笔信号)`;
              }
            }
          }
        }
      } catch (err: any) {
        // 网络超时或证书限制忽略，不阻断主流程
      }
    }
    this.lastSyncTime = Date.now();
  }

  /**
   * 当本机产生新信号时，立即主动推送到对等节点进行广播
   */
  public async broadcastOrderToPeers(order: SignalOrder): Promise<void> {
    for (const peerUrl of this.peerUrls) {
      try {
        const targetUrl = `${peerUrl.replace(/\/$/, '')}/api/signals/sync`;
        await fetch(targetUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orders: [order] }),
          signal: AbortSignal.timeout(3000),
        });
      } catch (e) {
        // 允许静默失败，后续周期轮询仍会补全
      }
    }
  }

  public getStatus(): CloudSyncStatus {
    return {
      isConfigured: true,
      activePeerCount: this.peerUrls.length,
      lastSyncTime: this.lastSyncTime,
      lastSyncResult: this.lastSyncResult,
      totalSyncedSignals: this.totalSyncedCount,
      peerUrls: this.peerUrls,
    };
  }
}
