import path from 'path';
import fs from 'fs';
import { createClient, Client } from '@libsql/client';
import { DailySignalStats, DurationType, SignalOrder, SymbolType } from '../types/market.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'trading.db');
const SIGNAL_ORDERS_FILE = path.join(DATA_DIR, 'signal_orders.json');

/**
 * 获取 Asia/Shanghai (北京时间) 的标准日期字符串 YYYY-MM-DD
 */
export function getShanghaiDateStr(timestamp: number = Date.now()): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(timestamp));
}

/**
 * 获取 Asia/Shanghai (北京时间) 紧凑日期 YYYYMMDD
 */
export function getShanghaiDateCompact(timestamp: number = Date.now()): string {
  return getShanghaiDateStr(timestamp).replace(/-/g, '');
}

/**
 * 获取 Asia/Shanghai (北京时间) 格式化时间 HH:mm:ss
 */
export function getShanghaiTimeStr(timestamp: number = Date.now()): string {
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Shanghai',
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(new Date(timestamp));
}

class SignalDatabase {
  private client: Client;
  private isInitialized = false;

  constructor() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    this.client = createClient({
      url: `file:${DB_PATH}`,
    });
  }

  public async init(): Promise<void> {
    if (this.isInitialized) return;

    await this.client.execute(`
      CREATE TABLE IF NOT EXISTS signals (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        symbol TEXT NOT NULL,
        direction TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        signal_time INTEGER NOT NULL,
        entry_price REAL NOT NULL,
        expiry_time INTEGER NOT NULL,
        expiry_price REAL,
        up_probability REAL NOT NULL,
        down_probability REAL NOT NULL,
        wait_probability REAL NOT NULL,
        confidence_score REAL NOT NULL,
        reasons TEXT,
        market_snapshot TEXT,
        status TEXT NOT NULL,
        result TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        settled_at INTEGER,
        duration_ms INTEGER NOT NULL
      );
    `);

    await this.client.execute(`
      CREATE INDEX IF NOT EXISTS idx_signals_date ON signals(date);
    `);
    await this.client.execute(`
      CREATE INDEX IF NOT EXISTS idx_signals_status ON signals(status);
    `);

    this.isInitialized = true;
  }

  /**
   * 生成当日下一个标准 Signal ID: SIG-YYYYMMDD-XXXX
   */
  public async generateNextSignalId(dateCompact: string): Promise<string> {
    await this.init();
    const dateStr = `${dateCompact.slice(0, 4)}-${dateCompact.slice(4, 6)}-${dateCompact.slice(6, 8)}`;
    const res = await this.client.execute({
      sql: `SELECT COUNT(*) as cnt FROM signals WHERE date = ?`,
      args: [dateStr],
    });
    const count = Number(res.rows[0]?.cnt || 0);
    const seq = count + 1;
    return `SIG-${dateCompact}-${String(seq).padStart(4, '0')}`;
  }

  /**
   * 清零重置所有信号记录
   */
  public async clearAllSignals(): Promise<void> {
    await this.init();
    await this.client.execute('DELETE FROM signals');
  }

  /**
   * 插入或更新信号订单
   */
  public async saveSignal(sig: SignalOrder): Promise<void> {
    await this.init();
    const time = sig.signalTime || sig.createdAt || Date.now();
    const dateStr = sig.date || getShanghaiDateStr(time);
    const reasonsStr = JSON.stringify(sig.confirmations || sig.rationale || []);
    const snapshotStr = JSON.stringify(sig.marketSnapshotAtSignal || {});
    const durationMs = sig.expiryTime - sig.entryTime || 600000;

    await this.client.execute({
      sql: `
        INSERT OR REPLACE INTO signals (
          id, date, symbol, direction, timeframe, signal_time, entry_price, expiry_time,
          expiry_price, up_probability, down_probability, wait_probability, confidence_score,
          reasons, market_snapshot, status, result, created_at, settled_at, duration_ms
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      args: [
        sig.signalId,
        dateStr,
        sig.symbol,
        sig.direction,
        sig.duration,
        sig.signalTime,
        sig.entryPriceIndex ?? sig.signalPrice,
        sig.expiryTime,
        sig.expiryPriceIndex ?? null,
        sig.upProb ?? sig.modelProb,
        sig.downProb ?? (100 - (sig.modelProb || 50)),
        sig.waitProb ?? 0,
        sig.score ?? 85,
        reasonsStr,
        snapshotStr,
        sig.status,
        sig.result,
        sig.createdAt || time,
        sig.settledAt ?? null,
        durationMs,
      ],
    });
  }

  /**
   * 更新信号到期真实结算
   */
  public async settleSignal(
    signalId: string,
    expiryPrice: number,
    result: 'WIN' | 'LOSS',
    settledAt: number
  ): Promise<void> {
    await this.init();
    await this.client.execute({
      sql: `
        UPDATE signals
        SET status = 'SETTLED',
            result = ?,
            expiry_price = ?,
            settled_at = ?
        WHERE id = ?
      `,
      args: [result, expiryPrice, settledAt, signalId],
    });
  }

  /**
   * 获取指定日期的所有真实信号（北京时间）
   */
  public async getSignalsByDate(dateStr: string): Promise<SignalOrder[]> {
    await this.init();
    const res = await this.client.execute({
      sql: `SELECT * FROM signals WHERE date = ? ORDER BY signal_time DESC`,
      args: [dateStr],
    });
    return res.rows.map(this.rowToSignalOrder);
  }

  /**
   * 获取所有信号订单（按生成时间降序）
   */
  public async getAllSignals(limit: number = 1000): Promise<SignalOrder[]> {
    await this.init();
    const res = await this.client.execute({
      sql: `SELECT * FROM signals ORDER BY signal_time DESC LIMIT ?`,
      args: [limit],
    });
    return res.rows.map(this.rowToSignalOrder);
  }

  /**
   * 获取当前未结算进行中的信号
   */
  public async getActiveSignals(): Promise<SignalOrder[]> {
    await this.init();
    const res = await this.client.execute(`
      SELECT * FROM signals
      WHERE status IN ('ACTIVE', 'WAITING_ENTRY', 'PENDING')
      ORDER BY signal_time DESC
    `);
    return res.rows.map(this.rowToSignalOrder);
  }

  /**
   * 获取指定日期的统计汇总（北京时间）
   */
  public async getDailyStats(dateStr: string): Promise<DailySignalStats> {
    await this.init();
    const res = await this.client.execute({
      sql: `
        SELECT 
          COUNT(*) as total_signals,
          SUM(CASE WHEN result = 'PENDING' OR status IN ('ACTIVE', 'PENDING', 'WAITING_ENTRY') THEN 1 ELSE 0 END) as pending,
          SUM(CASE WHEN result = 'WIN' THEN 1 ELSE 0 END) as wins,
          SUM(CASE WHEN result = 'LOSS' THEN 1 ELSE 0 END) as losses,
          SUM(CASE WHEN direction = 'UP' THEN 1 ELSE 0 END) as up_signals,
          SUM(CASE WHEN direction = 'UP' AND result = 'WIN' THEN 1 ELSE 0 END) as up_wins,
          SUM(CASE WHEN direction = 'UP' AND result = 'LOSS' THEN 1 ELSE 0 END) as up_losses,
          SUM(CASE WHEN direction = 'DOWN' THEN 1 ELSE 0 END) as down_signals,
          SUM(CASE WHEN direction = 'DOWN' AND result = 'WIN' THEN 1 ELSE 0 END) as down_wins,
          SUM(CASE WHEN direction = 'DOWN' AND result = 'LOSS' THEN 1 ELSE 0 END) as down_losses,
          SUM(CASE WHEN symbol = 'BTCUSDT' THEN 1 ELSE 0 END) as btc_signals,
          SUM(CASE WHEN symbol = 'ETHUSDT' THEN 1 ELSE 0 END) as eth_signals
        FROM signals
        WHERE date = ?
      `,
      args: [dateStr],
    });

    const row = res.rows[0] || {};
    const total = Number(row.total_signals || 0);
    const pending = Number(row.pending || 0);
    const wins = Number(row.wins || 0);
    const losses = Number(row.losses || 0);
    const settled = wins + losses;
    const winRate = settled > 0 ? Number(((wins / settled) * 100).toFixed(2)) : 0;

    const upWins = Number(row.up_wins || 0);
    const upLosses = Number(row.up_losses || 0);
    const upSettled = upWins + upLosses;
    const upWinRate = upSettled > 0 ? Number(((upWins / upSettled) * 100).toFixed(2)) : 0;

    const downWins = Number(row.down_wins || 0);
    const downLosses = Number(row.down_losses || 0);
    const downSettled = downWins + downLosses;
    const downWinRate = downSettled > 0 ? Number(((downWins / downSettled) * 100).toFixed(2)) : 0;

    return {
      date: dateStr,
      total_signals: total,
      pending,
      wins,
      losses,
      win_rate: winRate,
      up_signals: Number(row.up_signals || 0),
      up_wins: upWins,
      up_losses: upLosses,
      up_win_rate: upWinRate,
      down_signals: Number(row.down_signals || 0),
      down_wins: downWins,
      down_losses: downLosses,
      down_win_rate: downWinRate,
      btc_signals: Number(row.btc_signals || 0),
      eth_signals: Number(row.eth_signals || 0),
    };
  }

  /**
   * 获取所有历史日结归档（按日期倒序）
   */
  public async getAllDailyArchives(): Promise<DailySignalStats[]> {
    await this.init();
    const res = await this.client.execute(`
      SELECT 
        date,
        COUNT(*) as total_signals,
        SUM(CASE WHEN result = 'PENDING' OR status IN ('ACTIVE', 'PENDING', 'WAITING_ENTRY') THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN result = 'WIN' THEN 1 ELSE 0 END) as wins,
        SUM(CASE WHEN result = 'LOSS' THEN 1 ELSE 0 END) as losses,
        SUM(CASE WHEN direction = 'UP' THEN 1 ELSE 0 END) as up_signals,
        SUM(CASE WHEN direction = 'UP' AND result = 'WIN' THEN 1 ELSE 0 END) as up_wins,
        SUM(CASE WHEN direction = 'UP' AND result = 'LOSS' THEN 1 ELSE 0 END) as up_losses,
        SUM(CASE WHEN direction = 'DOWN' THEN 1 ELSE 0 END) as down_signals,
        SUM(CASE WHEN direction = 'DOWN' AND result = 'WIN' THEN 1 ELSE 0 END) as down_wins,
        SUM(CASE WHEN direction = 'DOWN' AND result = 'LOSS' THEN 1 ELSE 0 END) as down_losses,
        SUM(CASE WHEN symbol = 'BTCUSDT' THEN 1 ELSE 0 END) as btc_signals,
        SUM(CASE WHEN symbol = 'ETHUSDT' THEN 1 ELSE 0 END) as eth_signals
      FROM signals
      GROUP BY date
      ORDER BY date DESC
    `);

    return res.rows.map((row) => {
      const dateStr = String(row.date);
      const total = Number(row.total_signals || 0);
      const pending = Number(row.pending || 0);
      const wins = Number(row.wins || 0);
      const losses = Number(row.losses || 0);
      const settled = wins + losses;
      const winRate = settled > 0 ? Number(((wins / settled) * 100).toFixed(2)) : 0;

      const upWins = Number(row.up_wins || 0);
      const upLosses = Number(row.up_losses || 0);
      const upSettled = upWins + upLosses;
      const upWinRate = upSettled > 0 ? Number(((upWins / upSettled) * 100).toFixed(2)) : 0;

      const downWins = Number(row.down_wins || 0);
      const downLosses = Number(row.down_losses || 0);
      const downSettled = downWins + downLosses;
      const downWinRate = downSettled > 0 ? Number(((downWins / downSettled) * 100).toFixed(2)) : 0;

      return {
        date: dateStr,
        total_signals: total,
        pending,
        wins,
        losses,
        win_rate: winRate,
        up_signals: Number(row.up_signals || 0),
        up_wins: upWins,
        up_losses: upLosses,
        up_win_rate: upWinRate,
        down_signals: Number(row.down_signals || 0),
        down_wins: downWins,
        down_losses: downLosses,
        down_win_rate: downWinRate,
        btc_signals: Number(row.btc_signals || 0),
        eth_signals: Number(row.eth_signals || 0),
      };
    });
  }

  private rowToSignalOrder(row: any): SignalOrder {
    let confirmations: string[] = [];
    try {
      confirmations = JSON.parse(row.reasons || '[]');
    } catch {}

    let marketSnapshot: any = {};
    try {
      marketSnapshot = JSON.parse(row.market_snapshot || '{}');
    } catch {}

    const entryPrice = Number(row.entry_price);
    const expiryPrice = row.expiry_price !== null && row.expiry_price !== undefined ? Number(row.expiry_price) : null;
    const diff = expiryPrice !== null ? Number((expiryPrice - entryPrice).toFixed(4)) : null;

    const result = row.result as 'PENDING' | 'WIN' | 'LOSS';
    const status = row.status as 'WAITING_ENTRY' | 'ACTIVE' | 'SETTLED';

    return {
      signalId: String(row.id),
      id: String(row.id),
      date: String(row.date),
      symbol: row.symbol as SymbolType,
      duration: row.timeframe as DurationType,
      direction: row.direction as 'UP' | 'DOWN',
      signalTime: Number(row.signal_time),
      timestamp: Number(row.signal_time),
      signalPrice: entryPrice,
      referencePrice: entryPrice,
      modelProb: Number(row.up_probability),
      upProb: Number(row.up_probability),
      downProb: Number(row.down_probability),
      waitProb: Number(row.wait_probability),
      payoutRatio: row.timeframe === '10m' ? 0.8 : 0.85,
      breakEvenProb: 55.56,
      edge: Number((Number(row.up_probability) - 55.56).toFixed(2)),
      expectedValue: 18.5,
      entryTime: Number(row.signal_time),
      entryPriceIndex: entryPrice,
      expiryTime: Number(row.expiry_time),
      settlementTime: Number(row.expiry_time),
      expiryPriceIndex: expiryPrice,
      settlementPrice: expiryPrice,
      priceChange: diff,
      status,
      result,
      outcome: result,
      resultDetail:
        status === 'SETTLED'
          ? result === 'WIN'
            ? '预测正确'
            : '预测错误'
          : '进行中，等待到期自动结算',
      confirmations,
      rationale: confirmations,
      score: Number(row.confidence_score),
      signalStrength: Number(row.confidence_score),
      marketSnapshotAtSignal: marketSnapshot,
      createdAt: Number(row.created_at),
      settledAt: row.settled_at ? Number(row.settled_at) : undefined,
      isFormalSignal: true,
    };
  }
}

export const signalDb = new SignalDatabase();
