import {
  DailySignalStats,
  DurationType,
  EnhancedMarketRegime,
  MarketSnapshot,
  OpportunityCandidate,
  OpportunityPoolResult,
  PredictionResult,
  SignalDirection,
  SignalOrder,
  SignalStrengthLevel,
  SymbolType,
} from '../types/market.js';

// Default Binance Event Contracts Payout Ratios for 9 independent timeframes
export const PAYOUT_RATIOS: Record<DurationType, number> = {
  '30s': 0.75, // 75% Payout -> Break-even: 57.14%
  '3m':  0.78, // 78% Payout -> Break-even: 56.18%
  '5m':  0.80, // 80% Payout -> Break-even: 55.56%
  '10m': 0.80, // 80% Payout -> Break-even: 55.56%
  '15m': 0.82, // 82% Payout -> Break-even: 54.95%
  '30m': 0.85, // 85% Payout -> Break-even: 54.05%
  '1h':  0.85, // 85% Payout -> Break-even: 54.05%
  '4h':  0.85, // 85% Payout -> Break-even: 54.05%
  '1d':  0.85, // 85% Payout -> Break-even: 54.05%
};

// Cooldown durations in milliseconds for 9 independent timeframes
export const COOLDOWN_MS: Record<DurationType, number> = {
  '30s': 45 * 1000,       // 45 seconds
  '3m':  3 * 60 * 1000,   // 3 minutes
  '5m':  5 * 60 * 1000,   // 5 minutes
  '10m': 10 * 60 * 1000,  // 10 minutes
  '15m': 15 * 60 * 1000,  // 15 minutes
  '30m': 25 * 60 * 1000,  // 25 minutes
  '1h':  45 * 60 * 1000,  // 45 minutes
  '4h':  2 * 3600 * 1000, // 2 hours
  '1d':  4 * 3600 * 1000, // 4 hours
};

export class OpportunityEngine {
  /**
   * 1. 市场状态识别器 (Market Regime Detector)
   */
  public detectMarketRegime(snapshot?: MarketSnapshot | null): {
    regime: EnhancedMarketRegime;
    label: string;
    details: string;
  } {
    if (!snapshot) {
      return {
        regime: 'CHAOTIC',
        label: '数据等待中 (INITIALIZING)',
        details: '行情快照正在等待 WebSocket 首次推送',
      };
    }

    const { price, indicators, multiTimeframe, orderBook, cvdSlope, rawOfi, latencyMs } = snapshot;

    if (latencyMs > 3000 || !orderBook || orderBook.bids.length === 0) {
      return {
        regime: 'CHAOTIC',
        label: '数据延迟或盘口异常 (CHAOTIC)',
        details: `数据延迟高达 ${latencyMs}ms 或盘口数据缺失，强制进入保护态`,
      };
    }

    const atrRatio = price > 0 ? (indicators.atr14 / price) * 100 : 0;
    const isExtremeVolatility =
      atrRatio > (snapshot.symbol === 'BTCUSDT' ? 0.45 : 0.65) ||
      indicators.bollinger.bandwidth > 1.35;
    const isLowVolatility =
      indicators.bollinger.bandwidth < 0.22 && atrRatio < 0.08;

    if (isExtremeVolatility) {
      return {
        regime: 'HIGH_VOLATILITY',
        label: '极端异常波动 (HIGH VOLATILITY)',
        details: `短周期ATR比例 ${atrRatio.toFixed(3)}% 剧烈放大，布林带极限开口，容易出现假突破与插针洗盘`,
      };
    }

    if (isLowVolatility) {
      return {
        regime: 'LOW_VOLATILITY',
        label: '极低波动缩量 (LOW VOLATILITY)',
        details: `布林带严重收口(宽度: ${indicators.bollinger.bandwidth.toFixed(3)}%)，缺乏有效趋势能量`,
      };
    }

    // 突破检测：价格突破近20根K线高低点，且伴随CVD与OFI放量
    const recentKlines = snapshot.recentKlines || [];
    if (recentKlines.length >= 20) {
      const last20 = recentKlines.slice(-20);
      const high20 = Math.max(...last20.map((k) => k.high));
      const low20 = Math.min(...last20.map((k) => k.low));

      if (price >= high20 && (cvdSlope || 0) > 8 && (rawOfi || 0) > 10) {
        return {
          regime: 'BREAKOUT',
          label: '多头放量突破 (BREAKOUT)',
          details: '价格突破20根K线阻力高位，且主动买盘CVD斜率与OFI显著配合放量',
        };
      }

      if (price <= low20 && (cvdSlope || 0) < -8 && (rawOfi || 0) < -10) {
        return {
          regime: 'BREAKDOWN',
          label: '空头下破跌破 (BREAKDOWN)',
          details: '价格跌破20根K线支撑低位，主动卖盘倾泻下破',
        };
      }
    }

    // 趋势检测：EMA7 > EMA20 > EMA50 且多周期协同分明确
    const ema7 = indicators.ema7;
    const ema20 = indicators.ema20;
    const ema50 = indicators.ema50;
    const tfScore = multiTimeframe?.alignmentScore || 0;

    if (ema7 > ema20 && ema20 > ema50 && tfScore >= 30) {
      return {
        regime: 'TREND_UP',
        label: '多头均线趋势 (TREND UP)',
        details: `均线呈典型多头发散排列，多周期共振分 +${tfScore} 分`,
      };
    }

    if (ema7 < ema20 && ema20 < ema50 && tfScore <= -30) {
      return {
        regime: 'TREND_DOWN',
        label: '空头均线趋势 (TREND DOWN)',
        details: `均线呈典型空头发散排列，多周期共振分 ${tfScore} 分`,
      };
    }

    // 反转力道衰竭判定
    if (indicators.rsi > 74 && (rawOfi || 0) < 0) {
      return {
        regime: 'REVERSAL',
        label: '多头超买顶背离 (REVERSAL RISK)',
        details: '短线价格严重超买，但OFI盘口挂单已开始压制，存在冲高回落反转风险',
      };
    }

    if (indicators.rsi < 26 && (rawOfi || 0) > 0) {
      return {
        regime: 'REVERSAL',
        label: '空头超卖底背离 (REVERSAL RISK)',
        details: '短线价格严重超卖，下方买盘挂单托底，存在超跌反弹风险',
      };
    }

    return {
      regime: 'RANGE',
      label: '区间震荡整理 (RANGE)',
      details: '多空均线交织纠缠，未形成显著单边突破，适宜等待或高抛低吸',
    };
  }

  /**
   * 2. 计算 BTC 与 ETH 的收益率皮尔逊相关系数
   */
  public calculateBtcEthCorrelation(
    btcKlines: { close: number }[],
    ethKlines: { close: number }[]
  ): number {
    if (!btcKlines || !ethKlines || btcKlines.length < 20 || ethKlines.length < 20) {
      return 0.85; // Default standard crypto market beta correlation
    }

    const n = Math.min(btcKlines.length, ethKlines.length, 60);
    const btcReturns: number[] = [];
    const ethReturns: number[] = [];

    for (let i = 1; i < n; i++) {
      const b0 = btcKlines[btcKlines.length - n + i - 1].close;
      const b1 = btcKlines[btcKlines.length - n + i].close;
      const e0 = ethKlines[ethKlines.length - n + i - 1].close;
      const e1 = ethKlines[ethKlines.length - n + i].close;

      if (b0 > 0 && e0 > 0) {
        btcReturns.push((b1 - b0) / b0);
        ethReturns.push((e1 - e0) / e0);
      }
    }

    const count = btcReturns.length;
    if (count < 10) return 0.85;

    const meanB = btcReturns.reduce((a, b) => a + b, 0) / count;
    const meanE = ethReturns.reduce((a, b) => a + b, 0) / count;

    let num = 0;
    let denB = 0;
    let denE = 0;

    for (let i = 0; i < count; i++) {
      const db = btcReturns[i] - meanB;
      const de = ethReturns[i] - meanE;
      num += db * de;
      denB += db * db;
      denE += de * de;
    }

    if (denB <= 0 || denE <= 0) return 0.85;
    const corr = num / Math.sqrt(denB * denE);
    return Number(Math.max(-1, Math.min(1, corr)).toFixed(2));
  }

  /**
   * 3. 概率校准器 (Platt-Scaling Logistic Calibration)
   * 严禁直接使用模型未校准的极端原概率！
   */
  public calibrateProbability(rawProb: number): number {
    // Clamp raw prob to [15, 88]
    const p = Math.max(0.15, Math.min(0.88, rawProb / 100));
    // Logit transform
    const logit = Math.log(p / (1 - p));
    // Platt-scaling compression to prevent extreme overconfidence while preserving authentic statistical edge
    const calibratedLogit = 0.90 * logit;
    const calibratedP = 1 / (1 + Math.exp(-calibratedLogit));
    return Number((calibratedP * 100).toFixed(1));
  }

  /**
   * 4. 防追涨杀跌 / 价格过度延伸检测器 (Overextension Filter)
   */
  public checkOverextension(
    price: number,
    ema7: number,
    atr14: number,
    direction: 'UP' | 'DOWN',
    rsi: number
  ): { isOverextended: boolean; reason?: string } {
    if (price <= 0 || atr14 <= 0) return { isOverextended: false };

    const distFromMean = Math.abs(price - ema7);
    const atrMultiple = distFromMean / atr14;

    if (direction === 'UP') {
      if (price > ema7 && atrMultiple > 1.25) {
        return {
          isOverextended: true,
          reason: `价格已大幅高于EMA7短期均线 (${atrMultiple.toFixed(2)}倍ATR)，短线过度延伸，严禁盲目追多`,
        };
      }
      if (rsi > 76) {
        return {
          isOverextended: true,
          reason: `RSI动量已达 ${rsi.toFixed(1)} 严重超买极端区，存在冲高洗盘诱多风险`,
        };
      }
    } else {
      if (price < ema7 && atrMultiple > 1.25) {
        return {
          isOverextended: true,
          reason: `价格已大幅低于EMA7短期均线 (${atrMultiple.toFixed(2)}倍ATR)，短线空头过度延伸，严禁追空`,
        };
      }
      if (rsi < 24) {
        return {
          isOverextended: true,
          reason: `RSI动量已达 ${rsi.toFixed(1)} 严重超卖极端区，存在插针反抽爆空风险`,
        };
      }
    }

    return { isOverextended: false };
  }

  /**
   * 30秒候选机会专属决策逻辑 (Ultra-High-Frequency Micro-Stream)
   * 架构约束：30s 采用轻量级实时流计算（聚焦盘口价差与瞬时成交流）；
   * 数据延迟或不足时短周期严禁强行发信号。
   */
  private evaluate30s(
    snapshot: MarketSnapshot,
    regime: EnhancedMarketRegime
  ): {
    candidateDirection: 'UP' | 'DOWN';
    rawProb: number;
    score: number;
    keyFactors: string[];
    rejectionReasons: string[];
    timeframeRole: string;
    longPassed: boolean;
    shortPassed: boolean;
    primaryDriver: string;
  } {
    const { orderBook, rawOfi, cvdSlope, microstructure, latencyMs } = snapshot;
    const timeframeRole = '30秒超高频极速流撮合 (30s Ultra-Micro Stream)';

    const ofi = rawOfi || 0;
    const cvdSl = cvdSlope || 0;
    const spreadPct = orderBook?.spreadPercent || (orderBook && snapshot.price > 0 ? orderBook.spread / snapshot.price : 0.0001);
    const bidRatio = orderBook && orderBook.bidTotal + orderBook.askTotal > 0
      ? orderBook.bidTotal / (orderBook.bidTotal + orderBook.askTotal)
      : 0.5;

    let longScore = 50;
    let shortScore = 50;
    const longFactors: string[] = [];
    const shortFactors: string[] = [];
    const longRejections: string[] = [];
    const shortRejections: string[] = [];

    // Red line check: latency & spread constraints
    if (latencyMs > 1500) {
      longRejections.push(`❌ 30s周期严禁延迟交易：当前数据延迟 ${latencyMs}ms (>1500ms)，触发极速风控保护`);
      shortRejections.push(`❌ 30s周期严禁延迟交易：当前数据延迟 ${latencyMs}ms (>1500ms)，触发极速风控保护`);
    }

    if (spreadPct > 0.0003) {
      longRejections.push(`❌ 30s盘口点差过大 (${(spreadPct * 100).toFixed(3)}%)，超短线滑点摩擦成本过高`);
      shortRejections.push(`❌ 30s盘口点差过大 (${(spreadPct * 100).toFixed(3)}%)，超短线滑点摩擦成本过高`);
    }

    const tickDelta = microstructure?.tickDelta || 0;
    const takerRatio = microstructure?.takerBuyRatio || 0.5;

    // Independent LONG for 30s
    if (tickDelta >= 4 && takerRatio > 0.55) {
      longScore += 24;
      longFactors.push(`✓ 瞬时Tick吃买加速 (Tick Delta: +${tickDelta}, Taker买比: ${(takerRatio * 100).toFixed(1)}%)`);
    } else if (tickDelta <= -3 || takerRatio < 0.46) {
      longScore -= 25;
      longRejections.push(`❌ 瞬时主动卖流压制 (Tick Delta: ${tickDelta})`);
    }

    if (bidRatio >= 0.56) {
      longScore += 16;
      longFactors.push(`✓ 盘口前五档买方垫单厚重 (占比 ${(bidRatio * 100).toFixed(1)}%)`);
    } else if (bidRatio < 0.47) {
      longScore -= 20;
      longRejections.push(`❌ 盘口买方垫单稀薄 (占比 ${(bidRatio * 100).toFixed(1)}%)`);
    }

    if (ofi > 3 && cvdSl > 2) {
      longScore += 12;
      longFactors.push(`✓ 短时OFI与CVD斜率共振正向`);
    }

    // Independent SHORT for 30s
    if (tickDelta <= -4 && takerRatio < 0.45) {
      shortScore += 24;
      shortFactors.push(`✓ 瞬时Tick砸盘加速 (Tick Delta: ${tickDelta}, Taker买比: ${(takerRatio * 100).toFixed(1)}%)`);
    } else if (tickDelta >= 3 || takerRatio > 0.54) {
      shortScore -= 25;
      shortRejections.push(`❌ 瞬时主动买流托单 (Tick Delta: +${tickDelta})`);
    }

    if (bidRatio <= 0.44) {
      shortScore += 16;
      shortFactors.push(`✓ 盘口前五档卖方压盘显著 (卖方占比 ${((1 - bidRatio) * 100).toFixed(1)}%)`);
    } else if (bidRatio > 0.53) {
      shortScore -= 20;
      shortRejections.push(`❌ 盘口下方托单较重 (买方占比 ${(bidRatio * 100).toFixed(1)}%)`);
    }

    if (ofi < -3 && cvdSl < -2) {
      shortScore += 12;
      shortFactors.push(`✓ 短时OFI与CVD斜率共振负向`);
    }

    const longPassed =
      latencyMs <= 1500 &&
      spreadPct <= 0.0003 &&
      longScore >= 78 &&
      bidRatio >= 0.53 &&
      tickDelta >= 2 &&
      longRejections.length === 0;

    const shortPassed =
      latencyMs <= 1500 &&
      spreadPct <= 0.0003 &&
      shortScore >= 78 &&
      bidRatio <= 0.47 &&
      tickDelta <= -2 &&
      shortRejections.length === 0;

    let candidateDirection: 'UP' | 'DOWN';
    let chosenScore: number;
    let keyFactors: string[];
    let rejectionReasons: string[];
    let primaryDriver = '30s盘口微结构';

    if (longPassed && !shortPassed) {
      candidateDirection = 'UP';
      chosenScore = longScore;
      keyFactors = longFactors;
      rejectionReasons = longRejections;
      primaryDriver = '30s瞬时吃买流突破';
    } else if (shortPassed && !longPassed) {
      candidateDirection = 'DOWN';
      chosenScore = shortScore;
      keyFactors = shortFactors;
      rejectionReasons = shortRejections;
      primaryDriver = '30s瞬时吃卖流砸盘';
    } else {
      candidateDirection = longScore >= shortScore ? 'UP' : 'DOWN';
      chosenScore = Math.min(longScore, shortScore, 65);
      keyFactors = candidateDirection === 'UP' ? longFactors : shortFactors;
      rejectionReasons = [...longRejections.slice(0, 2), ...shortRejections.slice(0, 2)];
      if (rejectionReasons.length === 0) {
        rejectionReasons.push('❌ 30s盘口微观撮合多空势均力敌，无显著瞬时失衡');
      }
    }

    const rawProb = Math.min(88, Math.max(30, 50 + (chosenScore - 50) * 0.74));
    return {
      candidateDirection,
      rawProb: Number(rawProb.toFixed(1)),
      score: Math.min(100, Math.max(0, Math.round(chosenScore))),
      keyFactors,
      rejectionReasons,
      timeframeRole,
      longPassed,
      shortPassed,
      primaryDriver,
    };
  }

  /**
   * 3分钟候选机会专属决策逻辑 (3m Instantaneous Order Flow)
   * 架构约束：聚焦短线微观成交脉冲与盘口量能共振
   */
  private evaluate3m(
    snapshot: MarketSnapshot,
    regime: EnhancedMarketRegime
  ): {
    candidateDirection: 'UP' | 'DOWN';
    rawProb: number;
    score: number;
    keyFactors: string[];
    rejectionReasons: string[];
    timeframeRole: string;
    longPassed: boolean;
    shortPassed: boolean;
    primaryDriver: string;
  } {
    const { orderBook, rawOfi, cvdSlope, cvd5mChange, latencyMs } = snapshot;
    const timeframeRole = '3分钟瞬时成交流 (3m Instantaneous Flow & CVD Pulse)';

    const ofi = rawOfi || 0;
    const cvdSl = cvdSlope || 0;
    const cvd5m = cvd5mChange || 0;
    const bidRatio = orderBook && orderBook.bidTotal + orderBook.askTotal > 0
      ? orderBook.bidTotal / (orderBook.bidTotal + orderBook.askTotal)
      : 0.5;

    let longScore = 50;
    let shortScore = 50;
    const longFactors: string[] = [];
    const shortFactors: string[] = [];
    const longRejections: string[] = [];
    const shortRejections: string[] = [];

    if (latencyMs > 2000) {
      longRejections.push(`❌ 3m数据延迟高达 ${latencyMs}ms，超时保护`);
      shortRejections.push(`❌ 3m数据延迟高达 ${latencyMs}ms，超时保护`);
    }

    // Long
    if (cvdSl > 4 && cvd5m > 0) {
      longScore += 22;
      longFactors.push(`✓ 3m CVD买盘斜率显著上攻 (+${cvdSl.toFixed(1)})`);
    } else {
      longScore -= 18;
      longRejections.push('❌ 3m CVD买盘未放量上攻');
    }

    if (ofi > 4) {
      longScore += 16;
      longFactors.push(`✓ 3m OFI买方持续堆单 (+${ofi.toFixed(1)})`);
    } else {
      longScore -= 15;
      longRejections.push('❌ 3m OFI买方支撑不足');
    }

    if (bidRatio >= 0.51) {
      longScore += 10;
      longFactors.push(`✓ 盘口买方占优 (${(bidRatio * 100).toFixed(1)}%)`);
    }

    // Short
    if (cvdSl < -4 && cvd5m < 0) {
      shortScore += 22;
      shortFactors.push(`✓ 3m CVD主动抛压斜率剧烈向下 (${cvdSl.toFixed(1)})`);
    } else {
      shortScore -= 18;
      shortRejections.push('❌ 3m CVD卖压未达到阈值');
    }

    if (ofi < -4) {
      shortScore += 16;
      shortFactors.push(`✓ 3m OFI卖压压盘强化 (${ofi.toFixed(1)})`);
    } else {
      shortScore -= 15;
      shortRejections.push('❌ 3m OFI卖方压制不足');
    }

    if (bidRatio <= 0.49) {
      shortScore += 10;
      shortFactors.push(`✓ 盘口卖方占优 (${((1 - bidRatio) * 100).toFixed(1)}%)`);
    }

    const longPassed = latencyMs <= 2000 && longScore >= 78 && ofi > 2 && cvdSl > 2 && longRejections.length === 0;
    const shortPassed = latencyMs <= 2000 && shortScore >= 78 && ofi < -2 && cvdSl < -2 && shortRejections.length === 0;

    let candidateDirection: 'UP' | 'DOWN';
    let chosenScore: number;
    let keyFactors: string[];
    let rejectionReasons: string[];
    let primaryDriver = '3m订单流';

    if (longPassed && !shortPassed) {
      candidateDirection = 'UP';
      chosenScore = longScore;
      keyFactors = longFactors;
      rejectionReasons = longRejections;
      primaryDriver = '3m主动买流放量突破';
    } else if (shortPassed && !longPassed) {
      candidateDirection = 'DOWN';
      chosenScore = shortScore;
      keyFactors = shortFactors;
      rejectionReasons = shortRejections;
      primaryDriver = '3m主动卖流倾泻下破';
    } else {
      candidateDirection = longScore >= shortScore ? 'UP' : 'DOWN';
      chosenScore = Math.min(longScore, shortScore, 66);
      keyFactors = candidateDirection === 'UP' ? longFactors : shortFactors;
      rejectionReasons = [...longRejections.slice(0, 2), ...shortRejections.slice(0, 2)];
      if (rejectionReasons.length === 0) {
        rejectionReasons.push('❌ 3m周期多空能量相持，缺乏主导成交量');
      }
    }

    const rawProb = Math.min(88, Math.max(30, 50 + (chosenScore - 50) * 0.75));
    return {
      candidateDirection,
      rawProb: Number(rawProb.toFixed(1)),
      score: Math.min(100, Math.max(0, Math.round(chosenScore))),
      keyFactors,
      rejectionReasons,
      timeframeRole,
      longPassed,
      shortPassed,
      primaryDriver,
    };
  }

  /**
   * 5分钟候选机会专属决策逻辑 (5m Momentum & Micro Breakout)
   */
  private evaluate5m(
    snapshot: MarketSnapshot,
    regime: EnhancedMarketRegime
  ): {
    candidateDirection: 'UP' | 'DOWN';
    rawProb: number;
    score: number;
    keyFactors: string[];
    rejectionReasons: string[];
    timeframeRole: string;
    longPassed: boolean;
    shortPassed: boolean;
    primaryDriver: string;
  } {
    const { indicators, rawOfi, cvdSlope, cvd5mChange, price } = snapshot;
    const timeframeRole = '5分钟动量与微观突破 (5m Momentum & Breakout)';

    const ofi = rawOfi || 0;
    const cvdSl = cvdSlope || 0;
    const cvd5m = cvd5mChange || 0;
    const ema7 = indicators?.ema7 || price;
    const ema20 = indicators?.ema20 || price;
    const macdHist = indicators?.macd?.histogram || 0;

    let longScore = 50;
    let shortScore = 50;
    const longFactors: string[] = [];
    const shortFactors: string[] = [];
    const longRejections: string[] = [];
    const shortRejections: string[] = [];

    // Long
    if (price > ema7 && ema7 >= ema20) {
      longScore += 18;
      longFactors.push('✓ 5m价格站上EMA7短期均线上方且EMA7>=EMA20');
    } else {
      longScore -= 18;
      longRejections.push('❌ 5m价格低于EMA7短期均线');
    }

    if (cvd5m > 0 && cvdSl > 2) {
      longScore += 18;
      longFactors.push(`✓ 5m CVD主动净流入 (+${cvd5m.toFixed(1)})`);
    } else {
      longScore -= 16;
      longRejections.push('❌ 5m CVD未放量');
    }

    if (macdHist > 0) {
      longScore += 12;
      longFactors.push('✓ 5m MACD动能柱维持多头扩张');
    }

    // Short
    if (price < ema7 && ema7 <= ema20) {
      shortScore += 18;
      shortFactors.push('✓ 5m价格跌破EMA7短期均线且EMA7<=EMA20');
    } else {
      shortScore -= 18;
      shortRejections.push('❌ 5m价格高于EMA7短期均线');
    }

    if (cvd5m < 0 && cvdSl < -2) {
      shortScore += 18;
      shortFactors.push(`✓ 5m CVD主动净流出 (${cvd5m.toFixed(1)})`);
    } else {
      shortScore -= 16;
      shortRejections.push('❌ 5m CVD卖方流出未达标');
    }

    if (macdHist < 0) {
      shortScore += 12;
      shortFactors.push('✓ 5m MACD动能柱空头扩张');
    }

    const longPassed = longScore >= 78 && price > ema7 && cvd5m > 0 && ofi >= 0 && longRejections.length === 0;
    const shortPassed = shortScore >= 78 && price < ema7 && cvd5m < 0 && ofi <= 0 && shortRejections.length === 0;

    let candidateDirection: 'UP' | 'DOWN';
    let chosenScore: number;
    let keyFactors: string[];
    let rejectionReasons: string[];
    let primaryDriver = '5m动量突破';

    if (longPassed && !shortPassed) {
      candidateDirection = 'UP';
      chosenScore = longScore;
      keyFactors = longFactors;
      rejectionReasons = longRejections;
      primaryDriver = '5m均线动量顺势看多';
    } else if (shortPassed && !longPassed) {
      candidateDirection = 'DOWN';
      chosenScore = shortScore;
      keyFactors = shortFactors;
      rejectionReasons = shortRejections;
      primaryDriver = '5m均线动量顺势看空';
    } else {
      candidateDirection = longScore >= shortScore ? 'UP' : 'DOWN';
      chosenScore = Math.min(longScore, shortScore, 67);
      keyFactors = candidateDirection === 'UP' ? longFactors : shortFactors;
      rejectionReasons = [...longRejections.slice(0, 2), ...shortRejections.slice(0, 2)];
      if (rejectionReasons.length === 0) {
        rejectionReasons.push('❌ 5m周期动量与订单流平衡，未形成单边破位');
      }
    }

    const rawProb = Math.min(88, Math.max(30, 50 + (chosenScore - 50) * 0.75));
    return {
      candidateDirection,
      rawProb: Number(rawProb.toFixed(1)),
      score: Math.min(100, Math.max(0, Math.round(chosenScore))),
      keyFactors,
      rejectionReasons,
      timeframeRole,
      longPassed,
      shortPassed,
      primaryDriver,
    };
  }

  /**
   * 10分钟候选机会专属决策逻辑 (Microstructure-heavy)
   * 严格实现 LONG 与 SHORT 完全独立的判定逻辑，严禁非黑即白的镜像逻辑
   */
  private evaluate10m(
    snapshot: MarketSnapshot,
    regime: EnhancedMarketRegime
  ): {
    candidateDirection: 'UP' | 'DOWN';
    rawProb: number;
    score: number;
    keyFactors: string[];
    rejectionReasons: string[];
    timeframeRole: string;
    longPassed: boolean;
    shortPassed: boolean;
    primaryDriver: string;
  } {
    const { orderBook, rawOfi, cvdSlope, cvd5mChange, indicators, microstructure, multiTimeframe, recentKlines } = snapshot;
    const timeframeRole = '微观订单流高频撮合突破 (10m Microstructure & Order Flow)';

    const ofi = rawOfi || 0;
    const cvd = cvd5mChange || 0;
    const cvdSl = cvdSlope || 0;
    const bidRatio = orderBook && orderBook.bidTotal + orderBook.askTotal > 0
      ? orderBook.bidTotal / (orderBook.bidTotal + orderBook.askTotal)
      : 0.5;

    // 10m Micro Breakout / Fakeout detection (recent 5 klines)
    const last5Klines = (recentKlines || []).slice(-5);
    const high5m = last5Klines.length > 0 ? Math.max(...last5Klines.map((k) => k.high)) : snapshot.price;
    const low5m = last5Klines.length > 0 ? Math.min(...last5Klines.map((k) => k.low)) : snapshot.price;
    const nearHigh5m = high5m > 0 && (snapshot.price >= high5m * 0.9995);
    const nearLow5m = low5m > 0 && (snapshot.price <= low5m * 1.0005);
    const tfScore = multiTimeframe?.alignmentScore || 0;

    // 【独立判定 1】：OPEN LONG 独立多头评估体系
    let longScore = 50;
    const longFactors: string[] = [];
    const longRejections: string[] = [];

    if (ofi > 8) {
      longScore += Math.min(24, ofi * 1.5);
      longFactors.push(`✓ OFI订单流买方持续补充 (+${ofi.toFixed(1)}分)`);
    } else if (ofi > 2) {
      longScore += 8;
      longFactors.push(`✓ OFI偏向买方 (+${ofi.toFixed(1)}分)`);
    } else {
      longScore -= 25;
      longRejections.push(`❌ OFI订单流买方不足 (${ofi.toFixed(1)}分)，微观盘口不支持看多`);
    }

    if (cvdSl > 3 && cvd > 0) {
      longScore += 20;
      longFactors.push(`✓ CVD主动买盘放量推进 (5m变化: +${cvd.toFixed(1)})`);
    } else if (cvdSl < -3 || cvd < 0) {
      longScore -= 28;
      longRejections.push(`❌ CVD主动卖单倾泻，吃单方向与多头相反`);
    } else {
      longScore -= 10;
      longRejections.push(`❌ CVD买盘动能平淡，未出现主动吃单突破`);
    }

    if (bidRatio >= 0.48) {
      longScore += 10;
      longFactors.push(`✓ L2前20档买方挂单托底坚挺 (买方占比 ${(bidRatio * 100).toFixed(1)}%)`);
    } else {
      longScore -= 20;
      longRejections.push(`❌ 盘口卖方压盘显著 (买方占比仅 ${(bidRatio * 100).toFixed(1)}%)`);
    }

    if (microstructure) {
      if (microstructure.tickDelta > 3 && microstructure.takerBuyRatio > 0.52) {
        longScore += 12;
        longFactors.push(`✓ 微观Tick单净买入 (Tick Delta: +${microstructure.tickDelta}, Taker买比: ${(microstructure.takerBuyRatio * 100).toFixed(1)}%)`);
      } else if (microstructure.tickDelta < -3) {
        longScore -= 16;
        longRejections.push(`❌ 微观Tick出现净主动吃卖 (Delta: ${microstructure.tickDelta})`);
      }
    }

    if (nearHigh5m && (ofi < 2 || cvd < 0)) {
      longScore -= 30;
      longRejections.push('❌ 10分钟微观假突破保护：逼近5m局部高点但盘口OFI/CVD未有效放量');
    }

    if (tfScore >= 20) {
      longScore += 8;
      longFactors.push(`✓ 大周期背景趋势偏多顺势 (+${tfScore}分)`);
    } else if (tfScore <= -35) {
      longScore -= 20;
      longRejections.push(`❌ 逆大周期严重空头背景 (${tfScore}分)，10分钟多头受压`);
    }

    const longPassed = longScore >= 78 && ofi > 2 && cvdSl > 0 && bidRatio >= 0.47 && longRejections.length === 0;

    // 【独立判定 2】：OPEN SHORT 独立空头评估体系 (绝非 LONG 反向补集)
    let shortScore = 50;
    const shortFactors: string[] = [];
    const shortRejections: string[] = [];

    if (ofi < -8) {
      shortScore += Math.min(24, Math.abs(ofi) * 1.5);
      shortFactors.push(`✓ OFI订单流卖方压迫施压 (${ofi.toFixed(1)}分)`);
    } else if (ofi < -2) {
      shortScore += 8;
      shortFactors.push(`✓ OFI偏向卖方 (${ofi.toFixed(1)}分)`);
    } else {
      shortScore -= 25;
      shortRejections.push(`❌ OFI订单流卖方不足 (${ofi.toFixed(1)}分)，微观盘口不支持做空`);
    }

    if (cvdSl < -3 && cvd < 0) {
      shortScore += 20;
      shortFactors.push(`✓ CVD主动卖盘放量泄压 (5m变化: ${cvd.toFixed(1)})`);
    } else if (cvdSl > 3 || cvd > 0) {
      shortScore -= 28;
      shortRejections.push(`❌ CVD主动买单强劲，吃单方向与空头相反`);
    } else {
      shortScore -= 10;
      shortRejections.push(`❌ CVD卖盘动能平淡，未出现主动砸盘下破`);
    }

    if (bidRatio <= 0.52) {
      shortScore += 10;
      shortFactors.push(`✓ L2前20档卖方压单密集 (卖方占比 ${((1 - bidRatio) * 100).toFixed(1)}%)`);
    } else {
      shortScore -= 20;
      shortRejections.push(`❌ 盘口买方托单过厚 (卖方占比仅 ${((1 - bidRatio) * 100).toFixed(1)}%)`);
    }

    if (microstructure) {
      if (microstructure.tickDelta < -3 && microstructure.takerBuyRatio < 0.48) {
        shortScore += 12;
        shortFactors.push(`✓ 微观Tick单净卖出 (Tick Delta: ${microstructure.tickDelta}, Taker卖比: ${((1 - microstructure.takerBuyRatio) * 100).toFixed(1)}%)`);
      } else if (microstructure.tickDelta > 3) {
        shortScore -= 16;
        shortRejections.push(`❌ 微观Tick出现净主动吃买 (Delta: +${microstructure.tickDelta})`);
      }
    }

    if (nearLow5m && (ofi > -2 || cvd > 0)) {
      shortScore -= 30;
      shortRejections.push('❌ 10分钟微观假跌破保护：逼近5m局部低点但盘口出现托单支撑');
    }

    if (tfScore <= -20) {
      shortScore += 8;
      shortFactors.push(`✓ 大周期背景趋势偏空顺势 (${tfScore}分)`);
    } else if (tfScore >= 35) {
      shortScore -= 20;
      shortRejections.push(`❌ 逆大周期严重多头背景 (+${tfScore}分)，10分钟空头受限`);
    }

    const shortPassed = shortScore >= 78 && ofi < -2 && cvdSl < 0 && bidRatio <= 0.53 && shortRejections.length === 0;

    let candidateDirection: 'UP' | 'DOWN';
    let chosenScore: number;
    let keyFactors: string[];
    let rejectionReasons: string[];
    let primaryDriver = '10m微观订单流脉冲';

    if (longPassed && !shortPassed) {
      candidateDirection = 'UP';
      chosenScore = longScore;
      keyFactors = longFactors;
      rejectionReasons = longRejections;
      primaryDriver = `10m微观主动买盘驱动 (OFI +${ofi.toFixed(1)}, CVD 5m +${cvd.toFixed(1)})`;
    } else if (shortPassed && !longPassed) {
      candidateDirection = 'DOWN';
      chosenScore = shortScore;
      keyFactors = shortFactors;
      rejectionReasons = shortRejections;
      primaryDriver = `10m微观主动卖盘驱动 (OFI ${ofi.toFixed(1)}, CVD 5m ${cvd.toFixed(1)})`;
    } else {
      candidateDirection = longScore >= shortScore ? 'UP' : 'DOWN';
      chosenScore = Math.min(longScore, shortScore, 68);
      keyFactors = candidateDirection === 'UP' ? longFactors : shortFactors;
      rejectionReasons = [
        ...longRejections.slice(0, 2),
        ...shortRejections.slice(0, 2),
      ];
      if (rejectionReasons.length === 0) {
        rejectionReasons.push('❌ 10分钟微观订单流多空双向均无明确独立优势');
      }
    }

    const rawProb = Math.min(88, Math.max(30, 50 + (chosenScore - 50) * 0.76));

    return {
      candidateDirection,
      rawProb: Number(rawProb.toFixed(1)),
      score: Math.min(100, Math.max(0, Math.round(chosenScore))),
      keyFactors,
      rejectionReasons,
      timeframeRole,
      longPassed,
      shortPassed,
      primaryDriver,
    };
  }

  /**
   * 6. 30分钟候选机会专属决策逻辑 (Swing wave & Intermediate structure)
   * 严格实现独立多空双逻辑判定
   */
  private evaluate30m(
    snapshot: MarketSnapshot,
    regime: EnhancedMarketRegime
  ): {
    candidateDirection: 'UP' | 'DOWN';
    rawProb: number;
    score: number;
    keyFactors: string[];
    rejectionReasons: string[];
    timeframeRole: string;
    longPassed: boolean;
    shortPassed: boolean;
    primaryDriver: string;
  } {
    const { multiTimeframe, openInterest, fundingRate, indicators, cvd5mChange, rawOfi } = snapshot;
    const timeframeRole = '短中期波段结构与持仓博弈 (30m Intermediate Swing)';

    const tfScore = multiTimeframe?.alignmentScore || 0;
    const fundingPct = (fundingRate || 0) * 100;
    const cvd = cvd5mChange || 0;
    const ofi = rawOfi || 0;

    // Independent LONG for 30m
    let longScore = 50;
    const longFactors: string[] = [];
    const longRejections: string[] = [];

    if (tfScore >= 25) {
      longScore += 22;
      longFactors.push(`✓ 5m/15m/30m 均线短中期结构多头支持 (+${tfScore}分)`);
    } else {
      longScore -= 18;
      longRejections.push('❌ 30分钟短中期均线多头共振不足');
    }

    if (fundingPct > 0.035) {
      longScore -= 25;
      longRejections.push(`❌ 资金费率多头严重过热 (${fundingPct.toFixed(4)}%)，多头拥挤`);
    } else if (fundingPct < 0.015) {
      longScore += 8;
      longFactors.push(`✓ 资金费率健康平稳 (${fundingPct.toFixed(4)}%)`);
    }

    if (cvd > 15 && ofi > 5) {
      longScore += 18;
      longFactors.push('✓ CVD与OFI同步放大支持30m多头');
    } else if (cvd < -10 || ofi < -5) {
      longScore -= 22;
      longRejections.push('❌ 30分钟出现主动卖单压盘与OFI负值，多头结构背离');
    } else {
      longScore -= 10;
      longRejections.push('❌ 30分钟缺少强烈的订单流(CVD/OFI)共振支持');
    }

    const longPassed = longScore >= 78 && tfScore >= 25 && cvd > 0 && ofi > 0 && longRejections.length === 0;

    // Independent SHORT for 30m
    let shortScore = 50;
    const shortFactors: string[] = [];
    const shortRejections: string[] = [];

    if (tfScore <= -25) {
      shortScore += 22;
      shortFactors.push(`✓ 5m/15m/30m 均线短中期结构空头支持 (${tfScore}分)`);
    } else {
      shortScore -= 18;
      shortRejections.push('❌ 30分钟短中期均线空头共振不足');
    }

    if (fundingPct < -0.02) {
      shortScore -= 25;
      shortRejections.push(`❌ 资金费率空头过热 (${fundingPct.toFixed(4)}%)，空头拥挤反弹风险`);
    } else if (fundingPct > -0.01) {
      shortScore += 8;
      shortFactors.push(`✓ 资金费率无空头拥挤踩踏风险 (${fundingPct.toFixed(4)}%)`);
    }

    if (cvd < -15 && ofi < -5) {
      shortScore += 18;
      shortFactors.push('✓ CVD与OFI同步放大支持30m空头');
    } else if (cvd > 10 || ofi > 5) {
      shortScore -= 22;
      shortRejections.push('❌ 30分钟出现主动买盘托单与OFI正值，空头逻辑受阻');
    } else {
      shortScore -= 10;
      shortRejections.push('❌ 30分钟缺少强烈的订单流(CVD/OFI)放量压迫');
    }

    const shortPassed = shortScore >= 78 && tfScore <= -25 && cvd < 0 && ofi < 0 && shortRejections.length === 0;

    let candidateDirection: 'UP' | 'DOWN';
    let chosenScore: number;
    let keyFactors: string[];
    let rejectionReasons: string[];
    let primaryDriver = '30m波段结构博弈';

    if (longPassed && !shortPassed) {
      candidateDirection = 'UP';
      chosenScore = longScore;
      keyFactors = longFactors;
      rejectionReasons = longRejections;
      primaryDriver = `30m均线波段与持仓多头推进 (均线共振 +${tfScore})`;
    } else if (shortPassed && !longPassed) {
      candidateDirection = 'DOWN';
      chosenScore = shortScore;
      keyFactors = shortFactors;
      rejectionReasons = shortRejections;
      primaryDriver = `30m均线波段与持仓空头承压 (均线共振 ${tfScore})`;
    } else {
      candidateDirection = longScore >= shortScore ? 'UP' : 'DOWN';
      chosenScore = Math.min(longScore, shortScore, 68);
      keyFactors = candidateDirection === 'UP' ? longFactors : shortFactors;
      rejectionReasons = [
        ...longRejections.slice(0, 2),
        ...shortRejections.slice(0, 2),
      ];
      if (rejectionReasons.length === 0) {
        rejectionReasons.push('❌ 30分钟短中期多空波段逻辑均未独立达标');
      }
    }

    const rawProb = Math.min(88, Math.max(30, 50 + (chosenScore - 50) * 0.76));

    return {
      candidateDirection,
      rawProb: Number(rawProb.toFixed(1)),
      score: Math.min(100, Math.max(0, Math.round(chosenScore))),
      keyFactors,
      rejectionReasons,
      timeframeRole,
      longPassed,
      shortPassed,
      primaryDriver,
    };
  }

  /**
   * 7. 1小时候选机会专属决策逻辑 (Trend structure & Momentum)
   * 独立多头趋势 vs 独立空头趋势
   */
  private evaluate1h(
    snapshot: MarketSnapshot,
    regime: EnhancedMarketRegime
  ): {
    candidateDirection: 'UP' | 'DOWN';
    rawProb: number;
    score: number;
    keyFactors: string[];
    rejectionReasons: string[];
    timeframeRole: string;
    longPassed: boolean;
    shortPassed: boolean;
    primaryDriver: string;
  } {
    const { indicators, multiTimeframe } = snapshot;
    const timeframeRole = '中周期趋势结构共振 (1h Trend Momentum)';

    const ema7 = indicators.ema7;
    const ema20 = indicators.ema20;
    const ema50 = indicators.ema50;
    const macdHist = indicators.macd.histogram;
    const rsi = indicators.rsi;
    const hasConflict = multiTimeframe?.hasConflict || false;

    // Independent 1h LONG
    let longScore = 50;
    const longFactors: string[] = [];
    const longRejections: string[] = [];

    if (ema7 > ema20 && ema20 > ema50) {
      longScore += 24;
      longFactors.push('✓ 1h 周期 EMA7 > EMA20 > EMA50 完美多头排列');
    } else {
      longScore -= 20;
      longRejections.push('❌ 1h 均线系统未呈现EMA多头排列');
    }

    if (macdHist > 4) {
      longScore += 12;
      longFactors.push('✓ 1h MACD 动能柱多头放大');
    } else if (macdHist < 0) {
      longScore -= 18;
      longRejections.push('❌ 1h MACD 柱体处于零轴下方，多头动能不足');
    }

    if (rsi >= 50 && rsi <= 68) {
      longScore += 10;
      longFactors.push(`✓ 1h RSI (${rsi.toFixed(1)}) 处于健康多头扩张区间`);
    } else {
      longScore -= 15;
      longRejections.push(`❌ 1h RSI (${rsi.toFixed(1)}) 未在50-68健康多头区间`);
    }

    if (hasConflict) {
      longScore -= 28;
      longRejections.push(`❌ 多周期均线发生结构性逆势冲突 (${multiTimeframe?.conflictDescription})`);
    }

    const longPassed = longScore >= 80 && ema7 > ema20 && ema20 > ema50 && macdHist > 0 && !hasConflict && longRejections.length === 0;

    // Independent 1h SHORT
    let shortScore = 50;
    const shortFactors: string[] = [];
    const shortRejections: string[] = [];

    if (ema7 < ema20 && ema20 < ema50) {
      shortScore += 24;
      shortFactors.push('✓ 1h 周期 EMA7 < EMA20 < EMA50 完美空头排列');
    } else {
      shortScore -= 20;
      shortRejections.push('❌ 1h 均线系统未呈现EMA空头排列');
    }

    if (macdHist < -4) {
      shortScore += 12;
      shortFactors.push('✓ 1h MACD 动能柱空头放大');
    } else if (macdHist > 0) {
      shortScore -= 18;
      shortRejections.push('❌ 1h MACD 柱体处于零轴上方，空头动能不足');
    }

    if (rsi >= 32 && rsi <= 50) {
      shortScore += 10;
      shortFactors.push(`✓ 1h RSI (${rsi.toFixed(1)}) 处于健康空头扩张区间`);
    } else {
      shortScore -= 15;
      shortRejections.push(`❌ 1h RSI (${rsi.toFixed(1)}) 未在32-50健康空头区间`);
    }

    if (hasConflict) {
      shortScore -= 28;
      shortRejections.push(`❌ 多周期均线发生结构性逆势冲突 (${multiTimeframe?.conflictDescription})`);
    }

    const shortPassed = shortScore >= 80 && ema7 < ema20 && ema20 < ema50 && macdHist < 0 && !hasConflict && shortRejections.length === 0;

    let candidateDirection: 'UP' | 'DOWN';
    let chosenScore: number;
    let keyFactors: string[];
    let rejectionReasons: string[];
    let primaryDriver = '1h趋势通道';

    if (longPassed && !shortPassed) {
      candidateDirection = 'UP';
      chosenScore = longScore;
      keyFactors = longFactors;
      rejectionReasons = longRejections;
      primaryDriver = '1h宏观均线多头趋势通道 (EMA7>20>50)';
    } else if (shortPassed && !longPassed) {
      candidateDirection = 'DOWN';
      chosenScore = shortScore;
      keyFactors = shortFactors;
      rejectionReasons = shortRejections;
      primaryDriver = '1h宏观均线空头趋势通道 (EMA7<20<50)';
    } else {
      candidateDirection = longScore >= shortScore ? 'UP' : 'DOWN';
      chosenScore = Math.min(longScore, shortScore, 68);
      keyFactors = candidateDirection === 'UP' ? longFactors : shortFactors;
      rejectionReasons = [
        ...longRejections.slice(0, 2),
        ...shortRejections.slice(0, 2),
      ];
      if (rejectionReasons.length === 0) {
        rejectionReasons.push('❌ 1h趋势均线系统处于缠绕震荡，未形成单边趋势');
      }
    }

    const rawProb = Math.min(88, Math.max(30, 50 + (chosenScore - 50) * 0.76));

    return {
      candidateDirection,
      rawProb: Number(rawProb.toFixed(1)),
      score: Math.min(100, Math.max(0, Math.round(chosenScore))),
      keyFactors,
      rejectionReasons,
      timeframeRole,
      longPassed,
      shortPassed,
      primaryDriver,
    };
  }

  /**
   * 8. 1天候选机会专属决策逻辑 (Macro & Daily Trend)
   * 宏观单边日线通道
   */
  private evaluate1d(
    snapshot: MarketSnapshot,
    regime: EnhancedMarketRegime
  ): {
    candidateDirection: 'UP' | 'DOWN';
    rawProb: number;
    score: number;
    keyFactors: string[];
    rejectionReasons: string[];
    timeframeRole: string;
    longPassed: boolean;
    shortPassed: boolean;
    primaryDriver: string;
  } {
    const { indicators, price } = snapshot;
    const timeframeRole = '宏观日线结构与动量 (1d Macro Horizon)';

    // Independent 1d LONG
    let longScore = 50;
    const longFactors: string[] = [];
    const longRejections: string[] = [];

    if (price > indicators.ema50 && indicators.ema20 > indicators.ema50) {
      longScore += 26;
      longFactors.push('✓ 日线级别处于大周期多头通道上方');
    } else {
      longScore -= 20;
      longRejections.push('❌ 日线未处于明确大周期多头通道上方');
    }

    if (regime === 'HIGH_VOLATILITY') {
      longScore -= 30;
      longRejections.push('❌ 日线波动率异常偏高，存在假突破洗盘');
    }

    const longPassed = longScore >= 80 && price > indicators.ema50 && indicators.ema20 > indicators.ema50 && regime !== 'HIGH_VOLATILITY';

    // Independent 1d SHORT
    let shortScore = 50;
    const shortFactors: string[] = [];
    const shortRejections: string[] = [];

    if (price < indicators.ema50 && indicators.ema20 < indicators.ema50) {
      shortScore += 26;
      shortFactors.push('✓ 日线级别处于大周期空头通道下方');
    } else {
      shortScore -= 20;
      shortRejections.push('❌ 日线未处于明确大周期空头通道下方');
    }

    if (regime === 'HIGH_VOLATILITY') {
      shortScore -= 30;
      shortRejections.push('❌ 日线波动率异常偏高，存在假突破洗盘');
    }

    const shortPassed = shortScore >= 80 && price < indicators.ema50 && indicators.ema20 < indicators.ema50 && regime !== 'HIGH_VOLATILITY';

    let candidateDirection: 'UP' | 'DOWN';
    let chosenScore: number;
    let keyFactors: string[];
    let rejectionReasons: string[];
    let primaryDriver = '1d日线中枢';

    if (longPassed && !shortPassed) {
      candidateDirection = 'UP';
      chosenScore = longScore;
      keyFactors = longFactors;
      rejectionReasons = longRejections;
      primaryDriver = '1d大周期宏观多头通道突破';
    } else if (shortPassed && !longPassed) {
      candidateDirection = 'DOWN';
      chosenScore = shortScore;
      keyFactors = shortFactors;
      rejectionReasons = shortRejections;
      primaryDriver = '1d大周期宏观空头通道破位';
    } else {
      candidateDirection = longScore >= shortScore ? 'UP' : 'DOWN';
      chosenScore = Math.min(longScore, shortScore, 68);
      keyFactors = candidateDirection === 'UP' ? longFactors : shortFactors;
      rejectionReasons = [
        ...longRejections.slice(0, 2),
        ...shortRejections.slice(0, 2),
      ];
      if (rejectionReasons.length === 0) {
        rejectionReasons.push('❌ 日线处于大周期中枢中性震荡带');
      }
    }

    const rawProb = Math.min(88, Math.max(30, 50 + (chosenScore - 50) * 0.76));

    return {
      candidateDirection,
      rawProb: Number(rawProb.toFixed(1)),
      score: Math.min(100, Math.max(0, Math.round(chosenScore))),
      keyFactors,
      rejectionReasons,
      timeframeRole,
      longPassed,
      shortPassed,
      primaryDriver,
    };
  }

  /**
   * 动态门槛体系 (满足 Section 4 要求)
   */
  public getDynamicThresholds(regime: EnhancedMarketRegime): {
    minCalibratedProb: number;
    minEdge: number;
    minEv: number;
    minScore: number;
    requireStrongOrderFlow: boolean;
    pauseTrading: boolean;
    regimeDescription: string;
  } {
    switch (regime) {
      case 'TREND_UP':
      case 'TREND_DOWN':
      case 'BREAKOUT':
      case 'BREAKDOWN':
        return {
          minCalibratedProb: 78.0,
          minEdge: 5.0,
          minEv: 4.0,
          minScore: 84,
          requireStrongOrderFlow: true,
          pauseTrading: false,
          regimeDescription: '强趋势市场：门槛校准概率>=78%，Edge>=+5%，且必须具有强烈顺势订单流支持',
        };
      case 'REVERSAL':
        return {
          minCalibratedProb: 85.0,
          minEdge: 8.0,
          minEv: 8.0,
          minScore: 88,
          requireStrongOrderFlow: false,
          pauseTrading: false,
          regimeDescription: '震荡/潜在反转市场：门槛提高至校准概率>=85%，Edge>=+8%，防假突破',
        };
      case 'RANGE':
        return {
          minCalibratedProb: 85.0,
          minEdge: 8.0,
          minEv: 8.0,
          minScore: 88,
          requireStrongOrderFlow: false,
          pauseTrading: false,
          regimeDescription: '区间震荡市场：门槛提高至校准概率>=85%，Edge>=+8%，防震荡噪音',
        };
      case 'HIGH_VOLATILITY':
        return {
          minCalibratedProb: 88.0,
          minEdge: 10.0,
          minEv: 12.0,
          minScore: 92,
          requireStrongOrderFlow: true,
          pauseTrading: false,
          regimeDescription: '高波动剧烈洗盘市场：大幅抬升门槛至校准概率>=88%，Edge>=+10%，严防插针洗盘',
        };
      case 'CHAOTIC':
        return {
          minCalibratedProb: 99.0,
          minEdge: 25.0,
          minEv: 30.0,
          minScore: 99,
          requireStrongOrderFlow: true,
          pauseTrading: true,
          regimeDescription: '混乱/数据延迟市场：直接暂停全部开单，强制保持观望 WAIT',
        };
      case 'LOW_VOLATILITY':
      default:
        return {
          minCalibratedProb: 80.0,
          minEdge: 6.0,
          minEv: 5.0,
          minScore: 85,
          requireStrongOrderFlow: false,
          pauseTrading: false,
          regimeDescription: '普通市场：基准门槛校准概率>=80%，Edge>=+6%，EV>0',
        };
    }
  }

  /**
   * 9. 核心全市场机会池与综合过滤评估管道
   * 严格实现：
   * Candidate Generation
   * ↳ 1. 独立方向（Direction）判定
   * ↳ 2. 市场状态（Regime）与波动率过滤
   * ↳ 3. 追涨追空（Overextension）风险检测
   * ↳ 4. 多周期与 Order Flow（CVD/OFI/OrderBook/OI）验证
   * ↳ 5. 概率校准（Probability Calibration）
   * ↳ 6. 统计优势（Edge）与期望值（EV）计算
   * ↳ 7. 同源信号去重与高度相关性去相关过滤（De-correlation）
   * ↳ 8. Cooldown（冷却期）检测
   * ↳ 最终状态决定：仅有 [OPEN LONG] / [OPEN SHORT] / [WAIT]
   *
   * 核心原则：
   * 取消机械数量上限封顶。任何信号具备独立交易逻辑与不重叠 Edge、真实达标即可 OPEN！
   */
  public evaluateOpportunityPool(
    snapshots: Record<SymbolType, MarketSnapshot>,
    activeOrders: SignalOrder[],
    historicalOrders: SignalOrder[] = []
  ): OpportunityPoolResult {
    const now = Date.now();
    const symbols: SymbolType[] = ['BTCUSDT', 'ETHUSDT'];
    const durations: DurationType[] = ['10m', '30m', '1h', '1d'];

    // 1. Identify Market Regimes for each symbol
    const regimes: Record<SymbolType, { regime: EnhancedMarketRegime; label: string; details: string }> = {
      BTCUSDT: this.detectMarketRegime(snapshots?.BTCUSDT),
      ETHUSDT: this.detectMarketRegime(snapshots?.ETHUSDT),
    };

    // 2. Calculate rolling BTC-ETH Pearson correlation
    const btcEthCorrelation = this.calculateBtcEthCorrelation(
      snapshots?.BTCUSDT?.recentKlines || [],
      snapshots?.ETHUSDT?.recentKlines || []
    );

    const candidates: OpportunityCandidate[] = [];

    // 3. Phase 1: Generate all 8 candidates with timeframe-specific logic
    for (const sym of symbols) {
      const snap = snapshots?.[sym];
      if (!snap) continue;
      const regimeInfo = regimes[sym];
      const thresholds = this.getDynamicThresholds(regimeInfo.regime);

      for (const dur of durations) {
        let evalResult: {
          candidateDirection: 'UP' | 'DOWN';
          rawProb: number;
          score: number;
          keyFactors: string[];
          rejectionReasons: string[];
          timeframeRole: string;
          longPassed: boolean;
          shortPassed: boolean;
          primaryDriver: string;
        };

        if (dur === '10m') {
          evalResult = this.evaluate10m(snap, regimeInfo.regime);
        } else if (dur === '30m') {
          evalResult = this.evaluate30m(snap, regimeInfo.regime);
        } else if (dur === '1h') {
          evalResult = this.evaluate1h(snap, regimeInfo.regime);
        } else {
          evalResult = this.evaluate1d(snap, regimeInfo.regime);
        }

        const candidateDirection = evalResult.candidateDirection;

        // Overextension & Anti-chasing check
        const overextension = this.checkOverextension(
          snap.price,
          snap.indicators?.ema7 || snap.price,
          snap.indicators?.atr14 || 1,
          candidateDirection,
          snap.indicators?.rsi || 50
        );

        if (overextension.isOverextended && overextension.reason) {
          evalResult.rejectionReasons.push(`❌ ${overextension.reason}`);
        }

        // Probability calibration
        const calibratedProb = this.calibrateProbability(evalResult.rawProb);

        // Market implied probability & Break-even
        const payout = PAYOUT_RATIOS[dur];
        const marketProb = Number(((100 / (100 + payout * 100)) * 100).toFixed(2));

        // Statistical Edge & EV
        const edge = Number((calibratedProb - marketProb).toFixed(2));
        const ev = Number(
          (
            (calibratedProb / 100) * (100 * payout) -
            (1 - calibratedProb / 100) * 100
          ).toFixed(2)
        );

        // Historical sample stats from settled signals
        const matchingHistorical = historicalOrders.filter(
          (o) =>
            o.symbol === sym &&
            o.duration === dur &&
            o.direction === candidateDirection &&
            o.result !== 'PENDING'
        );
        const sampleCount = matchingHistorical.length;
        const wins = matchingHistorical.filter((o) => o.result === 'WIN').length;
        const actualWinRate =
          sampleCount >= 10 ? Number(((wins / sampleCount) * 100).toFixed(1)) : null;

        let confidenceLevel: 'HIGH' | 'MEDIUM' | 'LOW' | 'INSUFFICIENT' = 'INSUFFICIENT';
        if (sampleCount >= 60) confidenceLevel = 'HIGH';
        else if (sampleCount >= 25) confidenceLevel = 'MEDIUM';
        else if (sampleCount >= 10) confidenceLevel = 'LOW';

        // Calculate comprehensive Signal Score (0 - 100)
        let signalScore = evalResult.score;
        signalScore += edge * 0.8;
        if (overextension.isOverextended) {
          signalScore -= 30;
        }
        if (regimeInfo.regime === 'HIGH_VOLATILITY') {
          signalScore -= 20;
          evalResult.rejectionReasons.push('❌ 市场处于剧烈异常波动态，开单门槛强制收紧');
        } else if (regimeInfo.regime === 'CHAOTIC') {
          signalScore -= 40;
          evalResult.rejectionReasons.push('❌ 市场数据或盘口混乱混沌，强制空仓观望');
        }

        signalScore = Math.min(100, Math.max(0, Math.round(signalScore)));

        // Signal Strength Level
        let strengthLevel: SignalStrengthLevel = 'WAIT';
        if (signalScore >= 90) strengthLevel = 'VERY_STRONG';
        else if (signalScore >= 85) strengthLevel = 'STRONG';
        else if (signalScore >= 80) strengthLevel = 'VALID';
        else if (signalScore >= 70) strengthLevel = 'WEAK';
        else if (signalScore >= 60) strengthLevel = 'WATCH';
        else strengthLevel = 'WAIT';

        // Gate Checks against Dynamic Thresholds
        let canQualify = true;

        if (thresholds.pauseTrading) {
          canQualify = false;
          evalResult.rejectionReasons.push(`❌ ${thresholds.regimeDescription}`);
        }

        // Direction independent qualification check
        const isDirectionPassed =
          candidateDirection === 'UP' ? evalResult.longPassed : evalResult.shortPassed;
        if (!isDirectionPassed) {
          canQualify = false;
          evalResult.rejectionReasons.push(
            `❌ ${candidateDirection === 'UP' ? '买多' : '卖空'}独立判定条件未完全满足，严禁镜像伪开单`
          );
        }

        if (calibratedProb < thresholds.minCalibratedProb) {
          canQualify = false;
          evalResult.rejectionReasons.push(
            `❌ 模型校准胜率 (${calibratedProb}%) 未达当前市场(${regimeInfo.label})动态门槛 (>=${thresholds.minCalibratedProb}%)`
          );
        }

        if (edge < thresholds.minEdge) {
          canQualify = false;
          evalResult.rejectionReasons.push(
            `❌ 交易边际优势 Edge (${edge > 0 ? '+' : ''}${edge}%) 低于动态要求 (>=+${thresholds.minEdge}%)`
          );
        }

        if (ev <= 0 || ev < thresholds.minEv) {
          canQualify = false;
          evalResult.rejectionReasons.push(
            `❌ 理论期望值 EV ($${ev} USDT) 低于门槛 (需 EV > 0 且 >=+$${thresholds.minEv} USDT)`
          );
        }

        if (signalScore < thresholds.minScore) {
          canQualify = false;
          evalResult.rejectionReasons.push(
            `❌ 综合信号评分 (${signalScore}/100) 低于动态准入基准 (${thresholds.minScore}分)`
          );
        }

        if (thresholds.requireStrongOrderFlow) {
          const ofiVal = snap.rawOfi || 0;
          const cvdSlopeVal = snap.cvdSlope || 0;
          const hasStrongFlow =
            candidateDirection === 'UP'
              ? ofiVal > 5 && cvdSlopeVal > 2
              : ofiVal < -5 && cvdSlopeVal < -2;
          if (!hasStrongFlow) {
            canQualify = false;
            evalResult.rejectionReasons.push(
              `❌ 强趋势市场需极其强烈的 Order Flow 顺势支持 (当前 OFI: ${ofiVal.toFixed(1)}, CVD斜率: ${cvdSlopeVal.toFixed(1)})`
            );
          }
        }

        if (overextension.isOverextended) {
          canQualify = false;
        }

        const candidate: OpportunityCandidate = {
          id: `${sym}-${dur}`,
          symbol: sym,
          duration: dur,
          direction: canQualify ? candidateDirection : 'WAIT',
          candidateDirection,
          status: canQualify ? 'CONFIRMING' : 'WAIT',
          regime: regimeInfo.regime,
          regimeLabel: regimeInfo.label,
          rawProbability: evalResult.rawProb,
          calibratedProbability: calibratedProb,
          marketProbability: marketProb,
          edge,
          expectedValue: ev,
          signalScore,
          strengthLevel,
          rank: 0,
          timeframeRole: evalResult.timeframeRole,
          historicalSampleCount: sampleCount,
          historicalWinRate: actualWinRate,
          historicalConfidence: confidenceLevel,
          isOverextended: overextension.isOverextended,
          rejectionReasons: evalResult.rejectionReasons,
          keyFactors: evalResult.keyFactors,
          riskNotes: [
            overextension.isOverextended ? '存在过度延伸追单风险' : '波动率安全边际正常',
            `到期自动对比开仓价与结算价`,
          ],
          timestamp: now,
        };

        candidates.push(candidate);
      }
    }

    // 4. Phase 2: Signal Ranking (Sort all 8 candidates by Signal Score descending)
    const rankedOpportunities = [...candidates].sort((a, b) => b.signalScore - a.signalScore);
    rankedOpportunities.forEach((c, idx) => {
      c.rank = idx + 1;
    });

    // 5. Phase 3: Deduplication & Correlation Filter & Cooldown
    // 【核心原则】取消全市场或单币种的机械数量硬性封顶！
    // 实施严苛的“同源多周期去重”与“高相关性去相关过滤”：
    const qualifiedToOpen: OpportunityCandidate[] = [];

    // 记录已经获准开单的标的与方向驱动，用于检测同源
    const approvedDrivers: Array<{
      symbol: SymbolType;
      duration: DurationType;
      direction: 'UP' | 'DOWN';
      score: number;
      edge: number;
      ev: number;
      primaryDriver: string;
    }> = [];

    for (const cand of rankedOpportunities) {
      if (cand.status !== 'CONFIRMING') {
        continue;
      }

      // Check identical active order: Is there already an active order for this exact contract?
      const identicalActive = activeOrders.find(
        (o) =>
          o.symbol === cand.symbol &&
          o.duration === cand.duration &&
          o.direction === cand.candidateDirection &&
          (o.status === 'ACTIVE' || o.status === 'WAITING_ENTRY')
      );
      if (identicalActive) {
        cand.status = 'FILTERED';
        cand.filterReason = `该合约周期当前已有相同方向的活动订单在运行中 (${cand.symbol} ${cand.duration} ${cand.candidateDirection})`;
        cand.rejectionReasons.push(`❌ ${cand.filterReason}`);
        continue;
      }

      // 5.1 同源多周期去重 (Intra-symbol Multi-timeframe Deduplication)
      // 若同币种其他周期已经获准开单且方向相同，评估是否来自同一个市场驱动因素
      const sameSymbolApproved = approvedDrivers.find(
        (d) => d.symbol === cand.symbol && d.direction === cand.candidateDirection
      );
      if (sameSymbolApproved) {
        // 同币种同向已有一个更高评分周期通过。除非属于完全独立不重叠的底层驱动（如 10m 微观流动性吸收 vs 1d 宏观突破且不重叠），否则必须去重抑制！
        const isIndependentMicroVsMacro =
          (cand.duration === '10m' && sameSymbolApproved.duration === '1d') ||
          (cand.duration === '1d' && sameSymbolApproved.duration === '10m');

        if (!isIndependentMicroVsMacro) {
          cand.status = 'FILTERED';
          cand.filterReason = `[FILTERED_DUPLICATE] 同源多周期同向合并去重：已优选保留综合评分最高周期 (${sameSymbolApproved.duration}，评分 ${sameSymbolApproved.score})，防止机械同向加仓`;
          cand.rejectionReasons.push(`❌ ${cand.filterReason}`);
          continue;
        }
      }

      // 5.2 Cooldown 检测
      const cooldownLimit = COOLDOWN_MS[cand.duration];
      const recentSameSignals = historicalOrders
        .filter(
          (o) =>
            o.symbol === cand.symbol &&
            o.duration === cand.duration &&
            o.direction === cand.candidateDirection
        )
        .sort((a, b) => b.signalTime - a.signalTime);
      const lastSameSignal = recentSameSignals[0];
      if (lastSameSignal && now - lastSameSignal.signalTime < cooldownLimit) {
        const remainingCdMinutes = Math.ceil(
          (cooldownLimit - (now - lastSameSignal.signalTime)) / 60000
        );
        cand.status = 'FILTERED';
        cand.filterReason = `处于开单防抖冷却期 (还需冷却 ${remainingCdMinutes} 分钟)`;
        cand.rejectionReasons.push(`❌ ${cand.filterReason}`);
        continue;
      }

      // 5.3 多币种去重与高相关性去相关 (Cross-symbol Correlation Filter)
      // 若 BTC 与 ETH 高度相关 (> 0.70) 且同向看涨或同向看跌
      if (btcEthCorrelation > 0.70 && approvedDrivers.length > 0) {
        const otherAssetApproved = approvedDrivers.find(
          (d) => d.symbol !== cand.symbol && d.direction === cand.candidateDirection
        );
        if (otherAssetApproved) {
          // 比较两者的 Edge、EV 和综合评分
          // 除非当前候选具备完全独立的结构性超强行情（如 score >= 94 且 edge 极高），否则抑制次优标的
          const isOverwhelmingIndependentAlpha =
            cand.signalScore >= 94 && cand.edge >= otherAssetApproved.edge + 4;

          if (!isOverwhelmingIndependentAlpha) {
            cand.status = 'FILTERED';
            cand.filterReason = `[FILTERED_CORRELATION] BTC/ETH高相关性共振风控去重 (相关度: ${(btcEthCorrelation * 100).toFixed(0)}%)：已保留综合质量更优标的 (${otherAssetApproved.symbol} ${otherAssetApproved.duration})，避免重复暴露同一市场Beta`;
            cand.rejectionReasons.push(`❌ ${cand.filterReason}`);
            continue;
          }
        }
      }

      // 若全部通过：允许正式 OPEN！不设机械数量硬性封顶！
      cand.status = 'OPEN';
      cand.direction = cand.candidateDirection;
      qualifiedToOpen.push(cand);
      approvedDrivers.push({
        symbol: cand.symbol,
        duration: cand.duration,
        direction: cand.candidateDirection,
        score: cand.signalScore,
        edge: cand.edge,
        ev: cand.expectedValue,
        primaryDriver: cand.timeframeRole,
      });
    }

    const bestOpportunity = rankedOpportunities[0] || null;
    const secondOpportunity = rankedOpportunities[1] || null;

    let marketStatusSummary = '当前市场无高EV确定性统计优势，全市场处于严谨空仓观望态 (WAIT)';
    if (qualifiedToOpen.length > 0) {
      marketStatusSummary = `发现 ${qualifiedToOpen.length} 个高概率正期望机会：${qualifiedToOpen
        .map((c) => `${c.symbol} ${c.duration} ${c.candidateDirection === 'UP' ? '买涨' : '买跌'}`)
        .join('、')}，已获准开单`;
    }

    return {
      timestamp: now,
      regimes,
      btcEthCorrelation,
      candidates,
      rankedOpportunities,
      bestOpportunity,
      secondOpportunity,
      qualifiedSignalsToOpen: qualifiedToOpen,
      marketStatusSummary,
    };
  }

  /**
   * 将专属周期的候选机会转换为标准的 PredictionResult 结构
   * 确保每个周期的图表展示、胜率、指标与机会池保持严格真实与独立
   */
  public candidateToPredictionResult(
    candidate: OpportunityCandidate,
    snapshot: MarketSnapshot
  ): PredictionResult {
    const isWait = candidate.direction === 'WAIT';
    const upProb =
      candidate.candidateDirection === 'UP'
        ? candidate.calibratedProbability
        : Number((100 - candidate.calibratedProbability).toFixed(1));
    const downProb =
      candidate.candidateDirection === 'DOWN'
        ? candidate.calibratedProbability
        : Number((100 - candidate.calibratedProbability).toFixed(1));
    const waitProb = isWait
      ? Math.min(80, Math.max(30, Number((100 - candidate.calibratedProbability).toFixed(1))))
      : 10;

    return {
      symbol: candidate.symbol,
      duration: candidate.duration,
      timestamp: candidate.timestamp,
      referencePrice: snapshot.currentRound?.lockPrice || snapshot.price,
      indexPrice: snapshot.price,
      markPrice: snapshot.markPrice || snapshot.price,
      targetThreshold: 0,
      direction: candidate.direction,
      signalLevel:
        candidate.strengthLevel === 'VERY_STRONG' || candidate.strengthLevel === 'STRONG'
          ? 'STRONG'
          : candidate.strengthLevel === 'VALID'
          ? 'MODERATE'
          : candidate.strengthLevel === 'WEAK'
          ? 'WEAK'
          : 'WAIT',
      compositeScore: candidate.signalScore,
      confidence: Math.round(candidate.calibratedProbability),
      upProb,
      downProb,
      waitProb,
      breakEvenProb: candidate.marketProbability,
      payoutRatio: PAYOUT_RATIOS[candidate.duration],
      edge: candidate.edge,
      expectedValue: candidate.expectedValue,
      winProbability: candidate.calibratedProbability,
      regime: (snapshot.prediction?.regime as any) || 'RANGING',
      regimeLabel: candidate.regimeLabel,
      isWait,
      waitReasons: candidate.rejectionReasons,
      recommendedAction: isWait
        ? `处于空仓观望 (WAIT)：${candidate.filterReason || candidate.rejectionReasons[0] || '统计优势不足'}`
        : `高确定性信号 (${candidate.strengthLevel})：建议执行看${
            candidate.candidateDirection === 'UP' ? '涨' : '跌'
          }合约 (EV: +$${candidate.expectedValue}U, Edge: +${candidate.edge}%)`,
      rationale: candidate.keyFactors,
      factors: snapshot.prediction?.factors || ({} as any),
      multiTimeframe: snapshot.multiTimeframe,
      indicators: snapshot.indicators,
    };
  }

  /**
   * 针对单一标的快照，直接计算4个周期的独立专属预测结果
   * 杜绝机械复制，每个周期运行其专属的独立决策模型
   */
  public evaluateSymbolDurations(snapshot: MarketSnapshot): Record<DurationType, PredictionResult> {
    const durations: DurationType[] = ['10m', '30m', '1h', '1d'];
    const results = {} as Record<DurationType, PredictionResult>;
    const regimeInfo = this.detectMarketRegime(snapshot);
    const thresholds = this.getDynamicThresholds(regimeInfo.regime);

    for (const dur of durations) {
      let evalResult: {
        candidateDirection: 'UP' | 'DOWN';
        rawProb: number;
        score: number;
        keyFactors: string[];
        rejectionReasons: string[];
        timeframeRole: string;
        longPassed: boolean;
        shortPassed: boolean;
        primaryDriver: string;
      };

      if (dur === '10m') {
        evalResult = this.evaluate10m(snapshot, regimeInfo.regime);
      } else if (dur === '30m') {
        evalResult = this.evaluate30m(snapshot, regimeInfo.regime);
      } else if (dur === '1h') {
        evalResult = this.evaluate1h(snapshot, regimeInfo.regime);
      } else {
        evalResult = this.evaluate1d(snapshot, regimeInfo.regime);
      }

      const overextension = this.checkOverextension(
        snapshot.price,
        snapshot.indicators?.ema7 || snapshot.price,
        snapshot.indicators?.atr14 || 1,
        evalResult.candidateDirection,
        snapshot.indicators?.rsi || 50
      );

      if (overextension.isOverextended && overextension.reason) {
        evalResult.rejectionReasons.push(`❌ ${overextension.reason}`);
      }

      const calibratedProb = this.calibrateProbability(evalResult.rawProb);
      const payout = PAYOUT_RATIOS[dur];
      const marketProb = Number(((100 / (100 + payout * 100)) * 100).toFixed(2));
      const edge = Number((calibratedProb - marketProb).toFixed(2));
      const ev = Number(
        (
          (calibratedProb / 100) * (100 * payout) -
          (1 - calibratedProb / 100) * 100
        ).toFixed(2)
      );

      let signalScore = evalResult.score + edge * 0.8;
      if (overextension.isOverextended) signalScore -= 30;
      if (regimeInfo.regime === 'HIGH_VOLATILITY') signalScore -= 20;
      else if (regimeInfo.regime === 'CHAOTIC') signalScore -= 40;
      signalScore = Math.min(100, Math.max(0, Math.round(signalScore)));

      let strengthLevel: SignalStrengthLevel = 'WAIT';
      if (signalScore >= 90) strengthLevel = 'VERY_STRONG';
      else if (signalScore >= 85) strengthLevel = 'STRONG';
      else if (signalScore >= 80) strengthLevel = 'VALID';
      else if (signalScore >= 70) strengthLevel = 'WEAK';
      else if (signalScore >= 60) strengthLevel = 'WATCH';

      const isDirectionPassed =
        evalResult.candidateDirection === 'UP' ? evalResult.longPassed : evalResult.shortPassed;

      let canQualify =
        !thresholds.pauseTrading &&
        isDirectionPassed &&
        calibratedProb >= thresholds.minCalibratedProb &&
        edge >= thresholds.minEdge &&
        ev > 0 &&
        ev >= thresholds.minEv &&
        signalScore >= thresholds.minScore &&
        !overextension.isOverextended;

      const cand: OpportunityCandidate = {
        id: `${snapshot.symbol}-${dur}`,
        symbol: snapshot.symbol,
        duration: dur,
        direction: canQualify ? evalResult.candidateDirection : 'WAIT',
        candidateDirection: evalResult.candidateDirection,
        status: canQualify ? 'CONFIRMING' : 'WAIT',
        regime: regimeInfo.regime,
        regimeLabel: regimeInfo.label,
        rawProbability: evalResult.rawProb,
        calibratedProbability: calibratedProb,
        marketProbability: marketProb,
        edge,
        expectedValue: ev,
        signalScore,
        strengthLevel,
        rank: 0,
        timeframeRole: evalResult.timeframeRole,
        historicalSampleCount: 0,
        historicalWinRate: null,
        historicalConfidence: 'INSUFFICIENT',
        isOverextended: overextension.isOverextended,
        rejectionReasons: evalResult.rejectionReasons,
        keyFactors: evalResult.keyFactors,
        riskNotes: [
          overextension.isOverextended ? '存在过度延伸追单风险' : '波动率安全边际正常',
          '到期自动对比开仓价与结算价',
        ],
        timestamp: Date.now(),
      };

      results[dur] = this.candidateToPredictionResult(cand, snapshot);
    }

    return results;
  }
}

export const opportunityEngine = new OpportunityEngine();
