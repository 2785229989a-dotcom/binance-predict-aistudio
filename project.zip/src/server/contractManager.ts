import fs from 'fs';
import path from 'path';
import {
  DailySignalStats,
  DurationType,
  EventContractRound,
  KlineData,
  MarketRegime,
  OpportunityCandidate,
  PaperTrade,
  PredictionResult,
  SignalDirection,
  SignalLevel,
  SignalOrder,
  SignalOrderStats,
  SignalRecord,
  SymbolType,
} from '../types/market.js';
import { evaluateFormalTradeSignal } from './prediction.js';
import {
  signalDb,
  getShanghaiDateStr,
  getShanghaiDateCompact,
  getShanghaiTimeStr,
} from './database.js';
import { firestoreManager } from './firebaseStore.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const SIGNAL_ORDERS_FILE = path.join(DATA_DIR, 'signal_orders.json');
const PAPER_TRADES_FILE = path.join(DATA_DIR, 'paper_trades.json');

export class ContractManager {
  private activeRounds: Map<SymbolType, EventContractRound> = new Map();
  private roundHistory: EventContractRound[] = [];
  private trades: PaperTrade[] = [];
  private signalOrders: SignalOrder[] = [];
  private signalHistory: SignalRecord[] = [];
  private paperBalance: number = 10000;
  private lastEvaluationTime: Record<string, number> = {};
  private currentShanghaiDate: string = getShanghaiDateStr();
  private daySequence: Record<string, number> = {};

  constructor() {
    this.ensureDataDir();
    this.loadPersistedData();
    this.initRound('BTCUSDT', 88500);
    this.initRound('ETHUSDT', 2950);
  }

  private ensureDataDir() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
    } catch (err) {
      console.warn('[ContractManager] Failed to create data dir:', err);
    }
  }

  private loadPersistedData() {
    try {
      if (fs.existsSync(SIGNAL_ORDERS_FILE)) {
        const raw = fs.readFileSync(SIGNAL_ORDERS_FILE, 'utf-8');
        this.signalOrders = JSON.parse(raw);
        // Cleanse and migrate any historical TIE status to WIN / LOSS per rules:
        // UP: Expiry > Entry -> WIN, else LOSS
        // DOWN: Expiry < Entry -> WIN, else LOSS
        let migratedCount = 0;
        for (const o of this.signalOrders) {
          const time = o.signalTime || o.createdAt || Date.now();
          if (!o.date) {
            o.date = getShanghaiDateStr(time);
          }
          const compact = o.date.replace(/-/g, '');
          // Keep count of sequence IDs
          if (o.signalId && o.signalId.startsWith(`SIG-${compact}-`)) {
            const parts = o.signalId.split('-');
            const num = parseInt(parts[2], 10);
            if (!isNaN(num) && num > (this.daySequence[compact] || 0)) {
              this.daySequence[compact] = num;
            }
          }

          if ((o.result as string) === 'TIE' || (o.outcome as string) === 'TIE') {
            const entry = o.entryPriceIndex || o.signalPrice || 0;
            const expiry = o.expiryPriceIndex || entry;
            const diff = expiry - entry;
            o.result = (o.direction === 'UP' ? diff > 0 : diff < 0) ? 'WIN' : 'LOSS';
            o.outcome = o.result;
            o.resultDetail = o.result === 'WIN' ? '预测正确' : '预测错误';
            migratedCount++;
          }
        }
        if (migratedCount > 0) {
          this.persistSignalOrders();
          console.log(`[ContractManager] 已将 ${migratedCount} 条历史平盘记录重构为严格 WIN/LOSS`);
        }
        console.log(`[ContractManager] 已从持久化存储恢复 ${this.signalOrders.length} 条历史信号订单`);
      }
    } catch (err) {
      console.warn('[ContractManager] Failed to load signal orders from disk:', err);
      this.signalOrders = [];
    }

    // 初始化 SQLite 数据库
    signalDb.init().then(() => {
      console.log(`[ContractManager] SQLite 数据库已连接就绪 (当前北京日期: ${this.currentShanghaiDate})`);
    }).catch((err) => {
      console.warn('[ContractManager] SQLite init error:', err);
    });

    // 接入 Firebase Firestore 托管云数据库 (跨环境、跨设备永久保存)
    firestoreManager.testConnection().then(async (ok) => {
      if (ok) {
        console.log('[ContractManager] 正在从 Firestore 云端数据库全量加载历史持久化信号...');
        const cloudSignals = await firestoreManager.loadAllSignals();
        if (cloudSignals.length > 0) {
          const { added, updated } = this.mergeIncomingSignals(cloudSignals);
          console.log(`[ContractManager] 从 Firestore 成功恢复 ${cloudSignals.length} 条云端永久信号订单 (新增 ${added}, 更新 ${updated})`);
        }
        // 将本地所有有效历史信号备份至云端 Firestore
        for (const localOrder of this.signalOrders) {
          firestoreManager.saveSignal(localOrder).catch(() => {});
        }
        // 开启 Firestore 全球实时监听订阅
        firestoreManager.subscribeToSignals((remoteSignals) => {
          this.mergeIncomingSignals(remoteSignals);
        });
      }
    }).catch((err) => {
      console.warn('[ContractManager] Firestore cloud sync error:', err);
    });

    try {
      if (fs.existsSync(PAPER_TRADES_FILE)) {
        const raw = fs.readFileSync(PAPER_TRADES_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          this.trades = parsed;
        } else if (parsed.trades) {
          this.trades = parsed.trades;
          if (parsed.balance !== undefined) {
            this.paperBalance = parsed.balance;
          }
        }
        console.log(`[ContractManager] 已从持久化存储恢复 ${this.trades.length} 条模拟资金订单 (余额: $${this.paperBalance})`);
      }
    } catch (err) {
      console.warn('[ContractManager] Failed to load trades from disk:', err);
    }
  }

  private persistSignalOrders() {
    try {
      this.ensureDataDir();
      fs.writeFileSync(SIGNAL_ORDERS_FILE, JSON.stringify(this.signalOrders.slice(0, 1000), null, 2), 'utf-8');
    } catch (err) {
      console.warn('[ContractManager] Failed to persist signal orders:', err);
    }
  }

  private persistTrades() {
    try {
      this.ensureDataDir();
      fs.writeFileSync(
        PAPER_TRADES_FILE,
        JSON.stringify({ trades: this.trades.slice(0, 500), balance: this.paperBalance }, null, 2),
        'utf-8'
      );
    } catch (err) {
      console.warn('[ContractManager] Failed to persist trades:', err);
    }
  }

  private initRound(symbol: SymbolType, currentPrice: number) {
    const now = Date.now();
    const duration = 600 * 1000;
    const roundNumber = Math.floor(now / duration);
    const startTime = roundNumber * duration;
    const lockTime = startTime;
    const expiryTime = startTime + duration;

    const round: EventContractRound = {
      roundId: `${symbol}-${roundNumber}`,
      symbol,
      roundNumber,
      startTime,
      lockTime,
      expiryTime,
      durationSeconds: 600,
      lockPrice: currentPrice,
      currentPrice,
      settlementPrice: null,
      status: 'OPEN',
      outcome: null,
      upOdds: 1.88,
      downOdds: 1.95,
    };
    this.activeRounds.set(symbol, round);
  }

  public getDurationMs(duration: DurationType = '10m'): number {
    switch (duration) {
      case '30s':
        return 30 * 1000;
      case '3m':
        return 3 * 60 * 1000;
      case '5m':
        return 5 * 60 * 1000;
      case '10m':
        return 10 * 60 * 1000;
      case '15m':
        return 15 * 60 * 1000;
      case '30m':
        return 30 * 60 * 1000;
      case '1h':
        return 60 * 60 * 1000;
      case '4h':
        return 4 * 60 * 60 * 1000;
      case '1d':
        return 24 * 60 * 60 * 1000;
      default:
        return 10 * 60 * 1000;
    }
  }

  /**
   * 多端与多节点中心化同步：安全合并来自对等节点、远程云端或客户端的信号订单
   */
  public mergeIncomingSignals(incoming: SignalOrder[]): { added: number; updated: number } {
    if (!Array.isArray(incoming) || incoming.length === 0) {
      return { added: 0, updated: 0 };
    }

    let added = 0;
    let updated = 0;

    for (const inOrder of incoming) {
      if (!inOrder || !inOrder.signalId) continue;
      const existingIdx = this.signalOrders.findIndex((o) => o.signalId === inOrder.signalId);
      if (existingIdx >= 0) {
        const existing = this.signalOrders[existingIdx];
        let hasChanges = false;
        // 如果对端或云端已有确立好的开仓点位或已结算结果，合并最新状态
        if (
          (existing.status === 'WAITING_ENTRY' && inOrder.status !== 'WAITING_ENTRY') ||
          (existing.status === 'ACTIVE' && inOrder.status === 'SETTLED') ||
          (!existing.entryPriceIndex && inOrder.entryPriceIndex) ||
          (!existing.expiryPriceIndex && inOrder.expiryPriceIndex)
        ) {
          this.signalOrders[existingIdx] = { ...existing, ...inOrder };
          hasChanges = true;
          updated++;
        }
      } else {
        // 新信号订单
        this.signalOrders.push(inOrder);
        const compact = inOrder.date?.replace(/-/g, '') || '';
        if (compact && inOrder.signalId.startsWith(`SIG-${compact}-`)) {
          const num = parseInt(inOrder.signalId.split('-')[2], 10);
          if (!isNaN(num) && num > (this.daySequence[compact] || 0)) {
            this.daySequence[compact] = num;
          }
        }
        added++;
      }
    }

    if (added > 0 || updated > 0) {
      this.signalOrders.sort((a, b) => (b.signalTime || 0) - (a.signalTime || 0));
      this.persistSignalOrders();
      for (const order of incoming) {
        signalDb.saveSignal(order).catch((err: any) =>
          console.warn('[ContractManager] SQLite merge error:', err)
        );
      }
    }

    return { added, updated };
  }

  /**
   * 从全市场机会池通过严格多级过滤与去重引擎的优质候选生成正式信号订单
   */
  public createOrderFromOpportunity(
    cand: OpportunityCandidate,
    currentPrice: number,
    pred?: PredictionResult
  ): SignalOrder | null {
    if (!cand || cand.status !== 'OPEN' || cand.direction === 'WAIT' || currentPrice <= 0) {
      return null;
    }

    const now = Date.now();

    // 1. 杜绝同一标的同一周期同一方向重复开单 (取消全市场或单币种机械硬性数量封顶)
    const identicalActive = this.signalOrders.find(
      (o) =>
        o.symbol === cand.symbol &&
        o.duration === cand.duration &&
        o.direction === cand.candidateDirection &&
        (o.status === 'ACTIVE' || o.status === 'WAITING_ENTRY')
    );
    if (identicalActive) {
      return null;
    }

    const durationMs = this.getDurationMs(cand.duration);
    const signalTime = now;
    const entryTime = signalTime;
    const expiryTime = entryTime + durationMs;
    const dateCompact = getShanghaiDateCompact(now);
    const dateStr = getShanghaiDateStr(now);
    this.daySequence[dateCompact] = (this.daySequence[dateCompact] || 0) + 1;
    const seqStr = String(this.daySequence[dateCompact]).padStart(4, '0');
    const signalId = `SIG-${dateCompact}-${seqStr}`;

    const newOrder: SignalOrder = {
      signalId,
      id: signalId,
      date: dateStr,
      symbol: cand.symbol,
      duration: cand.duration,
      direction: cand.candidateDirection,
      signalTime,
      timestamp: signalTime,
      signalPrice: currentPrice,
      referencePrice: currentPrice,
      modelProb: cand.calibratedProbability,
      rawProb: cand.rawProbability,
      calibratedProb: cand.calibratedProbability,
      marketProb: cand.marketProbability,
      strengthLevel: cand.strengthLevel,
      timeframeRole: cand.timeframeRole,
      historicalSampleCount: cand.historicalSampleCount,
      historicalConfidence: cand.historicalConfidence,
      upProb: cand.candidateDirection === 'UP' ? cand.calibratedProbability : Number((100 - cand.calibratedProbability).toFixed(1)),
      downProb: cand.candidateDirection === 'DOWN' ? cand.calibratedProbability : Number((100 - cand.calibratedProbability).toFixed(1)),
      waitProb: 8,
      payoutRatio: cand.duration === '10m' ? 0.8 : 0.85,
      breakEvenProb: cand.marketProbability,
      edge: cand.edge,
      expectedValue: cand.expectedValue,
      entryTime,
      entryPriceIndex: currentPrice,
      expiryTime,
      settlementTime: expiryTime,
      expiryPriceIndex: null,
      priceChange: null,
      status: 'ACTIVE',
      result: 'PENDING',
      outcome: 'PENDING',
      resultDetail: '市场机会池择优开单中，等待到期自动结算',
      rationale: cand.keyFactors,
      factorsSummary: cand.keyFactors.slice(0, 3).join('；'),
      score: cand.signalScore,
      confirmations: cand.keyFactors,
      riskNotes: cand.riskNotes,
      signalStrength: cand.signalScore,
      isFormalSignal: true,
      marketSnapshotAtSignal: {
        ofi: pred?.factors?.ofi?.value || 0,
        cvd: pred?.factors?.cvd?.value || 0,
        depthImbalance: pred?.factors?.depth?.imbalanceRatio || 0.5,
        rsi: pred?.indicators?.rsi || 50,
        atr: pred?.indicators?.atr14 || 0,
        spread: pred?.factors?.depth?.skewRatio || 0,
        regime: cand.regimeLabel || '正常',
      },
      createdAt: signalTime,
    };

    this.signalOrders.unshift(newOrder);
    if (this.signalOrders.length > 1000) {
      this.signalOrders.pop();
    }
    this.persistSignalOrders();
    signalDb.saveSignal(newOrder).catch((err) => {
      console.warn('[Database] Failed to write signal to SQLite:', err);
    });
    // 异步同步至外部 Firebase Firestore 云数据库 (永久安全存储，关闭网页也绝不丢失)
    firestoreManager.saveSignal(newOrder).catch(() => {});
    console.log(
      `[ContractManager] ★★★ 机会池择优正式产生开单信号 ${newOrder.signalId}: ${cand.symbol} ${cand.duration} ${newOrder.direction} 评分=${cand.signalScore} 校准胜率=${cand.calibratedProbability}% Entry=$${currentPrice} (已入库持久化 & 云端备份)`
    );
    return newOrder;
  }

  /**
   * 自动创建信号订单 (Signal Order Lifecycle)
   * 只要模型输出符合条件的有效开单信号 (非 WAIT 且具有正期望优势)：
   * 自动进入完整的信号订单生命周期：
   * 1. WAITING_ENTRY: 等待 T+1s
   * 2. ACTIVE: 确立 Entry Price Index，进入倒计时
   * 3. SETTLED: 到期获取 Expiry Price Index 判定胜负平 (WIN/LOSS/TIE)
   */
  public evaluateAndCreateSignalOrder(
    symbol: SymbolType,
    duration: DurationType,
    pred: PredictionResult,
    currentPrice: number
  ): SignalOrder | null {
    if (!pred || pred.direction === 'WAIT' || currentPrice <= 0) {
      return null;
    }

    const now = Date.now();

    // 1. 同币种去重：同一标的任何周期已有正在进行的订单，绝不重复生成多周期重叠单！
    const existingActive = this.signalOrders.find(
      (o) => o.symbol === symbol && (o.status === 'ACTIVE' || o.status === 'WAITING_ENTRY')
    );
    if (existingActive) {
      return null;
    }

    // 2. 冷却防抖：同一标的，至少等待 3 分钟才能产生下一笔新开单信号
    const sameSymbolOrders = this.signalOrders
      .filter((o) => o.symbol === symbol)
      .sort((a, b) => b.signalTime - a.signalTime);
    const lastCreated = sameSymbolOrders[0];
    if (lastCreated && now - lastCreated.signalTime < 180000) {
      return null;
    }

    // 3. 严格执行 8 大硬性开单门槛校验 (Hard Gates)
    // 宁缺毋滥，唯有同时满足全部条件才允许产生开单信号！
    const check = evaluateFormalTradeSignal(pred, symbol, duration);
    if (!check.isQualified) {
      return null; // 未通过硬性门槛，策略强制空仓保护，绝不强行生成信号！
    }

    const durationMs = this.getDurationMs(duration);
    const signalTime = now;
    const entryTime = signalTime; // 信号产生的瞬间立即真实锁定 Entry Price！绝不事后篡改！
    const expiryTime = entryTime + durationMs;
    const dateCompact = getShanghaiDateCompact(now);
    const dateStr = getShanghaiDateStr(now);
    this.daySequence[dateCompact] = (this.daySequence[dateCompact] || 0) + 1;
    const seqStr = String(this.daySequence[dateCompact]).padStart(4, '0');
    const signalId = `SIG-${dateCompact}-${seqStr}`;
    const modelProb = pred.direction === 'UP' ? pred.upProb : pred.downProb;

    const newOrder: SignalOrder = {
      signalId,
      id: signalId,
      date: dateStr,
      symbol,
      duration,
      direction: pred.direction,
      signalTime,
      timestamp: signalTime,
      signalPrice: currentPrice,
      referencePrice: currentPrice,
      modelProb,
      upProb: pred.upProb,
      downProb: pred.downProb,
      waitProb: pred.waitProb,
      payoutRatio: pred.payoutRatio ?? (duration === '10m' ? 0.8 : 0.85),
      breakEvenProb: pred.breakEvenProb ?? 55.56,
      edge: pred.edge ?? 0,
      expectedValue: pred.expectedValue ?? 0,
      entryTime,
      entryPriceIndex: currentPrice, // 真实实时开仓价，立即锁定！
      expiryTime,
      settlementTime: expiryTime,
      expiryPriceIndex: null,
      priceChange: null,
      status: 'ACTIVE',
      result: 'PENDING',
      outcome: 'PENDING',
      resultDetail: '正式开单执行中，等待到期自动结算',
      rationale: pred.rationale || [],
      factorsSummary: check.confirmations.slice(0, 3).join('；'),
      score: check.score,
      confirmations: check.confirmations,
      riskNotes: check.riskNotes,
      signalStrength: check.signalStrength,
      isFormalSignal: true,
      marketSnapshotAtSignal: {
        ofi: pred.factors?.ofi?.value || 0,
        cvd: pred.factors?.cvd?.value || 0,
        depthImbalance: pred.factors?.depth?.imbalanceRatio || 0.5,
        rsi: pred.indicators?.rsi || 50,
        atr: pred.indicators?.atr14 || 0,
        spread: pred.factors?.depth?.skewRatio || 0,
        regime: pred.regimeLabel || '正常',
      },
      createdAt: signalTime,
    };

    this.signalOrders.unshift(newOrder);
    // 保持最多 1000 条真实历史信号订单
    if (this.signalOrders.length > 1000) {
      this.signalOrders.pop();
    }

    this.persistSignalOrders();
    // 立即持久化写入 SQLite
    signalDb.saveSignal(newOrder).catch((err) => {
      console.warn('[Database] Failed to write signal to SQLite:', err);
    });
    console.log(
      `[ContractManager] ★★★ 正式产生高置信度开单信号 ${newOrder.signalId}: ${symbol} ${duration} ${newOrder.direction} 概率=${modelProb}% Entry=$${currentPrice} (已入库持久化)`
    );

    return newOrder;
  }

  /**
   * 1秒级时钟驱动：
   * 1. 处理 WAITING_ENTRY 订单到达 T+1s，确立锁定 entryPriceIndex
   * 2. 处理 ACTIVE 订单到达 expiryTime，以真实 Expiry Price Index 判定 WIN/LOSS/TIE
   */
  public tickSignalOrders(currentPrices: Record<SymbolType, number>): {
    entered: SignalOrder[];
    settled: SignalOrder[];
    dailyReset: boolean;
    currentShanghaiDate: string;
  } {
    const now = Date.now();
    const entered: SignalOrder[] = [];
    const settled: SignalOrder[] = [];
    let stateChanged = false;

    // 检查北京时间跨越自然日 00:00:00 自动日结重置当日统计
    const todayShanghai = getShanghaiDateStr(now);
    let dailyReset = false;
    if (todayShanghai !== this.currentShanghaiDate) {
      console.log(
        `[ContractManager] ★★★ 跨越北京时间 00:00:00 自然日切换: ${this.currentShanghaiDate} -> ${todayShanghai}，当日统计计数器归零重置，历史数据永久安全归档！`
      );
      this.currentShanghaiDate = todayShanghai;
      dailyReset = true;
    }

    for (const order of this.signalOrders) {
      // 1. T+1秒开仓锁定
      if (order.status === 'WAITING_ENTRY' && now >= order.entryTime) {
        const livePrice = currentPrices[order.symbol] || order.signalPrice;
        order.entryPriceIndex = livePrice;
        order.referencePrice = livePrice;
        order.status = 'ACTIVE';
        order.resultDetail = '进行中，等待到期自动结算';
        entered.push(order);
        stateChanged = true;
        // 同步至 SQLite 与外部云数据库 Firestore
        signalDb.saveSignal(order).catch(() => {});
        firestoreManager.saveSignal(order).catch(() => {});
        console.log(
          `[ContractManager] 信号订单锁定开仓价 ${order.signalId} (${order.symbol} ${order.duration}): Entry Price Index = $${livePrice.toFixed(2)}`
        );
      }

      // 2. 到期自动判定结算
      if (order.status === 'ACTIVE' && now >= order.expiryTime) {
        const expiryPrice = currentPrices[order.symbol] || order.entryPriceIndex || order.signalPrice;
        order.expiryPriceIndex = expiryPrice;
        order.settlementPrice = expiryPrice;

        const entry = order.entryPriceIndex || order.signalPrice;
        const diff = Number((expiryPrice - entry).toFixed(4));
        order.priceChange = diff;

        // 严谨二元结算规则：
        // 买涨（UP）：到期结算价 > 开仓价 判定为 WIN，否则 <= 开仓价 判定为 LOSS
        // 买跌（DOWN）：到期结算价 < 开仓价 判定为 WIN，否则 >= 开仓价 判定为 LOSS
        if (order.direction === 'UP') {
          order.result = diff > 0 ? 'WIN' : 'LOSS';
        } else {
          order.result = diff < 0 ? 'WIN' : 'LOSS';
        }

        order.outcome = order.result;
        order.status = 'SETTLED';
        order.settledAt = now;
        order.resultDetail = order.result === 'WIN' ? '预测正确' : '预测错误';

        settled.push(order);
        stateChanged = true;

        // 立即写入 SQLite 与外部云数据库 Firestore 持久化
        signalDb.settleSignal(order.signalId, expiryPrice, order.result, now).catch((err) => {
          console.warn('[Database] Failed to settle signal in SQLite:', err);
        });
        firestoreManager.saveSignal(order).catch(() => {});
        firestoreManager.saveDailyStats(this.getTodayStats()).catch(() => {});

        console.log(
          `[ContractManager] 信号订单自动结算 ${order.signalId} (${order.symbol} ${order.duration} ${order.direction}): Entry=${entry} Expiry=${expiryPrice} 结果=${order.result} (${order.resultDetail})`
        );

        // 如果有关联的模拟资金订单，同步结算
        if (order.simulatedTradeId) {
          const trade = this.trades.find((t) => t.id === order.simulatedTradeId);
          if (trade && trade.status === 'ACTIVE') {
            trade.settlementPrice = expiryPrice;
            trade.settledAt = now;
            trade.result = order.result;
            const pRatio = trade.payoutRatio ?? order.payoutRatio;

            if (order.result === 'WIN') {
              trade.status = 'WON';
              trade.pnl = Number((trade.stake * pRatio).toFixed(2));
              trade.payout = Number((trade.stake * (1 + pRatio)).toFixed(2));
              this.paperBalance += trade.payout;
            } else {
              trade.status = 'LOST';
              trade.pnl = -trade.stake;
              trade.payout = 0;
            }
          }
        }
      }
    }

    if (stateChanged) {
      this.persistSignalOrders();
      if (settled.some((s) => s.simulatedTradeId)) {
        this.persistTrades();
      }
    }

    return { entered, settled, dailyReset, currentShanghaiDate: this.currentShanghaiDate };
  }

  /**
   * 更新模拟资金订单与合约轮次
   */
  public updatePriceAndTick(
    symbol: SymbolType,
    currentPrice: number,
    upOdds: number = 1.9,
    downOdds: number = 1.9
  ) {
    const round = this.activeRounds.get(symbol);
    if (!round) return;

    round.currentPrice = currentPrice;
    round.upOdds = upOdds;
    round.downOdds = downOdds;

    const now = Date.now();

    // 检查独立模拟资金订单
    let tradesChanged = false;
    this.trades.forEach((trade) => {
      if (trade.symbol === symbol && trade.status === 'PENDING_OPEN' && trade.openTime && now >= trade.openTime) {
        trade.entryPrice = currentPrice;
        trade.strikePrice = currentPrice;
        trade.status = 'ACTIVE';
        tradesChanged = true;
      }
    });

    this.trades.forEach((trade) => {
      if (trade.symbol === symbol && trade.status === 'ACTIVE' && trade.expiryTime && now >= trade.expiryTime) {
        trade.settlementPrice = currentPrice;
        trade.settledAt = now;
        const entry = trade.entryPrice || trade.strikePrice;
        const diff = Number((currentPrice - entry).toFixed(4));
        const pRatio = trade.payoutRatio ?? (trade.odds ? trade.odds - 1 : 0.8);

        if (trade.direction === 'UP') {
          trade.result = diff >= 0 ? 'WIN' : 'LOSS';
        } else {
          trade.result = diff <= 0 ? 'WIN' : 'LOSS';
        }

        if (trade.result === 'WIN') {
          trade.status = 'WON';
          trade.payout = Number((trade.stake * (1 + pRatio)).toFixed(2));
          trade.pnl = Number((trade.stake * pRatio).toFixed(2));
          this.paperBalance += trade.payout;
        } else {
          trade.status = 'LOST';
          trade.payout = 0;
          trade.pnl = -trade.stake;
        }
        tradesChanged = true;
      }
    });

    if (tradesChanged) {
      this.persistTrades();
    }

    if (now >= round.expiryTime) {
      this.settleRound(symbol, currentPrice);
    }
  }

  private settleRound(symbol: SymbolType, finalPrice: number) {
    const round = this.activeRounds.get(symbol);
    if (!round) return;

    round.status = 'SETTLED';
    round.settlementPrice = finalPrice;

    if (finalPrice > round.lockPrice) {
      round.outcome = 'UP';
    } else if (finalPrice < round.lockPrice) {
      round.outcome = 'DOWN';
    } else {
      round.outcome = 'FLAT';
    }

    this.roundHistory.unshift({ ...round });
    if (this.roundHistory.length > 50) {
      this.roundHistory.pop();
    }

    const now = Date.now();
    const duration = 600 * 1000;
    const nextRoundNumber = round.roundNumber + 1;
    const startTime = now;
    const expiryTime = startTime + duration;

    const newRound: EventContractRound = {
      roundId: `${symbol}-${nextRoundNumber}`,
      symbol,
      roundNumber: nextRoundNumber,
      startTime,
      lockTime: startTime,
      expiryTime,
      durationSeconds: 600,
      lockPrice: finalPrice,
      currentPrice: finalPrice,
      settlementPrice: null,
      status: 'OPEN',
      outcome: null,
      upOdds: round.upOdds,
      downOdds: round.downOdds,
    };
    this.activeRounds.set(symbol, newRound);
  }

  /**
   * 用户主动点击模拟下单 (Simulated Trade)
   * 关联当前有效 Signal Order (如有)
   */
  public placePaperTrade(
    symbol: SymbolType,
    direction: 'UP' | 'DOWN',
    stake: number,
    duration: DurationType = '10m',
    customPayoutRatio?: number,
    modelProb: number = 50,
    currentPriceIndex?: number,
    linkedSignalId?: string
  ): { success: boolean; trade?: PaperTrade; message: string; balance: number } {
    if (stake < 5) {
      return { success: false, message: '事件合约最低下单金额为 5 USDT', balance: this.paperBalance };
    }
    if (this.paperBalance < stake) {
      return { success: false, message: '模拟账户余额不足', balance: this.paperBalance };
    }

    const round = this.activeRounds.get(symbol);
    if (!round) {
      return { success: false, message: '未找到当前活动合约周期', balance: this.paperBalance };
    }

    this.paperBalance -= stake;

    const now = Date.now();
    const durationMs = this.getDurationMs(duration);

    const payoutRatio =
      customPayoutRatio !== undefined
        ? customPayoutRatio
        : duration === '10m'
        ? 0.8
        : 0.85;

    const breakEvenProb = Number(((100 / (100 + payoutRatio * 100)) * 100).toFixed(2));
    const edge = Number((modelProb - breakEvenProb).toFixed(2));
    const winProfit = stake * payoutRatio;
    const loss = stake;
    const expectedValue = Number(
      ((modelProb / 100) * winProfit - ((100 - modelProb) / 100) * loss).toFixed(2)
    );

    const openTime = now + 1000;
    const expiryTime = openTime + durationMs;
    const provisionalPrice = currentPriceIndex || round.currentPrice;

    // 寻找或关联当前活跃的信号订单
    let activeSig = linkedSignalId
      ? this.signalOrders.find((s) => s.signalId === linkedSignalId)
      : this.signalOrders.find(
          (s) =>
            s.symbol === symbol &&
            s.duration === duration &&
            (s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY')
        );

    const tradeId = `trade-${now}-${Math.random().toString(36).slice(2, 8)}`;
    const trade: PaperTrade = {
      id: tradeId,
      roundId: `${symbol}-${duration}-${Math.floor(openTime / 60000)}`,
      symbol,
      duration,
      timestamp: now,
      signalTime: activeSig?.signalTime || now,
      orderTime: now,
      openTime,
      expiryTime,
      direction,
      stake,
      entryPrice: provisionalPrice,
      strikePrice: provisionalPrice,
      settlementPrice: null,
      payoutRatio,
      odds: Number((1 + payoutRatio).toFixed(2)),
      status: 'PENDING_OPEN',
      result: 'PENDING',
      pnl: 0,
      payout: 0,
      modelProbAtEntry: modelProb,
      breakEvenProb,
      edge,
      expectedValue,
    };

    if (activeSig && !activeSig.simulatedTradeId) {
      activeSig.simulatedTradeId = tradeId;
      this.persistSignalOrders();
    }

    this.trades.unshift(trade);
    this.persistTrades();

    const dirZh = direction === 'UP' ? '买涨 (UP)' : '买跌 (DOWN)';
    const durZh =
      duration === '10m'
        ? '10分钟'
        : duration === '30m'
        ? '30分钟'
        : duration === '1h'
        ? '1小时'
        : '1天';

    return {
      success: true,
      trade,
      message: `成功下单: [模拟交易] ${symbol} ${durZh} ${dirZh} $${stake} (赔率 ${(payoutRatio * 100).toFixed(0)}%, 下一秒T+1s正式确立Entry)`,
      balance: this.paperBalance,
    };
  }

  /**
   * 获取当前有效进行中的信号订单 (按 Symbol 与 Duration)
   */
  public getActiveSignalOrders(): SignalOrder[] {
    return this.signalOrders.filter((s) => s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY');
  }

  /**
   * 获取历史信号订单
   */
  public getSignalOrders(): SignalOrder[] {
    return this.signalOrders;
  }

  /**
   * 汇总模型信号统计指标 (总信号、WIN、LOSS、TIE、总胜率、各维度胜率)
   * 规则：总胜率 = WIN / (WIN + LOSS) * 100 (TIE 独立统计，不计入胜负分母)
   */
  public getSignalOrderStats(): SignalOrderStats {
    const totalSignals = this.signalOrders.length;
    const active = this.signalOrders.filter((s) => s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY');
    const settled = this.signalOrders.filter((s) => s.status === 'SETTLED');

    const wins = settled.filter((s) => s.result === 'WIN').length;
    const losses = settled.filter((s) => s.result === 'LOSS').length;
    const ties = 0;
    const winRate = wins + losses > 0 ? Number(((wins / (wins + losses)) * 100).toFixed(2)) : 0;

    const calcWinRate = (w: number, l: number) =>
      w + l > 0 ? Number(((w / (w + l)) * 100).toFixed(2)) : 0;

    // UP & DOWN
    const upSettled = settled.filter((s) => s.direction === 'UP');
    const upWins = upSettled.filter((s) => s.result === 'WIN').length;
    const upLosses = upSettled.filter((s) => s.result === 'LOSS').length;
    const upTies = 0;

    const downSettled = settled.filter((s) => s.direction === 'DOWN');
    const downWins = downSettled.filter((s) => s.result === 'WIN').length;
    const downLosses = downSettled.filter((s) => s.result === 'LOSS').length;
    const downTies = 0;

    // BTC & ETH
    const btcSettled = settled.filter((s) => s.symbol === 'BTCUSDT');
    const btcWins = btcSettled.filter((s) => s.result === 'WIN').length;
    const btcLosses = btcSettled.filter((s) => s.result === 'LOSS').length;
    const btcTies = 0;

    const ethSettled = settled.filter((s) => s.symbol === 'ETHUSDT');
    const ethWins = ethSettled.filter((s) => s.result === 'WIN').length;
    const ethLosses = ethSettled.filter((s) => s.result === 'LOSS').length;
    const ethTies = 0;

    // Durations (all 9 event contract periods)
    const durKeys: DurationType[] = ['30s', '3m', '5m', '10m', '15m', '30m', '1h', '4h', '1d'];
    const durationStats: Record<
      DurationType,
      { total: number; wins: number; losses: number; ties: number; winRate: number }
    > = {
      '30s': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '3m': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '5m': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '10m': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '15m': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '30m': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '1h': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '4h': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
      '1d': { total: 0, wins: 0, losses: 0, ties: 0, winRate: 0 },
    };

    durKeys.forEach((d) => {
      const dOrders = this.signalOrders.filter((s) => s.duration === d);
      const dSettled = dOrders.filter((s) => s.status === 'SETTLED');
      const dWins = dSettled.filter((s) => s.result === 'WIN').length;
      const dLosses = dSettled.filter((s) => s.result === 'LOSS').length;
      const dTies = 0;
      durationStats[d] = {
        total: dOrders.length,
        wins: dWins,
        losses: dLosses,
        ties: dTies,
        winRate: calcWinRate(dWins, dLosses),
      };
    });

    return {
      totalSignals,
      activeCount: active.length,
      settledCount: settled.length,
      wins,
      losses,
      ties,
      winRate,
      upWins,
      upLosses,
      upTies,
      upWinRate: calcWinRate(upWins, upLosses),
      downWins,
      downLosses,
      downTies,
      downWinRate: calcWinRate(downWins, downLosses),
      btcWins,
      btcLosses,
      btcTies,
      btcWinRate: calcWinRate(btcWins, btcLosses),
      ethWins,
      ethLosses,
      ethTies,
      ethWinRate: calcWinRate(ethWins, ethLosses),
      durationStats,
    };
  }

  /**
   * 获取当前北京时间对应自然日 (YYYY-MM-DD)
   */
  public getCurrentShanghaiDate(): string {
    return this.currentShanghaiDate;
  }

  /**
   * 获取今日 (Asia/Shanghai) 真实统计数据（00:00 每日自动重置）
   */
  public getTodayStats(): DailySignalStats {
    const today = this.currentShanghaiDate;
    const todayOrders = this.signalOrders.filter(
      (s) => (s.date || getShanghaiDateStr(s.signalTime || s.createdAt)) === today
    );
    const total = todayOrders.length;
    const pending = todayOrders.filter(
      (s) => s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY' || s.result === 'PENDING'
    ).length;
    const settled = todayOrders.filter((s) => s.status === 'SETTLED');
    const wins = settled.filter((s) => s.result === 'WIN').length;
    const losses = settled.filter((s) => s.result === 'LOSS').length;
    const winRate = wins + losses > 0 ? Number(((wins / (wins + losses)) * 100).toFixed(2)) : 0;

    const upSettled = settled.filter((s) => s.direction === 'UP');
    const upWins = upSettled.filter((s) => s.result === 'WIN').length;
    const upLosses = upSettled.filter((s) => s.result === 'LOSS').length;
    const upWinRate = upWins + upLosses > 0 ? Number(((upWins / (upWins + upLosses)) * 100).toFixed(2)) : 0;

    const downSettled = settled.filter((s) => s.direction === 'DOWN');
    const downWins = downSettled.filter((s) => s.result === 'WIN').length;
    const downLosses = downSettled.filter((s) => s.result === 'LOSS').length;
    const downWinRate = downWins + downLosses > 0 ? Number(((downWins / (downWins + downLosses)) * 100).toFixed(2)) : 0;

    return {
      date: today,
      total_signals: total,
      pending,
      wins,
      losses,
      win_rate: winRate,
      up_signals: todayOrders.filter((s) => s.direction === 'UP').length,
      up_wins: upWins,
      up_losses: upLosses,
      up_win_rate: upWinRate,
      down_signals: todayOrders.filter((s) => s.direction === 'DOWN').length,
      down_wins: downWins,
      down_losses: downLosses,
      down_win_rate: downWinRate,
      btc_signals: todayOrders.filter((s) => s.symbol === 'BTCUSDT').length,
      eth_signals: todayOrders.filter((s) => s.symbol === 'ETHUSDT').length,
    };
  }

  /**
   * 获取今日真实产生的所有 Signal Orders
   */
  public getTodaySignals(): SignalOrder[] {
    return this.getSignalsByDate(this.currentShanghaiDate);
  }

  /**
   * 获取历史每日统计归档 (按北京时间自然日倒序，每日独立统计)
   */
  public getAllDailyArchives(): DailySignalStats[] {
    const map: Record<string, SignalOrder[]> = {};
    for (const s of this.signalOrders) {
      const d = s.date || getShanghaiDateStr(s.signalTime || s.createdAt);
      if (!map[d]) map[d] = [];
      map[d].push(s);
    }
    // 确保今日自然日永远存在，即使今日暂无信号产生
    if (!map[this.currentShanghaiDate]) {
      map[this.currentShanghaiDate] = [];
    }

    const dates = Object.keys(map).sort((a, b) => b.localeCompare(a));
    return dates.map((dateStr) => {
      const orders = map[dateStr];
      const total = orders.length;
      const pending = orders.filter(
        (s) => s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY' || s.result === 'PENDING'
      ).length;
      const settled = orders.filter((s) => s.status === 'SETTLED');
      const wins = settled.filter((s) => s.result === 'WIN').length;
      const losses = settled.filter((s) => s.result === 'LOSS').length;
      const winRate = wins + losses > 0 ? Number(((wins / (wins + losses)) * 100).toFixed(2)) : 0;

      const upSettled = settled.filter((s) => s.direction === 'UP');
      const upWins = upSettled.filter((s) => s.result === 'WIN').length;
      const upLosses = upSettled.filter((s) => s.result === 'LOSS').length;
      const upWinRate = upWins + upLosses > 0 ? Number(((upWins / (upWins + upLosses)) * 100).toFixed(2)) : 0;

      const downSettled = settled.filter((s) => s.direction === 'DOWN');
      const downWins = downSettled.filter((s) => s.result === 'WIN').length;
      const downLosses = downSettled.filter((s) => s.result === 'LOSS').length;
      const downWinRate = downWins + downLosses > 0 ? Number(((downWins / (downWins + downLosses)) * 100).toFixed(2)) : 0;

      return {
        date: dateStr,
        total_signals: total,
        pending,
        wins,
        losses,
        win_rate: winRate,
        up_signals: orders.filter((s) => s.direction === 'UP').length,
        up_wins: upWins,
        up_losses: upLosses,
        up_win_rate: upWinRate,
        down_signals: orders.filter((s) => s.direction === 'DOWN').length,
        down_wins: downWins,
        down_losses: downLosses,
        down_win_rate: downWinRate,
        btc_signals: orders.filter((s) => s.symbol === 'BTCUSDT').length,
        eth_signals: orders.filter((s) => s.symbol === 'ETHUSDT').length,
      };
    });
  }

  /**
   * 按北京时间日期查询当天的所有真实 Signal ID 订单
   */
  public getSignalsByDate(dateStr: string): SignalOrder[] {
    return this.signalOrders.filter(
      (s) => (s.date || getShanghaiDateStr(s.signalTime || s.createdAt)) === dateStr
    );
  }

  // 兼容老接口
  public recordSignal(
    symbol: SymbolType,
    direction: SignalDirection,
    signalLevel: SignalLevel,
    score: number,
    confidence: number,
    upProb: number,
    downProb: number,
    waitProb: number,
    referencePrice: number,
    regime: MarketRegime,
    factorsSummary: string,
    marketSnapshotAtSignal: any
  ) {
    const now = Date.now();
    const newSig: SignalRecord = {
      id: `sig-${now}-${symbol}`,
      timestamp: now,
      symbol,
      direction,
      signalLevel,
      referencePrice,
      upProb,
      downProb,
      waitProb,
      confidence,
      score,
      regime,
      settlementTime: now + 600 * 1000,
      settlementPrice: null,
      priceChange: null,
      outcome: direction === 'WAIT' ? 'WAIT_SKIPPED' : 'PENDING',
      pnl: null,
      factorsSummary,
      marketSnapshotAtSignal,
    };

    this.signalHistory.unshift(newSig);
    if (this.signalHistory.length > 200) {
      this.signalHistory.pop();
    }
  }

  public getActiveRound(symbol: SymbolType): EventContractRound {
    return this.activeRounds.get(symbol)!;
  }

  public getRoundHistory(): EventContractRound[] {
    return this.roundHistory;
  }

  public getTrades(): PaperTrade[] {
    return this.trades;
  }

  public getSignalHistory(): SignalRecord[] {
    return this.signalHistory;
  }

  public getPaperBalance(): number {
    return this.paperBalance;
  }

  public resetPaperTrading(initialBalance: number = 10000) {
    this.paperBalance = initialBalance;
    this.trades = [];
    this.persistTrades();
  }

  /**
   * 清零重置所有历史交易与信号订单记录
   */
  public async clearAllRecords(): Promise<void> {
    this.signalOrders = [];
    this.trades = [];
    this.signalHistory = [];
    this.daySequence = {};
    this.paperBalance = 10000;
    this.persistSignalOrders();
    this.persistTrades();
    await signalDb.clearAllSignals();
    console.log('[ContractManager] ★★★ 历史交易与信号记录已全部清零重置完毕！');
  }
}
