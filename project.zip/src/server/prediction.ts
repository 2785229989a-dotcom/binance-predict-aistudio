import {
  DurationType,
  FactorBreakdown,
  MarketRegime,
  MarketSnapshot,
  MultiTimeframeAnalysis,
  OrderBookData,
  PredictionResult,
  SignalDirection,
  SignalLevel,
  SymbolType,
  TechnicalIndicators,
} from '../types/market.js';
import { opportunityEngine } from './opportunityEngine.js';

export interface ComputePredictionInput {
  symbol: SymbolType;
  duration?: DurationType;
  price: number;
  indexPrice?: number; // Official Binance Price Index
  markPrice?: number;
  referencePrice?: number; // Entry reference price P0
  targetThreshold?: number;
  orderBook: OrderBookData;
  rawOfi: number;
  cvdSlope: number;
  cvd5mChange: number;
  openInterest: number;
  oiChange24h: number;
  priceChangePercent: number;
  fundingRate: number;
  longShortRatio: number | null;
  indicators: TechnicalIndicators;
  microstructure?: any;
  multiTimeframe: MultiTimeframeAnalysis;
  latencyMs?: number;
  customPayoutRatio?: number;
  userOdds?: { up: number; down: number };
}

// Default Binance Event Contracts Payout Ratios for all 9 durations
export const DEFAULT_PAYOUT_RATIOS: Record<DurationType, number> = {
  '30s': 0.75, // 75% Payout -> Break-even: 57.14%
  '3m': 0.78,  // 78% Payout -> Break-even: 56.18%
  '5m': 0.80,  // 80% Payout -> Break-even: 55.56%
  '10m': 0.80, // 80% Payout -> Break-even: 55.56%
  '15m': 0.82, // 82% Payout -> Break-even: 54.95%
  '30m': 0.85, // 85% Payout -> Break-even: 54.05%
  '1h': 0.85,  // 85% Payout -> Break-even: 54.05%
  '4h': 0.85,  // 85% Payout -> Break-even: 54.05%
  '1d': 0.85,  // 85% Payout -> Break-even: 54.05%
};

export function computePrediction(input: ComputePredictionInput): PredictionResult {
  const {
    symbol,
    duration = '10m',
    price,
    indexPrice,
    markPrice,
    orderBook,
    rawOfi,
    cvdSlope,
    cvd5mChange,
    openInterest,
    oiChange24h,
    priceChangePercent,
    fundingRate,
    longShortRatio,
    indicators,
    multiTimeframe,
    latencyMs = 50,
    customPayoutRatio,
  } = input;

  const waitReasons: string[] = [];
  const rationale: string[] = [];

  // ================= 1. Payout & Break-even Probability =================
  const payoutRatio = customPayoutRatio ?? DEFAULT_PAYOUT_RATIOS[duration];
  // Break-even Prob = Loss / (Loss + WinProfit) = 100 / (100 + payoutRatio * 100) * 100
  const breakEvenProb = Number(((100 / (100 + payoutRatio * 100)) * 100).toFixed(2));

  // ================= 2. Market Regime & Risk Identification =================
  let regime: MarketRegime = 'RANGING';
  let regimeLabel = '震荡盘整 (RANGING)';

  const atrRatio = price > 0 ? (indicators.atr14 / price) * 100 : 0;
  // Dynamic volatility thresholds based on duration
  const maxAtrRatio = duration === '1d' ? 1.8 : duration === '1h' ? 0.9 : 0.45;
  const isHighVolatility = atrRatio > maxAtrRatio || indicators.bollinger.bandwidth > 1.2;

  // Realistic liquidity threshold (Top 20 bids+asks depth)
  const minBookDepth = symbol === 'BTCUSDT' ? 0.8 : 4.0;
  const isLowLiquidity =
    orderBook.spreadPercent > 0.08 || orderBook.bidTotal + orderBook.askTotal < minBookDepth;
  const isDataDelay = latencyMs > 3000;

  if (isDataDelay) {
    regime = 'DATA_DELAY';
    regimeLabel = '数据延迟异常 (DATA DELAY)';
    waitReasons.push(`市场数据延迟高达 ${latencyMs}ms，超出安全阈值(3000ms)，触发强制保护`);
  } else if (isLowLiquidity) {
    regime = 'LOW_LIQUIDITY';
    regimeLabel = '盘口流动性匮乏 (LOW LIQUIDITY)';
    waitReasons.push(`盘口深度不足(买卖总量 < ${minBookDepth})或点差 ${orderBook.spreadPercent.toFixed(3)}% 偏大`);
  } else if (isHighVolatility) {
    regime = 'HIGH_VOLATILITY';
    regimeLabel = '剧烈异常波动 (HIGH VOLATILITY)';
    waitReasons.push(`短周期波动率超标 (ATR比例 ${atrRatio.toFixed(3)}%)，布林带极限开口，容易出现假突破`);
  } else if (Math.abs(multiTimeframe.alignmentScore) >= 45) {
    if (multiTimeframe.alignmentScore > 0) {
      regime = 'TRENDING_UP';
      regimeLabel = '多周期共振看涨 (TRENDING UP)';
    } else {
      regime = 'TRENDING_DOWN';
      regimeLabel = '多周期共振看跌 (TRENDING DOWN)';
    }
  } else {
    regime = 'RANGING';
    regimeLabel = '窄幅区间震荡 (RANGING)';
  }

  // ================= 3. Duration-Specific Factor Weights =================
  // 10m is microstructure-heavy; 30m/1h is trend-heavy; 1d is macro/funding-heavy
  let weights = {
    ofi: 0.25,
    cvd: 0.25,
    depth: 0.20,
    momentum: 0.15,
    multiTf: 0.10,
    oi: 0.03,
    funding: 0.02,
  };

  if (duration === '30m') {
    weights = { ofi: 0.15, cvd: 0.20, depth: 0.15, momentum: 0.20, multiTf: 0.20, oi: 0.05, funding: 0.05 };
  } else if (duration === '1h') {
    weights = { ofi: 0.10, cvd: 0.15, depth: 0.10, momentum: 0.25, multiTf: 0.25, oi: 0.08, funding: 0.07 };
  } else if (duration === '1d') {
    weights = { ofi: 0.05, cvd: 0.10, depth: 0.05, momentum: 0.25, multiTf: 0.35, oi: 0.10, funding: 0.10 };
  }

  // Factor Scores
  const ofiScale = symbol === 'BTCUSDT' ? 4.0 : 30.0;
  const ofiScore = Math.round(Math.max(-100, Math.min(100, (rawOfi / ofiScale) * 100)));

  const cvdScale = symbol === 'BTCUSDT' ? 12.0 : 80.0;
  const cvdScore = Math.round(Math.max(-100, Math.min(100, (cvd5mChange / cvdScale) * 50 + cvdSlope * 50)));

  const totalDepth = orderBook.bidTotal + orderBook.askTotal;
  const imbalance = totalDepth > 0 ? (orderBook.bidTotal - orderBook.askTotal) / totalDepth : 0;
  const depthScore = Math.round(Math.max(-100, Math.min(100, imbalance * 150)));

  const rsiScore = (indicators.rsi - 50) * 2;
  const emaDiffPercent = indicators.ema20 > 0 ? ((indicators.ema7 - indicators.ema20) / indicators.ema20) * 1000 : 0;
  const macdScore = indicators.macd.histogram * (symbol === 'BTCUSDT' ? 4 : 18);
  const momentumScore = Math.round(
    Math.max(-100, Math.min(100, rsiScore * 0.45 + emaDiffPercent * 25 + macdScore * 0.3))
  );

  const multiTfScore = multiTimeframe.alignmentScore;

  let oiScore = 0;
  let oiCorrelationText = '持仓量平稳';
  if (priceChangePercent > 0.05 && oiChange24h > 0.5) {
    oiScore = 60;
    oiCorrelationText = '量价齐升 (多头主动建仓)';
  } else if (priceChangePercent < -0.05 && oiChange24h > 0.5) {
    oiScore = -60;
    oiCorrelationText = '空头放量施压 (空头主动建仓)';
  } else if (priceChangePercent > 0.05 && oiChange24h < -0.5) {
    oiScore = 25;
    oiCorrelationText = '空头减仓反弹 (轧空平仓)';
  } else if (priceChangePercent < -0.05 && oiChange24h < -0.5) {
    oiScore = -25;
    oiCorrelationText = '多头止损踩踏 (多头平仓)';
  } else {
    oiScore = Math.round(Math.max(-40, Math.min(40, oiChange24h * 10)));
  }

  let fundingScore = 0;
  const fundingPct = fundingRate * 100;
  if (fundingPct > 0.05) fundingScore = -35;
  else if (fundingPct < -0.01) fundingScore = 40;
  else if (fundingPct > 0.01) fundingScore = 15;

  const compositeRaw =
    ofiScore * weights.ofi +
    cvdScore * weights.cvd +
    depthScore * weights.depth +
    momentumScore * weights.momentum +
    multiTfScore * weights.multiTf +
    oiScore * weights.oi +
    fundingScore * weights.funding;

  const compositeScore = Math.round(Math.max(-100, Math.min(100, compositeRaw)));

  // ================= 4. Probability Calibration =================
  // Sigmoid probability distribution centered at 50%
  const sigmoid = (x: number) => 1 / (1 + Math.exp(-x / 20));
  let baseProb = sigmoid(compositeScore) * 100;

  let rawUpProb = Number(Math.min(88, Math.max(12, baseProb)).toFixed(1));
  let rawDownProb = Number((100 - rawUpProb).toFixed(1));

  // Determine potential direction and win probability
  const potentialDirection: SignalDirection =
    compositeScore >= 15 ? 'UP' : compositeScore <= -15 ? 'DOWN' : 'WAIT';

  const modelProb = potentialDirection === 'UP' ? rawUpProb : potentialDirection === 'DOWN' ? rawDownProb : 50;

  // Expected Value (EV) calculation per 100 USDT stake:
  // EV = (P * WinProfit) - ((1 - P) * Loss)
  // WinProfit = 100 * payoutRatio; Loss = 100
  const winProfit = 100 * payoutRatio;
  const lossAmount = 100;
  const expectedValue = Number(
    ((modelProb / 100) * winProfit - (1 - modelProb / 100) * lossAmount).toFixed(2)
  );
  const edge = Number((modelProb - breakEvenProb).toFixed(2));

  // ================= 5. Strict Conflict & WAIT Filters =================
  // Filter 1: EV <= 0 or Edge <= 0
  if (expectedValue <= 0 || edge <= 0) {
    waitReasons.push(
      `模型胜率(${modelProb}%) 未达到盈亏平衡线(${breakEvenProb}%)，期望值 EV=${expectedValue} USDT，缺乏统计胜算优势`
    );
  }

  // Filter 2: Multi-timeframe trend conflict
  if (multiTimeframe.hasConflict) {
    waitReasons.push(multiTimeframe.conflictDescription || '多周期均线方向发生严重分歧，禁止逆大周期盲目开单');
  }

  // Filter 3: Microstructure conflict (OFI vs CVD divergence on 10m/30m)
  if (duration === '10m' || duration === '30m') {
    const isOfiCvdDivergent =
      (ofiScore > 25 && cvdScore < -20) || (ofiScore < -25 && cvdScore > 20);
    if (isOfiCvdDivergent) {
      waitReasons.push('微观结构背离：OFI盘口挂单与CVD主动吃单方向相反，存在托单诱盘嫌疑');
    }
  }

  // Filter 4: Low liquidity / Extreme volatility / Data delay
  if (isDataDelay || isLowLiquidity || isHighVolatility) {
    // already pushed in regime section
  }

  // Final Direction Decision
  let direction: SignalDirection = 'WAIT';
  let signalLevel: SignalLevel = 'WAIT';
  let upProb = rawUpProb;
  let downProb = rawDownProb;
  let waitProb = 0;
  let confidence = 50;

  if (waitReasons.length > 0 || potentialDirection === 'WAIT') {
    direction = 'WAIT';
    signalLevel = 'WAIT';
    waitProb = Math.min(85, Math.max(55, 50 + waitReasons.length * 10));
    const remainder = 100 - waitProb;
    upProb = Number(((rawUpProb / 100) * remainder).toFixed(1));
    downProb = Number((remainder - upProb).toFixed(1));
    confidence = Math.max(30, Math.min(58, 50 - waitReasons.length * 5));
  } else {
    direction = potentialDirection;
    waitProb = 12;
    const remainder = 100 - waitProb;
    upProb = Number(((rawUpProb / 100) * remainder).toFixed(1));
    downProb = Number((remainder - upProb).toFixed(1));
    signalLevel = edge >= 8 ? 'STRONG' : edge >= 3 ? 'MODERATE' : 'WEAK';
    confidence = Math.min(95, Math.max(62, Math.round(55 + edge * 2.5)));
  }

  // Rationale Generation
  if (Math.abs(ofiScore) > 20) {
    rationale.push(
      ofiScore > 0
        ? `OFI订单流失衡呈现强势净买入(+${ofiScore}分)，盘口买一档持续增量补充`
        : `OFI订单流失衡呈现被动卖压(-${Math.abs(ofiScore)}分)，盘口卖一档压制显著`
    );
  }
  if (Math.abs(cvdScore) > 20) {
    rationale.push(
      cvdScore > 0
        ? `CVD主动买量增量斜率陡峭上扬(+${cvdScore}分)，市价吃单主导多方突破`
        : `CVD主动卖单加速释放(-${Math.abs(cvdScore)}分)，空方主动吃单力度强劲`
    );
  }
  if (Math.abs(depthScore) > 20) {
    const bidPct = Math.round((orderBook.bidTotal / (totalDepth || 1)) * 100);
    rationale.push(
      depthScore > 0
        ? `L2前20档挂单深度买盘占优(买方占比 ${bidPct}%)，下方托单坚挺`
        : `L2前20档挂单深度卖盘压顶(卖方占比 ${100 - bidPct}%)，上方阻力密集`
    );
  }
  if (multiTimeframe.alignmentText) {
    rationale.push(`多周期协同分析：${multiTimeframe.alignmentText}`);
  }
  if (expectedValue > 0) {
    rationale.push(`理论期望值满足正期望 (EV: +$${expectedValue}, Edge: +${edge}%)`);
  }
  if (rationale.length === 0) {
    rationale.push('多空双方动能胶着震荡，未形成显著的确定性失衡');
  }

  let recommendedAction = '';
  if (direction === 'UP') {
    recommendedAction = `多头信号共振：模型概率 ${upProb}% 超过盈亏平衡点 ${breakEvenProb}% (Edge: +${edge}%, EV: +$${expectedValue})，建议执行看涨合约 (UP)`;
  } else if (direction === 'DOWN') {
    recommendedAction = `空头信号共振：模型概率 ${downProb}% 超过盈亏平衡点 ${breakEvenProb}% (Edge: +${edge}%, EV: +$${expectedValue})，建议执行看跌合约 (DOWN)`;
  } else {
    recommendedAction = `当前处于 WAIT 状态：暂无满足交易条件的信号 (${waitReasons[0] || '期望值或胜率优势不足'})`;
  }

  const factors: FactorBreakdown = {
    ofi: {
      score: ofiScore,
      weight: weights.ofi,
      value: Number(rawOfi.toFixed(3)),
      label: ofiScore > 20 ? '买方订单流显著' : ofiScore < -20 ? '卖方订单流强势' : '中性均衡',
    },
    cvd: {
      score: cvdScore,
      weight: weights.cvd,
      value: Number(cvd5mChange.toFixed(2)),
      slope: Number(cvdSlope.toFixed(3)),
      label: cvdScore > 20 ? '主动买盘主导' : cvdScore < -20 ? '主动卖单倾泻' : '买卖拉锯',
    },
    depth: {
      score: depthScore,
      weight: weights.depth,
      imbalanceRatio: Number(orderBook.imbalanceRatio.toFixed(3)),
      skewRatio: Number((orderBook.bidTotal / (orderBook.askTotal || 0.001)).toFixed(2)),
      label: depthScore > 20 ? '买盘深度较厚' : depthScore < -20 ? '卖盘压单厚重' : '深度对称',
    },
    momentum: {
      score: momentumScore,
      weight: weights.momentum,
      rsi: Number(indicators.rsi.toFixed(1)),
      emaDiff: Number((indicators.ema7 - indicators.ema20).toFixed(2)),
      label: momentumScore > 20 ? '多头动量强势' : momentumScore < -20 ? '空头动量下破' : '动量震荡',
    },
    multiTf: {
      score: multiTfScore,
      weight: weights.multiTf,
      alignmentScore: multiTimeframe.alignmentScore,
      label: multiTimeframe.alignmentText,
    },
    oi: {
      score: oiScore,
      weight: weights.oi,
      openInterest: Number(openInterest.toFixed(2)),
      oiChange24h: Number(oiChange24h.toFixed(2)),
      priceCorrelation: oiCorrelationText,
      label: oiCorrelationText,
    },
    funding: {
      score: fundingScore,
      weight: weights.funding,
      rate: Number((fundingRate * 100).toFixed(4)),
      predictedRate: Number((fundingRate * 100).toFixed(4)),
      label:
        fundingPct > 0.03
          ? '多头费率偏高'
          : fundingPct < -0.01
          ? '空头费率过载'
          : '费率处于正常区间',
    },
    longShortRatio: {
      score: longShortRatio ? (longShortRatio > 1.2 ? 15 : longShortRatio < 0.8 ? -15 : 0) : 0,
      value: longShortRatio,
      label: longShortRatio ? `多空比 ${longShortRatio.toFixed(2)}` : '多空比获取中',
    },
  };

  const finalIndexPrice = indexPrice ?? price;
  const finalMarkPrice = markPrice ?? price;
  const finalRefPrice = input.referencePrice ?? finalIndexPrice;

  return {
    symbol,
    duration,
    timestamp: Date.now(),
    referencePrice: finalRefPrice, // Entry Price Index P0
    indexPrice: finalIndexPrice,
    markPrice: finalMarkPrice,
    targetThreshold: input.targetThreshold ?? 0,
    direction,
    signalLevel,
    compositeScore,
    confidence,
    upProb,
    downProb,
    waitProb,
    breakEvenProb,
    payoutRatio,
    edge,
    expectedValue,
    winProbability: Math.max(upProb, downProb),
    userOdds: input.userOdds ?? { up: 1.88, down: 1.95 },
    regime,
    regimeLabel,
    isWait: direction === 'WAIT',
    waitReasons,
    recommendedAction,
    rationale,
    factors,
    multiTimeframe,
    indicators,
  };
}

// Compute predictions for all 4 durations simultaneously with timeframe-specific engines
export function computeAllDurationPredictions(
  input: Omit<ComputePredictionInput, 'duration'>
): Record<DurationType, PredictionResult> {
  const durations: DurationType[] = ['10m', '30m', '1h', '1d'];
  const results = {} as Record<DurationType, PredictionResult>;

  const mockSnapshot: MarketSnapshot = {
    symbol: input.symbol,
    price: input.price,
    markPrice: input.markPrice || input.price,
    high24h: input.price * 1.02,
    low24h: input.price * 0.98,
    volume24h: 1000,
    priceChange24h: 0,
    priceChangePercent24h: input.priceChangePercent,
    orderBook: input.orderBook,
    recentKlines: (input as any).recentKlines || [],
    cvdHistory: [],
    currentCvd: 0,
    cvdSlope: input.cvdSlope,
    cvd5mChange: input.cvd5mChange,
    rawOfi: input.rawOfi,
    openInterest: input.openInterest,
    fundingRate: input.fundingRate,
    nextFundingTime: Date.now() + 14400000,
    longShortRatio: input.longShortRatio,
    prediction: {} as any,
    predictions: {} as any,
    currentRound: (input as any).currentRound,
    indicators: input.indicators,
    microstructure: input.microstructure,
    multiTimeframe: input.multiTimeframe,
    recentTrades: [],
    latencyMs: input.latencyMs || 50,
    lastUpdated: Date.now(),
    isRealData: true,
  };

  return opportunityEngine.evaluateSymbolDurations(mockSnapshot);
}

export interface FormalSignalCheckResult {
  isQualified: boolean;
  disqualifyReasons: string[];
  confirmations: string[];
  riskNotes: string[];
  score: number;
  signalStrength: number;
}

/**
 * 核心开单信号硬性检验 (Hard Gates)
 * 宁缺毋滥，唯有同时满足全部 8 大硬性门槛才允许产生正式开单信号，绝不为了凑数发单！
 */
export function evaluateFormalTradeSignal(
  pred: PredictionResult,
  symbol: SymbolType,
  duration: DurationType
): FormalSignalCheckResult {
  const disqualifyReasons: string[] = [];
  const confirmations: string[] = [];
  const riskNotes: string[] = [];

  // Gate 1: 必须有明确方向，拒绝 WAIT 态
  if (!pred || pred.direction === 'WAIT') {
    disqualifyReasons.push('策略模型处于风控观望状态(WAIT)，未探测到有效单边统计优势');
    return {
      isQualified: false,
      disqualifyReasons,
      confirmations: [],
      riskNotes: ['市场处于中性均衡或多空拉锯震荡期'],
      score: Math.abs(pred?.compositeScore || 0),
      signalStrength: 0,
    };
  }

  const modelProb = pred.direction === 'UP' ? pred.upProb : pred.downProb;

  // Gate 2: 严格高胜率概率门槛 (>= 75%) 与 低 WAIT 概率
  if (modelProb < 75.0) {
    disqualifyReasons.push(`模型概率 (${modelProb}%) 未达到硬性准入高阈值 (>=75.0%)`);
  }
  if (pred.waitProb > 20) {
    disqualifyReasons.push(`市场不确定性比例 (${pred.waitProb}%) 偏高，超过安全容忍线 (<=20%)`);
  }

  // Gate 3: 严格正期望优势 (Edge >= 10%, EV >= $10.0)
  if ((pred.edge ?? 0) < 10.0) {
    disqualifyReasons.push(`统计优势 Edge (${pred.edge}%) 未达到要求 (>=+10.0%)`);
  }
  if ((pred.expectedValue ?? 0) < 10.0) {
    disqualifyReasons.push(`单笔理论期望值 EV ($${pred.expectedValue} USDT) 未达及格线 (>=+10.0 USDT)`);
  }

  // Gate 4: 多周期趋势不能存在冲突，且需同向确认
  if (pred.multiTimeframe.hasConflict) {
    disqualifyReasons.push(pred.multiTimeframe.conflictDescription || '多周期均线趋势存在严重分歧，大周期逆风');
  } else {
    const isTfAligned =
      (pred.direction === 'UP' && pred.multiTimeframe.alignmentScore >= 15) ||
      (pred.direction === 'DOWN' && pred.multiTimeframe.alignmentScore <= -15);
    if (!isTfAligned) {
      disqualifyReasons.push('多周期协同未达到共振门槛，大周期方向未明确支持');
    }
  }

  // Gate 5: 微观盘口订单流 (OFI 与 CVD) 必须同向明确确认
  const ofiScore = pred.factors?.ofi?.score ?? 0;
  const cvdScore = pred.factors?.cvd?.score ?? 0;
  if (pred.direction === 'UP') {
    if (ofiScore < 10) {
      disqualifyReasons.push(`OFI 订单流买方失衡得分不足 (${ofiScore} 分 < 10 分)`);
    }
    if (cvdScore < 10) {
      disqualifyReasons.push(`CVD 主动买盘斜率未达到放量突破要求 (${cvdScore} 分 < 10 分)`);
    }
  } else {
    if (ofiScore > -10) {
      disqualifyReasons.push(`OFI 订单流卖方压迫得分不足 (${ofiScore} 分 > -10 分)`);
    }
    if (cvdScore > -10) {
      disqualifyReasons.push(`CVD 主动卖盘泄压未达到放量击穿要求 (${cvdScore} 分 > -10 分)`);
    }
  }

  // Gate 6: 严禁极端异常波动率或盘口枯竭
  if (pred.regime === 'HIGH_VOLATILITY') {
    disqualifyReasons.push('短周期波动率超标(ATR/布林带剧烈开口)，存在假突破洗盘风险');
  }
  if (pred.regime === 'LOW_LIQUIDITY') {
    disqualifyReasons.push('前20档挂单深度匮乏或盘口点差异常偏大');
  }
  if (pred.regime === 'DATA_DELAY') {
    disqualifyReasons.push('行情网络延迟异常，拒绝开单');
  }

  // Gate 7: 无任何触发性 WAIT 保护理由
  if (pred.waitReasons && pred.waitReasons.length > 0) {
    disqualifyReasons.push(...pred.waitReasons);
  }

  // 综合评分 (0 - 100)
  const baseScore = Math.min(100, Math.max(0, Math.round(50 + (modelProb - 50) * 1.5 + (pred.edge || 0) * 0.8)));
  const signalStrength = Math.min(99, Math.max(80, Math.round(baseScore * 0.95 + 4)));

  if (disqualifyReasons.length === 0) {
    // 满足全部硬性条件，生成正式确认项
    confirmations.push('✓ 多周期均线同向共振确认');
    confirmations.push(`✓ CVD主动成交量确认 (${pred.direction === 'UP' ? '主动买单吃盘' : '主动卖单倾泻'})`);
    confirmations.push(`✓ OFI订单流盘口失衡确认 (${ofiScore > 0 ? '+' : ''}${ofiScore}分)`);
    confirmations.push(`✓ 盘口深度确认 (买方占比 ${Math.round((pred.factors?.depth?.imbalanceRatio || 0.5) * 100)}%)`);
    confirmations.push(`✓ 正期望值数学确认 (EV: +$${pred.expectedValue}U, Edge: +${pred.edge}%)`);
    confirmations.push('✓ 波动率与流动性安全边际确认');

    riskNotes.push(`当前波动率状态: ${pred.regimeLabel}`);
    riskNotes.push('严格到期结算，自动以到期指数价对比开仓价');

    return {
      isQualified: true,
      disqualifyReasons: [],
      confirmations,
      riskNotes,
      score: baseScore,
      signalStrength,
    };
  }

  return {
    isQualified: false,
    disqualifyReasons,
    confirmations: [],
    riskNotes: ['未满足全部硬性开单门槛，策略强制空仓保护'],
    score: baseScore,
    signalStrength: 0,
  };
}

