import { DailySignalStats, FullDiagnosticsPayload, MarketSnapshot, SignalOrder, SignalOrderStats, SymbolType } from '../types/market.js';

export interface SyncPayload {
  orders: SignalOrder[];
  stats: SignalOrderStats | null;
  todayStats: DailySignalStats | null;
  dailyArchives: DailySignalStats[];
  diagnostics?: FullDiagnosticsPayload | null;
  snapshots?: Record<SymbolType, MarketSnapshot> | null;
  source: 'SOCKET' | 'POLLING' | 'CROSS_PEER' | 'BROADCAST_TAB';
  timestamp: number;
}

// 跨标签页即时同步通道 (0ms 跨页面实时广播)
const tabChannel = typeof window !== 'undefined' && 'BroadcastChannel' in window
  ? new BroadcastChannel('workbench_signals_channel')
  : null;

// 已知的备选对等云端节点列表
const KNOWN_PEERS = [
  'https://ais-dev-ryx6iotxo45avybvjffv7n-565490221983.europe-west3.run.app',
  'https://ais-pre-ryx6iotxo45avybvjffv7n-565490221983.europe-west3.run.app',
];

export class MultiClientSyncService {
  private lastSyncedCount = 0;
  private lastSyncTime = Date.now();
  private syncListeners: ((payload: SyncPayload) => void)[] = [];

  constructor() {
    if (tabChannel) {
      tabChannel.onmessage = (event) => {
        if (event.data && event.data.type === 'SYNC_DATA') {
          this.notifyListeners({
            ...event.data.payload,
            source: 'BROADCAST_TAB',
          });
        }
      };
    }
  }

  public onSync(listener: (payload: SyncPayload) => void) {
    this.syncListeners.push(listener);
    return () => {
      this.syncListeners = this.syncListeners.filter((l) => l !== listener);
    };
  }

  private notifyListeners(payload: SyncPayload) {
    this.lastSyncedCount = payload.orders?.length || 0;
    this.lastSyncTime = payload.timestamp || Date.now();
    for (const listener of this.syncListeners) {
      try {
        listener(payload);
      } catch (e) {
        console.error('[MultiClientSync] listener error:', e);
      }
    }
  }

  /**
   * 广播给本浏览器所有其他打开的页面或标签页
   */
  public broadcastToOtherTabs(payload: Omit<SyncPayload, 'source'>) {
    if (tabChannel) {
      tabChannel.postMessage({
        type: 'SYNC_DATA',
        payload: {
          ...payload,
          source: 'BROADCAST_TAB',
        },
      });
    }
  }

  /**
   * 全量同步：从当前后端获取，若当前后端为空(0笔)则自动向备用云端拉取并自愈填充
   */
  public async fetchAndSynchronize(): Promise<SyncPayload | null> {
    try {
      // 1. 先读取当前主站
      const [btcRes, ethRes, signalOrdersRes, todayRes, archivesRes, diagRes] = await Promise.all([
        fetch('/api/market/BTCUSDT').catch(() => null),
        fetch('/api/market/ETHUSDT').catch(() => null),
        fetch('/api/signal-orders').catch(() => null),
        fetch('/api/signals/today').catch(() => null),
        fetch('/api/signals/daily-archives').catch(() => null),
        fetch('/api/diagnostics/live').catch(() => null),
      ]);

      let orders: SignalOrder[] = [];
      let stats: SignalOrderStats | null = null;
      let todayStats: DailySignalStats | null = null;
      let dailyArchives: DailySignalStats[] = [];
      let diagnostics: FullDiagnosticsPayload | null = null;
      let snapshots: Record<SymbolType, MarketSnapshot> | null = null;

      if (btcRes?.ok && ethRes?.ok) {
        const btcData = await btcRes.json();
        const ethData = await ethRes.json();
        snapshots = { BTCUSDT: btcData, ETHUSDT: ethData };
      }

      if (signalOrdersRes?.ok) {
        const soData = await signalOrdersRes.json();
        if (Array.isArray(soData.orders)) orders = soData.orders;
        if (soData.stats) stats = soData.stats;
      }

      if (todayRes?.ok) {
        const td = await todayRes.json();
        if (td.todayStats) todayStats = td.todayStats;
      }

      if (archivesRes?.ok) {
        const ar = await archivesRes.json();
        if (ar.archives) dailyArchives = ar.archives;
      }

      if (diagRes?.ok) {
        diagnostics = await diagRes.json();
      }

      // 2. 自愈检查：如果当前节点只有 0 笔信号，尝试从已知对等公网镜像节点拉取并恢复
      if (orders.length === 0 && typeof window !== 'undefined') {
        const currentOrigin = window.location.origin;
        for (const peer of KNOWN_PEERS) {
          if (!peer.includes(window.location.hostname)) {
            try {
              const peerRes = await fetch(`${peer}/api/signal-orders`, {
                headers: { Accept: 'application/json' },
                signal: AbortSignal.timeout(3500),
              });
              if (peerRes.ok) {
                const peerData = await peerRes.json();
                if (Array.isArray(peerData.orders) && peerData.orders.length > 0) {
                  orders = peerData.orders;
                  stats = peerData.stats;
                  todayStats = peerData.todayStats;

                  // 自动同步写回当前主站后端持久化！
                  fetch('/api/signals/sync', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ orders: peerData.orders }),
                  }).catch(() => {});
                  break;
                }
              }
            } catch (err) {
              // 忽略不可达节点
            }
          }
        }
      }

      const payload: SyncPayload = {
        orders,
        stats,
        todayStats,
        dailyArchives,
        diagnostics,
        snapshots,
        source: 'POLLING',
        timestamp: Date.now(),
      };

      this.notifyListeners(payload);
      this.broadcastToOtherTabs(payload);

      return payload;
    } catch (err) {
      console.warn('[MultiClientSync] fetch error:', err);
      return null;
    }
  }

  public getStatus() {
    return {
      lastSyncedCount: this.lastSyncedCount,
      lastSyncTime: this.lastSyncTime,
    };
  }
}

export const multiClientSync = new MultiClientSyncService();
