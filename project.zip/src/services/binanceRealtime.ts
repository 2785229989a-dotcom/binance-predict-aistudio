/**
 * Binance Official Realtime WebSocket & Fallback Service
 * 币安官方 WebSocket 实时行情与 REST 兜底同步服务
 */
import { Time } from 'lightweight-charts';

export type ConnectionMode = 'websocket' | 'polling' | 'reconnecting';

export interface RealtimeTickerData {
  symbol: string;
  price: number;
  priceChange: number;
  priceChangePercent: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  quoteVolume24h: number;
  lastUpdate: number;
}

export interface RealtimeKlineBar {
  time: Time;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  isClosed: boolean;
}

type TickerListener = (tickers: Record<string, RealtimeTickerData>, mode: ConnectionMode) => void;

class BinanceRealtimeService {
  private static instance: BinanceRealtimeService;

  private ws: WebSocket | null = null;
  private connectionMode: ConnectionMode = 'reconnecting';
  private listeners: Set<TickerListener> = new Set();
  private reconnectTimer: any = null;
  private pollInterval: any = null;
  private isConnecting = false;

  private latestTickers: Record<string, RealtimeTickerData> = {
    BTCUSDT: {
      symbol: 'BTCUSDT',
      price: 0,
      priceChange: 0,
      priceChangePercent: 0,
      high24h: 0,
      low24h: 0,
      volume24h: 0,
      quoteVolume24h: 0,
      lastUpdate: 0,
    },
    ETHUSDT: {
      symbol: 'ETHUSDT',
      price: 0,
      priceChange: 0,
      priceChangePercent: 0,
      high24h: 0,
      low24h: 0,
      volume24h: 0,
      quoteVolume24h: 0,
      lastUpdate: 0,
    },
  };

  private constructor() {
    this.init();
  }

  public static getInstance(): BinanceRealtimeService {
    if (!BinanceRealtimeService.instance) {
      BinanceRealtimeService.instance = new BinanceRealtimeService();
    }
    return BinanceRealtimeService.instance;
  }

  private init() {
    // 1. Immediately do initial REST fetch for zero-delay startup
    this.pollRestPrices();

    // 2. Connect to official Binance WebSocket stream
    this.connectWs();
  }

  public getConnectionMode(): ConnectionMode {
    return this.connectionMode;
  }

  public getLatestTickers(): Record<string, RealtimeTickerData> {
    return this.latestTickers;
  }

  public subscribe(listener: TickerListener): () => void {
    this.listeners.add(listener);
    // Immediately emit current cached state
    listener(this.latestTickers, this.connectionMode);

    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => {
      try {
        fn(this.latestTickers, this.connectionMode);
      } catch (err) {
        console.error('[BinanceService] listener error:', err);
      }
    });
  }

  private setMode(mode: ConnectionMode) {
    if (this.connectionMode !== mode) {
      this.connectionMode = mode;
      this.notify();
    }
  }

  /**
   * Connect to Binance Official WebSocket
   * Combined stream for BTCUSDT and ETHUSDT 24hr tickers
   */
  private connectWs() {
    if (this.isConnecting) return;
    this.isConnecting = true;

    try {
      if (this.ws) {
        try {
          this.ws.close();
        } catch {}
        this.ws = null;
      }

      const streamUrl =
        'wss://stream.binance.com:9443/stream?streams=btcusdt@ticker/ethusdt@ticker';
      const ws = new WebSocket(streamUrl);
      this.ws = ws;

      ws.onopen = () => {
        console.log('[BinanceWS] 币安官方 WebSocket 实时流连接成功');
        this.isConnecting = false;
        this.setMode('websocket');
        // Stop REST polling when WS is healthy
        if (this.pollInterval) {
          clearInterval(this.pollInterval);
          this.pollInterval = null;
        }
      };

      ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          const data = payload.data || payload;
          if (!data || !data.s) return;

          const symbol = data.s.toUpperCase();
          if (symbol === 'BTCUSDT' || symbol === 'ETHUSDT') {
            const price = parseFloat(data.c);
            const high24h = parseFloat(data.h);
            const low24h = parseFloat(data.l);
            const volume24h = parseFloat(data.v);
            const quoteVolume24h = parseFloat(data.q);
            const priceChange = parseFloat(data.p);
            const priceChangePercent = parseFloat(data.P);

            this.latestTickers[symbol] = {
              symbol,
              price,
              high24h,
              low24h,
              volume24h,
              quoteVolume24h,
              priceChange,
              priceChangePercent,
              lastUpdate: Date.now(),
            };

            this.setMode('websocket');
            this.notify();
          }
        } catch (err) {
          // ignore parsing error
        }
      };

      ws.onerror = (err) => {
        console.warn('[BinanceWS] WebSocket 连接异常，启动 REST 轮询兜底:', err);
        this.handleWsFailure();
      };

      ws.onclose = () => {
        console.warn('[BinanceWS] WebSocket 连接断开，准备自动重连与 REST 兜底');
        this.handleWsFailure();
      };
    } catch (err) {
      console.warn('[BinanceWS] 创建 WebSocket 失败，进入兜底模式:', err);
      this.handleWsFailure();
    }
  }

  private handleWsFailure() {
    this.isConnecting = false;
    this.ws = null;
    this.setMode('polling');

    // Start fallback REST polling every 1500ms
    if (!this.pollInterval) {
      this.pollRestPrices();
      this.pollInterval = setInterval(() => {
        this.pollRestPrices();
      }, 1500);
    }

    // Schedule WebSocket reconnect after 3 seconds
    if (!this.reconnectTimer) {
      this.reconnectTimer = setTimeout(() => {
        this.reconnectTimer = null;
        this.connectWs();
      }, 3000);
    }
  }

  /**
   * REST polling fallback
   * Queries Binance public endpoints with proxy fallbacks
   */
  public async pollRestPrices() {
    const symbols = ['BTCUSDT', 'ETHUSDT'];
    for (const sym of symbols) {
      this.fetchSingleSymbolRest(sym);
    }
  }

  private async fetchSingleSymbolRest(symbol: string) {
    const urls = [
      `https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol}`,
      `https://data-api.binance.vision/api/v3/ticker/24hr?symbol=${symbol}`,
      `/api/ticker/24hr?symbol=${symbol}`,
      `/api/ticker/price?symbol=${symbol}`,
    ];

    for (const url of urls) {
      try {
        const resp = await fetch(url, { signal: AbortSignal.timeout(2000) });
        if (resp.ok) {
          const d = await resp.json();
          const price = parseFloat(d.lastPrice || d.price || d.c || '0');
          if (price > 0) {
            const high24h = parseFloat(d.highPrice || d.h || String(price * 1.01));
            const low24h = parseFloat(d.lowPrice || d.l || String(price * 0.99));
            const volume24h = parseFloat(d.volume || d.v || '0');
            const quoteVolume24h = parseFloat(d.quoteVolume || d.q || '0');
            const priceChange = parseFloat(d.priceChange || d.p || '0');
            const priceChangePercent = parseFloat(d.priceChangePercent || d.P || '0');

            this.latestTickers[symbol] = {
              symbol,
              price,
              high24h,
              low24h,
              volume24h,
              quoteVolume24h,
              priceChange,
              priceChangePercent,
              lastUpdate: Date.now(),
            };
            this.notify();
            return;
          }
        }
      } catch {
        // try next endpoint
      }
    }
  }

  /**
   * Subscribe to dedicated Binance Kline WebSocket channel
   * e.g. wss://stream.binance.com:9443/ws/btcusdt@kline_5m
   */
  public subscribeKline(
    symbol: string,
    interval: string,
    onKline: (kline: RealtimeKlineBar) => void
  ): () => void {
    let active = true;
    let ws: WebSocket | null = null;
    let reconnectTimeout: any = null;
    let pollTimer: any = null;

    const connectKlineWs = () => {
      if (!active) return;

      const wsUrl = `wss://stream.binance.com:9443/ws/${symbol.toLowerCase()}@kline_${interval}`;

      try {
        ws = new WebSocket(wsUrl);

        ws.onopen = () => {
          if (!active) {
            ws?.close();
            return;
          }
          if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
          }
        };

        ws.onmessage = (event) => {
          if (!active) return;
          try {
            const data = JSON.parse(event.data);
            const k = data.k;
            if (!k) return;

            const bar: RealtimeKlineBar = {
              time: Math.floor(k.t / 1000) as Time,
              open: parseFloat(k.o),
              high: parseFloat(k.h),
              low: parseFloat(k.l),
              close: parseFloat(k.c),
              volume: parseFloat(k.v),
              isClosed: k.x,
            };

            onKline(bar);
          } catch (err) {
            // ignore
          }
        };

        ws.onerror = () => {
          handleKlineFailure();
        };

        ws.onclose = () => {
          handleKlineFailure();
        };
      } catch {
        handleKlineFailure();
      }
    };

    const handleKlineFailure = () => {
      if (!active) return;
      ws = null;

      // Start REST polling fallback for kline
      if (!pollTimer) {
        pollLatestBar();
        pollTimer = setInterval(pollLatestBar, 2000);
      }

      if (!reconnectTimeout) {
        reconnectTimeout = setTimeout(() => {
          reconnectTimeout = null;
          connectKlineWs();
        }, 3000);
      }
    };

    const pollLatestBar = async () => {
      if (!active) return;
      try {
        const res = await fetch(`/api/klines?symbol=${symbol}&interval=${interval}&limit=2`, {
          signal: AbortSignal.timeout(2000),
        });
        if (res.ok) {
          const d = await res.json();
          if (d.klines && d.klines.length > 0) {
            const lastK = d.klines[d.klines.length - 1];
            onKline({
              time: lastK.time as Time,
              open: lastK.open,
              high: lastK.high,
              low: lastK.low,
              close: lastK.close,
              volume: lastK.volume,
              isClosed: false,
            });
          }
        }
      } catch {
        // ignore
      }
    };

    connectKlineWs();

    return () => {
      active = false;
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      if (pollTimer) clearInterval(pollTimer);
      if (ws) {
        try {
          ws.close();
        } catch {}
        ws = null;
      }
    };
  }
}

export const binanceRealtime = BinanceRealtimeService.getInstance();
