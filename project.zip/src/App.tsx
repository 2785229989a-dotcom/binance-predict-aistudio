import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import {
  DailySignalStats,
  DurationType,
  FullDiagnosticsPayload,
  MarketSnapshot,
  SignalOrder,
  SignalOrderStats,
  SymbolType,
} from './types/market.js';
import { BinanceRealtimeChart } from './components/BinanceRealtimeChart.js';
import { HistoryOrdersPanel } from './components/HistoryOrdersPanel.js';
import { DailyStatsDashboard } from './components/DailyStatsDashboard.js';
import { PredictionFactors } from './components/PredictionFactors.js';
import { OrderBookDepth } from './components/OrderBookDepth.js';
import { BacktestPanel } from './components/BacktestPanel.js';
import { ModelExamPanel } from './components/ModelExamPanel.js';
import { SignalDiagnosticsPanel } from './components/SignalDiagnosticsPanel.js';
import { ExportModal } from './components/ExportModal.js';
import { soundManager } from './utils/soundAlert.js';
import { multiClientSync } from './services/apiSync.js';
import {
  TrendingUp,
  Clock,
  Volume2,
  VolumeX,
  RefreshCw,
  Zap,
  FileText,
  Sliders,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  MinusCircle,
  Activity,
  Award,
  Calendar,
  Filter,
} from 'lucide-react';

export default function App() {
  const [selectedDuration, setSelectedDuration] = useState<DurationType>('10m');
  const [activeTab, setActiveTab] = useState<string>('live');
  const [viewFilter, setViewFilter] = useState<'ALL' | 'BTC' | 'ETH'>('ALL');
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [snapshots, setSnapshots] = useState<Record<SymbolType, MarketSnapshot> | null>(null);
  const [signalOrders, setSignalOrders] = useState<SignalOrder[]>([]);
  const [signalStats, setSignalStats] = useState<SignalOrderStats | null>(null);
  const [todayStats, setTodayStats] = useState<DailySignalStats | null>(null);
  const [dailyArchives, setDailyArchives] = useState<DailySignalStats[]>([]);
  const [diagnosticsData, setDiagnosticsData] = useState<FullDiagnosticsPayload | null>(null);
  const [currentShanghaiDate, setCurrentShanghaiDate] = useState<string>('2026-10-07');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => soundManager.getIsEnabled());
  const [audioUnlocked, setAudioUnlocked] = useState<boolean>(() => soundManager.isUnlocked());
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // High precision clock ticker for countdowns
  const [clockTime, setClockTime] = useState<number>(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setClockTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const socketRef = useRef<Socket | null>(null);
  const selectedDurationRef = useRef<DurationType>(selectedDuration);
  selectedDurationRef.current = selectedDuration;

  // REST fetch for initial load and manual refresh
  const fetchAllData = async () => {
    try {
      const [btcRes, ethRes, signalOrdersRes, todayRes, archivesRes, diagRes] = await Promise.all([
        fetch('/api/market/BTCUSDT'),
        fetch('/api/market/ETHUSDT'),
        fetch('/api/signal-orders'),
        fetch('/api/signals/today'),
        fetch('/api/signals/daily-archives'),
        fetch('/api/diagnostics/live'),
      ]);

      if (btcRes.ok && ethRes.ok) {
        const btcData = await btcRes.json();
        const ethData = await ethRes.json();
        setSnapshots({
          BTCUSDT: btcData,
          ETHUSDT: ethData,
        });
      }

      if (signalOrdersRes.ok) {
        const soData = await signalOrdersRes.json();
        if (soData.orders) setSignalOrders(soData.orders);
        if (soData.stats) setSignalStats(soData.stats);
      }

      if (todayRes.ok) {
        const td = await todayRes.json();
        if (td.todayStats) setTodayStats(td.todayStats);
        if (td.date) setCurrentShanghaiDate(td.date);
      }

      if (archivesRes.ok) {
        const ar = await archivesRes.json();
        if (ar.archives) setDailyArchives(ar.archives);
        if (ar.currentDate) setCurrentShanghaiDate(ar.currentDate);
      }

      if (diagRes.ok) {
        const dg = await diagRes.json();
        setDiagnosticsData(dg);
      }
    } catch (err) {
      console.warn('REST load error:', err);
    }
  };

  // Manual Refresh Handler
  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await multiClientSync.fetchAndSynchronize();
    } finally {
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  // Toggle Sound Handler
  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.setEnabled(next);
    if (next) {
      soundManager.initAudio();
      setAudioUnlocked(true);
    }
  };

  // User click to unlock browser audio context on mobile
  const handleUnlockAudio = () => {
    soundManager.initAudio();
    setAudioUnlocked(true);
  };

  // Multi-Client Continuous Sync and Visibility Listener
  useEffect(() => {
    // 1. Initial multi-environment sync
    multiClientSync.fetchAndSynchronize();

    // 2. Continuous 3.5s polling loop to ensure all browsers and devices stay in strict lockstep
    const syncTimer = setInterval(() => {
      multiClientSync.fetchAndSynchronize();
    }, 3500);

    // 3. Tab visibility listener (mobile screen wakeup / tab switch instantly re-syncs)
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        multiClientSync.fetchAndSynchronize();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // 4. Listen for BroadcastChannel / polling sync payloads
    const unsub = multiClientSync.onSync((payload) => {
      if (payload.snapshots) setSnapshots(payload.snapshots);
      if (Array.isArray(payload.orders)) setSignalOrders(payload.orders);
      if (payload.stats) setSignalStats(payload.stats);
      if (payload.todayStats) setTodayStats(payload.todayStats);
      if (payload.dailyArchives) setDailyArchives(payload.dailyArchives);
      if (payload.diagnostics) setDiagnosticsData(payload.diagnostics);
    });

    return () => {
      clearInterval(syncTimer);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      unsub();
    };
  }, []);

  // Initialize Socket.io connection and real-time push
  useEffect(() => {
    const socket = io({
      transports: ['polling', 'websocket'],
      reconnectionAttempts: 50,
      reconnectionDelay: 1000,
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('[Socket.io] 已连接至币安行情与事件合约推流服务 (Transport: ' + socket.io.engine.transport.name + ')');
      setIsConnected(true);
      multiClientSync.fetchAndSynchronize();
    });

    socket.on('disconnect', () => {
      console.log('[Socket.io] 与推流服务连接断开，自愈重连中');
      setIsConnected(false);
    });

    socket.on('market_init', (data: any) => {
      if (data.BTCUSDT && data.ETHUSDT) {
        setSnapshots({
          BTCUSDT: data.BTCUSDT,
          ETHUSDT: data.ETHUSDT,
        });
      }
      if (Array.isArray(data.signalOrders)) setSignalOrders(data.signalOrders);
      if (data.signalStats) setSignalStats(data.signalStats);
      if (data.todayStats) setTodayStats(data.todayStats);
      if (data.dailyArchives) setDailyArchives(data.dailyArchives);
      if (data.currentShanghaiDate) setCurrentShanghaiDate(data.currentShanghaiDate);
      if (data.diagnostics) setDiagnosticsData(data.diagnostics);
    });

    socket.on('market_update', (data: any) => {
      if (data.BTCUSDT && data.ETHUSDT) {
        setSnapshots({
          BTCUSDT: data.BTCUSDT,
          ETHUSDT: data.ETHUSDT,
        });
      }
      // Keep signalOrders in exact sync across all clients every tick
      if (Array.isArray(data.signalOrders)) {
        setSignalOrders(data.signalOrders);
      }
      if (data.signalStats) {
        setSignalStats(data.signalStats);
      }
      if (data.todayStats) setTodayStats(data.todayStats);
      if (data.dailyArchives) setDailyArchives(data.dailyArchives);
      if (data.currentShanghaiDate) setCurrentShanghaiDate(data.currentShanghaiDate);
      if (data.diagnostics) setDiagnosticsData(data.diagnostics);
    });

    socket.on('daily_reset', (data: any) => {
      console.log('[Socket.io] 接收到每日 00:00:00 日结重置事件:', data.date);
      if (data.date) setCurrentShanghaiDate(data.date);
      if (data.todayStats) setTodayStats(data.todayStats);
    });

    socket.on('today_stats_updated', (stats: DailySignalStats) => {
      setTodayStats(stats);
    });

    socket.on('daily_archives_updated', (archives: DailySignalStats[]) => {
      setDailyArchives(archives);
    });

    socket.on('signals_cleared', () => {
      setSignalOrders([]);
      setTodayStats(null);
      setDailyArchives([]);
      setSignalStats(null);
    });

    // New Signal Order automatically created by quantitative engine
    socket.on('signal_order_created', (newOrder: SignalOrder) => {
      console.log('[Socket.io] 接收到新信号订单:', newOrder.signalId, newOrder.symbol, newOrder.direction);
      setSignalOrders((prev) => {
        const filtered = prev.filter((o) => o.signalId !== newOrder.signalId);
        const updated = [newOrder, ...filtered];
        multiClientSync.broadcastToOtherTabs({
          orders: updated,
          stats: signalStats,
          todayStats,
          dailyArchives,
          timestamp: Date.now(),
        });
        return updated;
      });

      // Sound & Speech Alert on signal generation
      soundManager.notifySignal(
        newOrder.symbol,
        newOrder.duration,
        newOrder.direction,
        newOrder.modelProb,
        100 - newOrder.modelProb
      );
    });

    // Signal Order locked Entry Price Index at T+1s
    socket.on('signal_orders_entered', (enteredOrders: SignalOrder[]) => {
      setSignalOrders((prev) =>
        prev.map((order) => {
          const match = enteredOrders.find((e) => e.signalId === order.signalId);
          return match ? { ...order, ...match } : order;
        })
      );
    });

    // Signal Order settled with Expiry Price Index (WIN/LOSS/TIE)
    socket.on('signal_orders_settled', (settledOrders: SignalOrder[]) => {
      setSignalOrders((prev) =>
        prev.map((order) => {
          const match = settledOrders.find((s) => s.signalId === order.signalId);
          return match ? { ...order, ...match } : order;
        })
      );
    });

    socket.on('signal_stats_updated', (newStats: SignalOrderStats) => {
      setSignalStats(newStats);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const btcSnapshot = snapshots ? snapshots.BTCUSDT : null;
  const ethSnapshot = snapshots ? snapshots.ETHUSDT : null;
  const btcPrice = btcSnapshot?.price || 0;
  const ethPrice = ethSnapshot?.price || 0;

  // Currently active signal orders for BTC and ETH under selected duration
  const activeBtcSignal = signalOrders.find(
    (s) =>
      s.symbol === 'BTCUSDT' &&
      s.duration === selectedDuration &&
      (s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY')
  );

  const activeEthSignal = signalOrders.find(
    (s) =>
      s.symbol === 'ETHUSDT' &&
      s.duration === selectedDuration &&
      (s.status === 'ACTIVE' || s.status === 'WAITING_ENTRY')
  );

  const btcCandidate = diagnosticsData?.candidates?.BTCUSDT?.[selectedDuration];
  const ethCandidate = diagnosticsData?.candidates?.ETHUSDT?.[selectedDuration];

  // Recently settled signal orders
  const recentSettledSignals = signalOrders.filter((s) => s.status === 'SETTLED').slice(0, 6);

  return (
    <div className="min-h-screen max-w-full overflow-x-hidden bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-400 selection:text-zinc-950">
      {/* Top Header: Navigation & Key Market Stats */}
      <header className="border-b border-zinc-800 bg-zinc-950/95 sticky top-0 z-40 backdrop-blur max-w-full overflow-x-hidden">
        {/* Row 1: App Title, Quick Price, Live Status, Sound Toggle */}
        <div className="max-w-7xl mx-auto px-2.5 sm:px-6 py-2 sm:py-2.5 flex flex-wrap items-center justify-between gap-2">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            <div className="h-7 w-7 sm:h-8 sm:w-8 rounded-lg bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center shadow-lg shadow-amber-500/20 shrink-0">
              <TrendingUp className="h-4 w-4 sm:h-4.5 sm:w-4.5 text-zinc-950 font-black" />
            </div>
            <div>
              <h1 className="font-black text-xs sm:text-base text-white tracking-tight flex items-center gap-1.5">
                BINANCE 事件合约实时预测与实盘看盘
                <span className="text-[9px] uppercase font-bold tracking-widest px-1 py-0.2 sm:px-1.5 sm:py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  BTC / ETH
                </span>
              </h1>
              <div className="text-[9px] sm:text-[10px] text-zinc-400 flex items-center gap-2">
                <span>币安实盘完整K线看盘 · 盘面标记有效信号 · T+1s确立Entry · 自动判定胜负平</span>
              </div>
            </div>
          </div>

          {/* Quick Status Badges (Always visible on mobile & desktop) */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 text-[10px] sm:text-xs font-mono">
            {/* Live Prices */}
            <div className="flex items-center gap-1 sm:gap-2 font-bold">
              <span className="bg-zinc-900 border border-zinc-800 px-1.5 sm:px-2 py-1 rounded text-amber-400 text-[10px] sm:text-xs">
                BTC: ${btcPrice > 0 ? btcPrice.toLocaleString(undefined, { minimumFractionDigits: 1 }) : '---'}
              </span>
              <span className="bg-zinc-900 border border-zinc-800 px-1.5 sm:px-2 py-1 rounded text-sky-400 text-[10px] sm:text-xs">
                ETH: ${ethPrice > 0 ? ethPrice.toLocaleString(undefined, { minimumFractionDigits: 1 }) : '---'}
              </span>
            </div>

            {/* Connection Status */}
            <span
              className={`hidden xs:flex items-center gap-1 px-2 py-1 rounded-full border text-[10px] sm:text-[11px] ${
                isConnected
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
              <span>{isConnected ? '实盘' : '中断'}</span>
            </span>

            {/* Firestore Cloud Persistence & Multi-Device Sync Badge */}
            <span
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] sm:text-[11px] bg-emerald-500/10 text-emerald-300 border-emerald-500/30 font-mono"
              title="Firebase Firestore 托管云数据库已接通：所有信号与胜率已永久持久化上云，即使全关网页数日也绝不丢失！"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>云端持久化: <strong className="text-white">{signalOrders.length}</strong> 笔信号</span>
            </span>

            {/* Sound Toggle - min 38px touch target */}
            <button
              onClick={handleToggleSound}
              className={`min-h-[38px] flex items-center gap-1 px-2.5 py-1 rounded-full border transition text-[11px] cursor-pointer ${
                soundEnabled
                  ? 'bg-amber-400/20 text-amber-300 border-amber-400/40 hover:bg-amber-400/30'
                  : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:text-zinc-300'
              }`}
              title="有开单信号时发出声音提示"
            >
              {soundEnabled ? (
                <>
                  <Volume2 className="h-3.5 w-3.5 text-amber-400" />
                  <span className="hidden sm:inline">声音: 开启</span>
                </>
              ) : (
                <>
                  <VolumeX className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">声音: 关闭</span>
                </>
              )}
            </button>

            {/* Manual Refresh - min 38px touch target */}
            <button
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              className="min-h-[38px] min-w-[38px] p-2 rounded-xl border border-zinc-800 bg-zinc-900 hover:text-white transition text-zinc-400 cursor-pointer flex items-center justify-center"
              title="手动强制刷新"
            >
              <RefreshCw className={`h-3.5 w-3.5 text-amber-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Row 2: Duration Selector & Navigation Tabs (Mobile Horizontal Swipe with Touch Targets) */}
        <div className="max-w-7xl mx-auto px-2.5 sm:px-6 py-1.5 border-t border-zinc-800/80 flex flex-col md:flex-row md:items-center justify-between gap-2 overflow-x-hidden">
          {/* Master Event Contract Duration Selector */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar whitespace-nowrap py-0.5">
            <span className="text-[11px] sm:text-xs text-amber-400 font-bold flex items-center gap-1 shrink-0">
              <Clock className="h-3.5 w-3.5" />
              预测期限:
            </span>
            <div className="flex bg-zinc-900 p-0.5 rounded-xl border border-zinc-800 text-xs font-mono shrink-0">
              {(
                [
                  { id: '10m', label: '10分钟' },
                  { id: '30m', label: '30分钟' },
                  { id: '1h', label: '1小时' },
                  { id: '1d', label: '1天' },
                ] as const
              ).map((d) => (
                <button
                  key={d.id}
                  onClick={() => setSelectedDuration(d.id)}
                  className={`min-h-[38px] px-3 py-1 rounded-lg font-bold transition cursor-pointer text-xs ${
                    selectedDuration === d.id
                      ? 'bg-amber-400 text-zinc-950 shadow-md font-black'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          {/* Navigation Tabs (Smooth touch scrolling on mobile) */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar whitespace-nowrap text-xs py-0.5">
            <button
              onClick={() => setActiveTab('live')}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'live'
                  ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <TrendingUp className="h-3.5 w-3.5" />
              实盘K线与信号看盘
            </button>

            <button
              onClick={() => setActiveTab('diagnostics')}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'diagnostics'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <ShieldCheck className="h-3.5 w-3.5" />
              开单信号诊断模式
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'orders'
                  ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <FileText className="h-3.5 w-3.5" />
              预测信号与胜率 ({signalOrders.length})
            </button>

            <button
              onClick={() => setActiveTab('quant')}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'quant'
                  ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Sliders className="h-3.5 w-3.5" />
              高级量化特征
            </button>

            <button
              onClick={() => setActiveTab('backtest')}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'backtest'
                  ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" />
              策略回测
            </button>

            <button
              onClick={() => setActiveTab('export')}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'export'
                  ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              专属链接与导出
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Browser Audio Permission Banner */}
      {!audioUnlocked && soundEnabled && (
        <div className="bg-amber-500/20 border-b border-amber-500/30 px-3 py-2 text-center text-xs text-amber-300 flex flex-wrap items-center justify-center gap-2">
          <span>🔊 手机浏览器已默认静音：</span>
          <button
            onClick={handleUnlockAudio}
            className="min-h-[36px] px-3 py-1 rounded-lg bg-amber-400 text-zinc-950 font-bold hover:bg-amber-300 transition cursor-pointer"
          >
            点击开启声音提醒
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-2.5 sm:px-6 py-3 sm:py-5 space-y-4 sm:space-y-6 max-w-full overflow-x-hidden">
        {/* Tab 1: Real Binance Candlestick Charts with On-Chart Signals */}
        {activeTab === 'live' && (
          <div className="space-y-4 sm:space-y-6">
            {/* View Filter: Dual (BTC + ETH) / Only BTC / Only ETH (Swipeable on mobile) */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 overflow-x-hidden">
              <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs overflow-x-auto no-scrollbar whitespace-nowrap">
                <button
                  onClick={() => setViewFilter('ALL')}
                  className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs shrink-0 ${
                    viewFilter === 'ALL'
                      ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  双币同屏 (BTC + ETH)
                </button>
                <button
                  onClick={() => setViewFilter('BTC')}
                  className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs shrink-0 ${
                    viewFilter === 'BTC'
                      ? 'bg-zinc-800 text-amber-300 border border-zinc-700 shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  仅看 BTC
                </button>
                <button
                  onClick={() => setViewFilter('ETH')}
                  className={`min-h-[38px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs shrink-0 ${
                    viewFilter === 'ETH'
                      ? 'bg-zinc-800 text-sky-300 border border-zinc-700 shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  仅看 ETH
                </button>
              </div>

              <div className="text-[11px] sm:text-xs text-zinc-400 flex items-center gap-1.5 font-mono">
                <span>模型期限:</span>
                <span className="text-amber-300 font-bold">
                  {selectedDuration === '10m'
                    ? '10分钟'
                    : selectedDuration === '30m'
                    ? '30分钟'
                    : selectedDuration === '1h'
                    ? '1小时'
                    : '1天'}
                </span>
                <span>• 币安完整 1000 根 K 线推流</span>
              </div>
            </div>

            {/* Core Section 1: BTC Binance Real-time K-Line Chart */}
            {(viewFilter === 'ALL' || viewFilter === 'BTC') && (
              <BinanceRealtimeChart
                symbol="BTCUSDT"
                snapshot={btcSnapshot}
                activeDuration={selectedDuration}
                onChangeDuration={setSelectedDuration}
                signalOrders={signalOrders}
              />
            )}

            {/* Core Section 2: ETH Binance Real-time K-Line Chart */}
            {(viewFilter === 'ALL' || viewFilter === 'ETH') && (
              <BinanceRealtimeChart
                symbol="ETHUSDT"
                snapshot={ethSnapshot}
                activeDuration={selectedDuration}
                onChangeDuration={setSelectedDuration}
                signalOrders={signalOrders}
              />
            )}

            {/* Core Section 3: Active Ongoing Signals & Real-time Candidate Diagnostic */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-3 sm:p-4 shadow-xl space-y-3 sm:space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 sm:pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2 font-bold text-white text-xs sm:text-sm">
                  <Activity className="h-4 w-4 sm:h-4.5 sm:w-4.5 text-amber-400 animate-pulse shrink-0" />
                  <span>当前正式开单信号与候选信号诊断</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-amber-300 font-mono border border-zinc-700">
                    宁缺毋滥 · 14项门槛
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] sm:text-[11px] font-mono text-zinc-400 hidden md:inline">
                    真实到期结算 · 锁定开仓价
                  </span>
                  <button
                    onClick={() => setActiveTab('diagnostics')}
                    className="text-amber-400 hover:text-amber-300 font-bold text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <ShieldCheck className="h-3.5 w-3.5" />
                    <span>查看开单信号诊断模式 →</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                {/* BTC Active Signal Card */}
                {activeBtcSignal ? (
                  (() => {
                    const isWaiting = activeBtcSignal.status === 'WAITING_ENTRY';
                    const entry = activeBtcSignal.entryPriceIndex ?? activeBtcSignal.signalPrice;
                    const delta = btcPrice - entry;
                    // UP: live >= entry -> floating profit (green), else loss (red)
                    // DOWN: live <= entry -> floating profit (green), else loss (red)
                    const isFav =
                      activeBtcSignal.direction === 'UP' ? delta >= 0 : delta <= 0;
                    const rem = isWaiting
                      ? Math.max(0, Math.ceil((activeBtcSignal.entryTime - clockTime) / 1000))
                      : Math.max(0, Math.floor((activeBtcSignal.expiryTime - clockTime) / 1000));
                    const remStr = `${String(Math.floor(rem / 60)).padStart(2, '0')}:${String(rem % 60).padStart(2, '0')}`;

                    return (
                      <div className="bg-zinc-950 p-3.5 sm:p-4 rounded-xl border border-amber-500/30 flex flex-col justify-between font-mono text-xs shadow-lg space-y-2.5 sm:space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5 sm:gap-2 font-bold text-sm sm:text-base text-white">
                            <span>BTCUSDT</span>
                            <span className="text-[10px] sm:text-xs px-1.5 py-0.5 rounded bg-zinc-900 text-amber-300">
                              {activeBtcSignal.duration}
                            </span>
                            <span
                              className={`text-[10px] sm:text-xs px-2 py-0.5 rounded font-black ${
                                activeBtcSignal.direction === 'UP'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {activeBtcSignal.direction === 'UP' ? '🟢 OPEN LONG (买涨)' : '🔴 OPEN SHORT (买跌)'}
                            </span>
                          </div>
                          <span className="text-amber-400 font-bold flex items-center gap-1 text-[11px]">
                            <Clock className="h-3.5 w-3.5 animate-spin" />
                            {isWaiting ? `确立中 (${rem}s)` : `剩余: ${remStr}`}
                          </span>
                        </div>

                        {/* Real-time Market Monitoring Grid */}
                        <div className="grid grid-cols-2 gap-2 text-[11px] sm:text-xs py-2 bg-zinc-900/60 p-2 sm:p-2.5 rounded-lg border border-zinc-800">
                          <div>
                            <span className="text-zinc-500 block text-[10px]">开仓参考 (Entry):</span>
                            <strong className="text-white text-xs sm:text-sm">
                              {activeBtcSignal.entryPriceIndex
                                ? `$${activeBtcSignal.entryPriceIndex.toFixed(2)}`
                                : 'T+1s 确立中'}
                            </strong>
                          </div>
                          <div>
                            <span className="text-zinc-500 block text-[10px]">实时现价 (Current):</span>
                            <strong className="text-white text-xs sm:text-sm">
                              ${btcPrice > 0 ? btcPrice.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '---'}
                            </strong>
                          </div>
                          <div>
                            <span className="text-zinc-500 block text-[10px]">实时价差 (Price Diff):</span>
                            <span className={`font-bold text-xs sm:text-sm flex items-center gap-1 ${isFav ? 'text-emerald-400' : 'text-rose-400'}`}>
                              <span>{delta >= 0 ? '+' : ''}{delta.toFixed(2)}</span>
                              <span
                                className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                                  isFav
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                }`}
                              >
                                {isFav ? '浮盈' : '浮亏'}
                              </span>
                            </span>
                          </div>
                          <div>
                            <span className="text-zinc-500 block text-[10px]">胜率 / 赔率:</span>
                            <span className="text-amber-300 font-bold text-xs sm:text-sm">
                              {activeBtcSignal.modelProb}% ({(activeBtcSignal.payoutRatio * 100).toFixed(0)}%)
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-1 text-[10px] sm:text-[11px] text-zinc-400">
                          <span>状态: <strong className="text-emerald-400">{activeBtcSignal.direction === 'UP' ? '🟢 OPEN LONG (进行中)' : '🔴 OPEN SHORT (进行中)'}</strong></span>
                          <span>ID: <span className="text-zinc-300 font-mono">{activeBtcSignal.signalId.slice(0, 14)}...</span></span>
                        </div>
                      </div>
                    );
                  })()
                ) : (
                  /* Real-time Candidate Diagnostic Box when no active BTC signal */
                  <div className="bg-zinc-950 p-3.5 sm:p-4 rounded-xl border border-zinc-800 font-mono text-xs flex flex-col justify-between space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-bold text-white">
                        <span>BTCUSDT</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-900 text-amber-300">
                          {selectedDuration}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-amber-300 border border-zinc-700 font-bold flex items-center gap-1">
                          <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
                          <span>⚪ WAIT (空仓观望)</span>
                        </span>
                      </div>
                      <span className="text-zinc-400 text-[11px]">
                        综合评分: <strong className={btcCandidate && btcCandidate.compositeScore >= 85 ? 'text-emerald-400' : 'text-amber-400'}>
                          {btcCandidate ? btcCandidate.compositeScore : '--'}/100
                        </strong>
                      </span>
                    </div>

                    <div className="bg-zinc-900/60 p-2.5 rounded-lg border border-zinc-800 space-y-2">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-zinc-400">候选倾向:</span>
                        <strong className={btcCandidate?.candidateDirection === 'UP' ? 'text-emerald-400' : 'text-rose-400'}>
                          BTC {btcCandidate?.candidateDirection === 'UP' ? '买涨 (UP)' : '买跌 (DOWN)'}
                        </strong>
                        <span className="text-zinc-500">
                          UP: {btcCandidate ? btcCandidate.upProb.toFixed(1) : '--'}% | DOWN: {btcCandidate ? btcCandidate.downProb.toFixed(1) : '--'}%
                        </span>
                      </div>

                      <div className="border-t border-zinc-800/80 pt-1.5 text-[11px]">
                        <span className="text-zinc-500 block mb-1 text-[10px]">未开单原因 (策略严格过滤):</span>
                        <div className="space-y-1">
                          {btcCandidate && btcCandidate.rejectionReasons.length > 0 ? (
                            btcCandidate.rejectionReasons.slice(0, 2).map((r, i) => (
                              <div key={i} className="text-rose-300 text-[10px] truncate flex items-center gap-1">
                                <span className="text-rose-500 shrink-0">•</span>
                                <span>{r}</span>
                              </div>
                            ))
                          ) : (
                            <div className="text-zinc-400 text-[10px]">
                              等待微观订单流(OFI/CVD)与多周期趋势共振满足正期望
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-0.5">
                      <span>门槛通过: <strong className="text-zinc-300">{btcCandidate ? btcCandidate.conditions.filter((c) => c.passed).length : 0}/14</strong></span>
                      <button
                        onClick={() => setActiveTab('diagnostics')}
                        className="text-amber-400 hover:text-amber-300 font-bold cursor-pointer flex items-center gap-1"
                      >
                        <span>查看14项开单门槛详情</span>
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                )}

                {/* ETH Active Signal Card */}
                {activeEthSignal ? (
                  (() => {
                    const isWaiting = activeEthSignal.status === 'WAITING_ENTRY';
                    const entry = activeEthSignal.entryPriceIndex ?? activeEthSignal.signalPrice;
                    const delta = ethPrice - entry;
                    // UP: live >= entry -> floating profit (green), else loss (red)
                    // DOWN: live <= entry -> floating profit (green), else loss (red)
                    const isFav =
                      activeEthSignal.direction === 'UP' ? delta >= 0 : delta <= 0;
                    const rem = isWaiting
                      ? Math.max(0, Math.ceil((activeEthSignal.entryTime - clockTime) / 1000))
                      : Math.max(0, Math.floor((activeEthSignal.expiryTime - clockTime) / 1000));
                    const remStr = `${String(Math.floor(rem / 60)).padStart(2, '0')}:${String(rem % 60).padStart(2, '0')}`;

                    return (
                      <div className="bg-zinc-950 p-3.5 sm:p-4 rounded-xl border border-amber-500/30 flex flex-col justify-between font-mono text-xs shadow-lg space-y-2.5 sm:space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5 sm:gap-2 font-bold text-sm sm:text-base text-white">
                            <span>ETHUSDT</span>
                            <span className="text-[10px] sm:text-xs px-1.5 py-0.5 rounded bg-zinc-900 text-amber-300">
                              {activeEthSignal.duration}
                            </span>
                            <span
                              className={`text-[10px] sm:text-xs px-2 py-0.5 rounded font-black ${
                                activeEthSignal.direction === 'UP'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {activeEthSignal.direction === 'UP' ? '🟢 OPEN LONG (买涨)' : '🔴 OPEN SHORT (买跌)'}
                            </span>
                          </div>
                          <span className="text-amber-400 font-bold flex items-center gap-1 text-[11px]">
                            <Clock className="h-3.5 w-3.5 animate-spin" />
                            {isWaiting ? `确立中 (${rem}s)` : `剩余: ${remStr}`}
                          </span>
                        </div>

                        {/* Real-time Market Monitoring Grid */}
                        <div className="grid grid-cols-2 gap-2 text-[11px] sm:text-xs py-2 bg-zinc-900/60 p-2 sm:p-2.5 rounded-lg border border-zinc-800">
                          <div>
                            <span className="text-zinc-500 block text-[10px]">开仓参考 (Entry):</span>
                            <strong className="text-white text-xs sm:text-sm">
                              {activeEthSignal.entryPriceIndex
                                ? `$${activeEthSignal.entryPriceIndex.toFixed(2)}`
                                : 'T+1s 确立中'}
                            </strong>
                          </div>
                          <div>
                            <span className="text-zinc-500 block text-[10px]">实时现价 (Current):</span>
                            <strong className="text-white text-xs sm:text-sm">
                              ${ethPrice > 0 ? ethPrice.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '---'}
                            </strong>
                          </div>
                          <div>
                            <span className="text-zinc-500 block text-[10px]">实时价差 (Price Diff):</span>
                            <span className={`font-bold text-xs sm:text-sm flex items-center gap-1 ${isFav ? 'text-emerald-400' : 'text-rose-400'}`}>
                              <span>{delta >= 0 ? '+' : ''}{delta.toFixed(2)}</span>
                              <span
                                className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                                  isFav
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                }`}
                              >
                                {isFav ? '浮盈' : '浮亏'}
                              </span>
                            </span>
                          </div>
                          <div>
                            <span className="text-zinc-500 block text-[10px]">胜率 / 赔率:</span>
                            <span className="text-amber-300 font-bold text-xs sm:text-sm">
                              {activeEthSignal.modelProb}% ({(activeEthSignal.payoutRatio * 100).toFixed(0)}%)
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-1 text-[10px] sm:text-[11px] text-zinc-400">
                          <span>状态: <strong className="text-emerald-400">{activeEthSignal.direction === 'UP' ? '🟢 OPEN LONG (进行中)' : '🔴 OPEN SHORT (进行中)'}</strong></span>
                          <span>ID: <span className="text-zinc-300 font-mono">{activeEthSignal.signalId.slice(0, 14)}...</span></span>
                        </div>
                      </div>
                    );
                  })()
                ) : (
                  /* Real-time Candidate Diagnostic Box when no active ETH signal */
                  <div className="bg-zinc-950 p-3.5 sm:p-4 rounded-xl border border-zinc-800 font-mono text-xs flex flex-col justify-between space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-bold text-white">
                        <span>ETHUSDT</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-900 text-sky-300">
                          {selectedDuration}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-amber-300 border border-zinc-700 font-bold flex items-center gap-1">
                          <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
                          <span>⚪ WAIT (空仓观望)</span>
                        </span>
                      </div>
                      <span className="text-zinc-400 text-[11px]">
                        综合评分: <strong className={ethCandidate && ethCandidate.compositeScore >= 85 ? 'text-emerald-400' : 'text-amber-400'}>
                          {ethCandidate ? ethCandidate.compositeScore : '--'}/100
                        </strong>
                      </span>
                    </div>

                    <div className="bg-zinc-900/60 p-2.5 rounded-lg border border-zinc-800 space-y-2">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-zinc-400">候选倾向:</span>
                        <strong className={ethCandidate?.candidateDirection === 'UP' ? 'text-emerald-400' : 'text-rose-400'}>
                          ETH {ethCandidate?.candidateDirection === 'UP' ? '买涨 (UP)' : '买跌 (DOWN)'}
                        </strong>
                        <span className="text-zinc-500">
                          UP: {ethCandidate ? ethCandidate.upProb.toFixed(1) : '--'}% | DOWN: {ethCandidate ? ethCandidate.downProb.toFixed(1) : '--'}%
                        </span>
                      </div>

                      <div className="border-t border-zinc-800/80 pt-1.5 text-[11px]">
                        <span className="text-zinc-500 block mb-1 text-[10px]">未开单原因 (策略严格过滤):</span>
                        <div className="space-y-1">
                          {ethCandidate && ethCandidate.rejectionReasons.length > 0 ? (
                            ethCandidate.rejectionReasons.slice(0, 2).map((r, i) => (
                              <div key={i} className="text-rose-300 text-[10px] truncate flex items-center gap-1">
                                <span className="text-rose-500 shrink-0">•</span>
                                <span>{r}</span>
                              </div>
                            ))
                          ) : (
                            <div className="text-zinc-400 text-[10px]">
                              等待微观订单流(OFI/CVD)与多周期趋势共振满足正期望
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-0.5">
                      <span>门槛通过: <strong className="text-zinc-300">{ethCandidate ? ethCandidate.conditions.filter((c) => c.passed).length : 0}/14</strong></span>
                      <button
                        onClick={() => setActiveTab('diagnostics')}
                        className="text-amber-400 hover:text-amber-300 font-bold cursor-pointer flex items-center gap-1"
                      >
                        <span>查看14项开单门槛详情</span>
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Core Section 4: 今日真实统计 & 历史每日日结归档 (每日00:00自动重置，历史永久保存) */}
            <DailyStatsDashboard
              currentDate={currentShanghaiDate}
              todayStats={todayStats}
              dailyArchives={dailyArchives}
              allSignalOrders={signalOrders}
              signalStats={signalStats}
              onSelectOrder={() => setActiveTab('orders')}
            />
          </div>
        )}

        {/* Tab: Signal Diagnostics Panel (开单信号诊断模式) */}
        {activeTab === 'diagnostics' && (
          <SignalDiagnosticsPanel
            candidates={diagnosticsData?.candidates}
            dataHealth={diagnosticsData?.dataHealth}
            stats100={diagnosticsData?.stats100}
            opportunityPool={diagnosticsData?.opportunityPool}
            defaultDuration={selectedDuration}
            onRefresh={fetchAllData}
          />
        )}

        {/* Tab 2: Full Historical Signal Orders Page (Exact Requirements) */}
        {(activeTab === 'orders' || activeTab === 'signals') && (
          <HistoryOrdersPanel
            signalOrders={signalOrders}
            stats={signalStats}
            currentPrices={{ BTCUSDT: btcPrice, ETHUSDT: ethPrice }}
            btcPrice={btcPrice}
            ethPrice={ethPrice}
            currentDate={currentShanghaiDate}
            todayStats={todayStats}
            dailyArchives={dailyArchives}
          />
        )}

        {/* Tab 3: Secondary Deep Quant Factors & Microstructure */}
        {activeTab === 'quant' && (
          <div className="space-y-6">
            <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800 text-xs text-zinc-400 flex items-center justify-between">
              <div>
                <strong className="text-white">量化特征与微观盘口分析：</strong>
                提供 OFI (订单流失衡)、CVD (累积成交量差)、L2 深度偏度与多周期均线动量分解
              </div>
              <button
                onClick={() => setActiveTab('live')}
                className="text-amber-400 hover:text-amber-300 font-bold cursor-pointer"
              >
                返回核心K线预测 →
              </button>
            </div>

            <PredictionFactors
              prediction={btcSnapshot?.prediction || null}
              snapshot={btcSnapshot}
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <OrderBookDepth
                orderBook={btcSnapshot?.orderBook || null}
                currentPrice={btcSnapshot?.price || 0}
              />
              <OrderBookDepth
                orderBook={ethSnapshot?.orderBook || null}
                currentPrice={ethSnapshot?.price || 0}
              />
            </div>
          </div>
        )}

        {/* Tab 4: Backtesting & Model Exam Lab */}
        {activeTab === 'backtest' && (
          <div className="space-y-6">
            <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800 text-xs text-zinc-400 flex items-center justify-between">
              <div>
                <strong className="text-white">时间序列策略回测与模型考试：</strong>
                严格使用 Lag(i) 历史截断，杜绝任何未来函数，验证无未来数据泄漏下的真实胜率
              </div>
              <button
                onClick={() => setActiveTab('live')}
                className="text-amber-400 hover:text-amber-300 font-bold cursor-pointer"
              >
                返回核心K线预测 →
              </button>
            </div>

            <BacktestPanel currentSymbol="BTCUSDT" />
            <ModelExamPanel currentSymbol="BTCUSDT" />
          </div>
        )}

        {/* Tab 4-2: Dedicated Model Exam Panel */}
        {activeTab === 'exam' && (
          <div className="space-y-6">
            <ModelExamPanel currentSymbol="BTCUSDT" />
          </div>
        )}

        {/* Tab 5: Exclusive URL & Export Guide */}
        {activeTab === 'export' && (
          <ExportModal
            signals={signalOrders}
            stats={signalStats}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 bg-zinc-950 py-4 text-center text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2 font-mono text-[11px]">
          <div>Binance BTC/ETH 事件合约实时预测工作台 • 币安实盘完整K线历史与实时流</div>
          <div className="text-zinc-600">有效开单信号自动进入订单生命周期 • T+1s 确立 Entry • 到期自动判定胜负平</div>
        </div>
      </footer>
    </div>
  );
}
